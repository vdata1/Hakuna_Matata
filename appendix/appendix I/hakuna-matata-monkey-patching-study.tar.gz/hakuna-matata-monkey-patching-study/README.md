# Artifact: Ecosystem Measurement of Built-in Modification

Artifact for the paper's appendix *Ecosystem Measurement of Built-in
Modification*. It contains the scanners and measurement harnesses, the corpora
they ran on, and the results they produced. The paper contains the full
discussion of the findings; this README covers what is needed to navigate the
data.

The appendix measures one question in two environments: when a security guard
dispatches through a built-in method, how often is that method not the one the
maintainer tested against?

| paper claim | environment | arm | code |
|---|---|---|---|
| 64% of JS-bearing Tranco top-1000 sites modify a built-in; 24.7% override the `String`/`Array` guard-dispatch methods | browser | Exp 2, Arm B | `supply-chain-monkey-patch/` |
| named benign modifiers, and the forms benign modification takes | npm | Exp 2, Arm A | `supply-chain-monkey-patch/` |
| base-rate prevalence of built-in mutation across top npm packages | npm | Exp 1 | `supply-chain-monkey-patch/` |
| guard surface reachable in 25.4–37.3% of server closures; 120 built-ins replaced on load; zero on the guard-dispatch surface | Node | S-1 / S-2 / S-3 | `server-side-measure/` |
| the same null on Deno and Bun | Deno, Bun | S-1 cross-runtime | `server-side-measure/` |

The two directories keep their working names. `server-side-measure/cache/app-scan.json`
is a relative symlink into `supply-chain-monkey-patch/results/`, and one script
resolves the other directory by path, so both must stay siblings.

---

## Quick check

```sh
node smoke/run-smoke.js
```

Runs the detectors over one small synthetic project with a known answer. It
completes in under a second and fetches nothing. This is a check that the
toolchain is intact, not a reproduction of any published number: the fixture is
not the measured corpus. It covers the four code paths the results depend on:
the built-in scanner, the server-mechanism detector, the closure resolver, and
the load-and-diff probe. Before `npm install`, the three parsing stages skip and
the probe still runs. After `npm install` in both arms, all 18 checks run.

The fixture is one project whose dependency closure contains a guarded polyfill
on the guard surface, an unguarded constant-return override, stack
instrumentation that replaces `Function.prototype.toString`, a core-module
wrapper, an opt-in-only patcher, and a negative control that must produce zero
hits. The probe stage snapshots 1,826 built-in slots, observes modifications
from two targets, and reports zero of them on the guard-dispatch surface.

---

## Layout

```
smoke/                        quick check + its one fixture project
supply-chain-monkey-patch/    npm + browser arms
├── scripts/     17 stages: the scanners and crawlers
├── results/     the source data for the published numbers
└── cache/       the frozen population inputs (see "The corpus")

server-side-measure/          server arm
├── scripts/     27 stages: closure resolution, scanners, sandboxed runners
├── results/     the source data for the published numbers
└── cache/       branches.json + the symlink to the Exp-1 app scan
```

Plain Node, no build step. `npm install` in each directory pulls `acorn`,
`acorn-walk` and `yaml`. `playwright` is a dev dependency used only by the
headless-validation stage.

---

## Results summary

Source files are listed after each paragraph.

**Client side.** Of the 458 JS-bearing Tranco top-1000 domains, 293 (64%) modify
a built-in, across 533 distinct `builtin.method` pairs. 113 (24.7%) override the
`String`/`Array` methods that guards dispatch through, and 45 (9.8%) override
`RegExp.prototype.test`. The most frequently modified targets are
`Error.prepareStackTrace` (127 domains), `Function.prototype.toString` (97),
`Promise.finally` (93) and `Object.assign` (91). Two limits apply. The
`() => false` override form occurs twice in the corpus, both guarded shims, so
the form remains distinguishable at line level even where the target is not.
And `Object.prototype.hasOwnProperty` is modified on zero domains.
Source: `results/bundle-scan.json`, `results/bundle_hits.csv`.

**Server side.** Across 142 server closures the guard surface is statically
reachable in 37.3% (upper bound 69%), driven by core-js (25.4%) and
swagger-ui-dist (14.1%). The broad built-in surface reaches 97.9% and core
modules 86.6%. Loading each of 30 curated modifiers alone in an instrumented
process and diffing 1,826 built-in slots by identity produces 403 changes, none
of them on the guard-dispatch surface, on Node, Deno and Bun. The totals are 120
built-in prototype and static replacements against 276 core-module
replacements. `dd-trace` accounts for 228 core-module slots, 115 of them in
`fs`, and replaces no built-in prototype. core-js changes 112 slots at import,
all of them proposal or esnext features; `includes`, `startsWith` and `test`
predate every engine it runs on and are not replaced. 21 of the 30 modify
nothing when loaded alone. Booting real applications (S-3) gives the same
result.
Source: `results/server-prevalence.json`, `results/server-surface.csv`,
`results/s1-crossruntime-raw.json`.

**npm base rate.** The npm scan found built-in mutation in 9 of the top 1,000
packages (0.9%). Packages ranked by download count are predominantly libraries,
which avoid shipping polyfills because patching `Array.prototype` affects
consumers, while core-js reaches applications through transpiler configuration
rather than direct dependency. The browser and server arms measure shipped
bundles and dependency closures for that reason.
Source: `results/summary.md`.

---

## The corpus

Four populations. The frozen inputs that define them are included, so a rerun
measures the same population rather than a fresh one. The fetched bodies are not
included; they are large and re-fetchable from public sources.

**Browser arm: Tranco top-1000.** List `PYG5J`, snapshotted 2026-08-06,
included as `supply-chain-monkey-patch/cache/tranco-top1000-PYG5J.csv`.
Homepages were crawled statically on 2026-08-07. 458 of 1000 domains yielded
JavaScript, giving 8,014 unique assets (673 MB). The other 542 are bot walls,
CDN endpoints with no homepage, or timeouts, all of which undercount, so every
browser figure is a lower bound. The asset inventory is in
`supply-chain-monkey-patch/results/bundles.json`; the asset bodies are not
included.

**npm arm: top 1,000 packages by download count.** Resolved 2026-08-03 and
frozen as `supply-chain-monkey-patch/AugTop1K_npm.json` (+ `.txt`), with the
registry metadata it was built from in
`supply-chain-monkey-patch/cache/manifests-2026-08-03.json`,
`supply-chain-monkey-patch/cache/live-downloads-2026-08-03.json` and
`supply-chain-monkey-patch/cache/dep-graph.json`. All 1,000 packages were
fetched and extracted with zero integrity failures, 940 of them carrying
scannable JavaScript. 32,334 JS files were scanned at a 0.046% parse-failure
rate. These counts are recorded in
`supply-chain-monkey-patch/results/scan-meta.json` and
`supply-chain-monkey-patch/results/corpus-2026-08-03.json`.

**Server arm: 173 self-hostable Node applications.** Drawn from the externally
curated `awesome-selfhosted` catalogue, so the denominator is not self-selected.
Frozen as `supply-chain-monkey-patch/cache/selfhosted-repos.json`, with
`repo-topics.json` and `gh-candidates.json` alongside. 142 have a resolvable
server entry and 91 a client-build entry; the median server closure is 578
packages. The 3,031 dependency packages those closures reach are enumerated in
`server-side-measure/results/server-dataset.json` (78,476 files scanned,
parse-failure rate 0.054%).

**Dynamic arm: 30 curated modifiers.** Listed in
`server-side-measure/scripts/s1-targets.js`, selected from what the static arm
found present rather than from a guessed list. The same 30 are loaded on all
three runtimes, so no cross-runtime difference can be a package-version
artifact.

### Regenerating what is not included

About 12 GB of re-fetchable bulk is excluded:

| excluded | size | regenerate with |
|---|--:|---|
| `*/node_modules/` | 22 MB | `npm install` |
| `supply-chain-monkey-patch/corpus/` | 887 MB | `npm run corpus` |
| `supply-chain-monkey-patch/cache/{tarballs,bundles,trees,repo-files,templates,lockfiles}` | 1.2 GB | `npm run corpus`, `npm run bundles`, `npm run templates` |
| `supply-chain-monkey-patch/cache/counts-*.json`, `tranco-PYG5J.csv` | 113 MB | `npm run population` (the derived top-1000 list is included) |
| `server-side-measure/corpus/` | 4.6 GB | `node scripts/fetch-corpus.js --dataset results/server-dataset.json` |
| `server-side-measure/cache/{tarballs,registry,s1-sandbox,s3,repo-files-extra}` | 4.8 GB | `node scripts/resolve-server-dataset.js`, then the S-1/S-3 runners |

`results/` is included in full, so every number above can be checked without
re-running anything.

---

## Running the scripts

Each script's header comment states its usage, inputs and outputs. The sequences
below are the order in which they were run.

### Browser arm (Exp 2, Arm B): the 64% / 24.7% figures

```sh
cd supply-chain-monkey-patch && npm install
npm run bundles           # crawl homepages, download JS -> cache/bundles/, results/bundles.json
npm run scan-bundles      # AST + core-js signature scan -> results/bundle-scan.json, bundle_hits.csv
npm run bundles-validate  # optional Playwright undercount check -> results/bundles-headless.json
```

Static crawl; site code is never executed.
`supply-chain-monkey-patch/results/bundles-headless-compare.json` quantifies what
the static crawl misses.

### npm arms (Exp 1 base rate, Exp 2 Arm A exemplars)

```sh
npm run population        # build the top-1K population
npm run corpus            # fetch + extract tarballs -> corpus/
npm run scan              # -> results/monkeypatch_hits.csv, results/scan-meta.json
npm run report            # -> results/summary.md (and regenerates FINDINGS.md)
npm run reach             # transitive reachability -> results/transitive-reach.json
npm run armA-resolve && npm run armA-scan   # -> results/armA-exemplars.json, armA_hits.csv
npm test                  # detector unit tests
```

Package code is never executed in these arms; detection is AST-based throughout.

### Server arm (S-1 / S-2 / S-3)

```sh
cd server-side-measure && npm install
node scripts/server-closure.js          # closures per app -> results/server-closures.json
node scripts/select-scan-targets.js     # -> results/scan-targets.json
node scripts/resolve-server-dataset.js  # -> results/server-dataset.json
node scripts/fetch-corpus.js --dataset results/server-dataset.json
node scripts/scan-server-corpus.js      # S-2 static -> results/server-surface-by-package.json
node scripts/server-prevalence.js       # S-2 join   -> results/server-prevalence.json
node scripts/s1-run.js                  # S-1 dynamic, Node -> results/server-surface.csv
node scripts/s1-crossruntime.js         # S-1 on node+deno+bun -> results/s1-crossruntime-raw.json
node scripts/s1-crossruntime-report.js  # -> results/server-surface-crossruntime.csv, corejs-gate-diff.md
node scripts/s3-run.js                  # S-3 boot real apps -> results/server-headless.json
node scripts/test-closure.js && node scripts/test-detector.js && node scripts/test-server-detect.js
```

S-1 and S-3 execute third-party code and are written to run only inside an OS
sandbox: curated named packages only, `npm install --ignore-scripts`, one target
per process under `sandbox-exec` with `(deny network*)`, with the egress block
re-verified per runtime binary before that binary runs. The runners enforce this
themselves. `sandbox-exec` is macOS-specific; on another platform, substitute an
equivalent envelope rather than removing it.

Dynamic results are conditional on node `26.5.0`, deno `2.9.4`, bun `1.3.14`.

Two reporting stages also write prose summaries to their arm root: `npm run
report` writes `FINDINGS.md`, and `s1-crossruntime-report.js` writes
`CROSSRUNTIME_FINDINGS.md`. These are generated documents and are not included
here, since the paper covers the same material.

---

## Reading the results

The scanners tag every hit with a tier, defined in `scan-monkeypatch.js`
(`tierOf`) and used as a column in the hit CSVs:

- **Tier A**: `String.prototype` (`includes`, `startsWith`, `endsWith`,
  `indexOf`, `lastIndexOf`, `split`, `match`, `search`, `matchAll`) and
  `Array.prototype` (`includes`, `indexOf`). The guard-dispatch surface.
- **Tier B**: `RegExp.prototype.test`.
- **Tier C**: `Object.prototype.hasOwnProperty` (incl. `.call`) and
  `Reflect.getPrototypeOf`.

Tags are descriptive over all hits. Capture is not restricted to these methods,
since the breadth of the modified surface is itself a result.

Three reporting rules apply to the numbers:

1. The `guard`, `broad`, `coremodule` and `global` buckets are not merged into a
   single "modifies a built-in" percentage.
2. The server guard surface is a range (25.4–37.3%), not a point. Static
   reachability leaves genuine uncertainty about dynamic loading, and the range
   bounds it.
3. The dynamic results are conditional on the runtime versions above, and
   prevalence is not exploitability.
