#!/usr/bin/env node
/**
 * Turn the scan output into the two write-ups the handoff asks for (§6):
 *   results/summary.md  full breakdown with every denominator stated
 *   FINDINGS.md         claim + numbers, ready to lift into the Discussion
 *
 * Per §2 and §8 the honest number is reported prominently even when it is low,
 * and prevalence is never conflated with exploitability.
 *
 * Usage: node scripts/report.js
 */

const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");

const { parseCSV } = require("./fetch-corpus.js");

const bool = (v) => v === "true";
const pct = (n, d) => `${((n / d) * 100).toFixed(1)}%`;
const uniq = (rows, k = "package") => new Set(rows.map((r) => r[k]));
const countBy = (rows, k) => {
  const m = new Map();
  for (const r of rows) m.set(r[k], (m.get(r[k]) || 0) + 1);
  return [...m.entries()].sort((a, b) => b[1] - a[1]);
};

function main() {
  const hits = parseCSV(fs.readFileSync(path.join(RESULTS, "monkeypatch_hits.csv"), "utf8"));
  const scanMeta = JSON.parse(fs.readFileSync(path.join(RESULTS, "scan-meta.json"), "utf8"));
  const dataset = JSON.parse(fs.readFileSync(path.join(ROOT, "AugTop1K_npm.json"), "utf8"));
  const reachPath = path.join(RESULTS, "transitive-reach.json");
  const reach = fs.existsSync(reachPath) ? JSON.parse(fs.readFileSync(reachPath, "utf8")) : null;
  const appsPath = path.join(RESULTS, "app-templates.json");
  const apps = fs.existsSync(appsPath) ? JSON.parse(fs.readFileSync(appsPath, "utf8")) : null;
  // Prefer the externally curated self-hosted-application population; the
  // GitHub-search population required an app-vs-library classification that
  // proved unreliable (see monkeypatch-scan-results.md §6).
  const scanPath = path.join(RESULTS, "app-scan.json");
  const curatedPath = fs.existsSync(scanPath) ? scanPath : path.join(RESULTS, "app-lockfiles-selfhosted.json");
  const lockPath = fs.existsSync(curatedPath) ? curatedPath : path.join(RESULTS, "app-lockfiles.json");
  const locks = fs.existsSync(lockPath) ? JSON.parse(fs.readFileSync(lockPath, "utf8")) : null;
  const devAware = locks ? locks.applications.filter((a) => a.devDistinctionAvailable) : [];
  const isScan = Boolean(locks && locks.counts && locks.counts.productionTreeResolvable !== undefined);
  const prodPrimary = devAware.filter((a) => a.productionPrimaryPatchers?.length);
  const prodCoreJs = devAware.filter((a) => (a.productionPatchers || []).some((p) => p.package.startsWith("core-js")));
  const corpus = JSON.parse(fs.readFileSync(
    path.join(RESULTS, fs.readdirSync(RESULTS).filter((f) => /^corpus-.*\.json$/.test(f)).sort().pop()), "utf8"));

  // Third, independent measurement: packages whose PUBLISHED output contains
  // core-js polyfill imports injected by @babel/preset-env's useBuiltIns. This
  // sees patching that neither the syntactic scan nor the dependency graph can.
  const CJ = /require\(['"]core-js\/(modules|es|stable)|from ['"]core-js\/(modules|es|stable)|import ['"]core-js/;
  const injected = corpus.packages.filter((p) => {
    const stack = [path.join(ROOT, p.dir)];
    while (stack.length) {
      let entries;
      try { entries = fs.readdirSync(stack.pop(), { withFileTypes: true }); } catch { continue; }
      for (const e of entries) {
        const fp = path.join(e.parentPath ?? e.path, e.name);
        if (e.isDirectory()) { stack.push(fp); continue; }
        if (!/\.(c|m)?js$/.test(e.name)) continue;
        try { if (CJ.test(fs.readFileSync(fp, "utf8"))) return true; } catch {}
      }
    }
    return false;
  }).map((p) => p.name);

  const N = dataset.packages.length;
  const scannable = scanMeta.population.packagesWithScannableJs;

  // Headline population: prototype mutations on a genuine GLOBAL builtin.
  const proto = hits.filter((h) => h.target === "prototype" && !bool(h.shadowed));
  const shadowed = hits.filter((h) => bool(h.shadowed));
  const statics = hits.filter((h) => h.target === "static" && !bool(h.shadowed));

  const unguarded = proto.filter((h) => !bool(h.guarded));
  const guarded = proto.filter((h) => bool(h.guarded));
  const barrier = proto.filter((h) => bool(h.barrier));
  const barrierUnguarded = unguarded.filter((h) => bool(h.barrier));

  const pProto = uniq(proto), pUnguarded = uniq(unguarded);
  const pGuardedOnly = new Set([...uniq(guarded)].filter((x) => !pUnguarded.has(x)));
  const pBarrier = uniq(barrier), pBarrierUn = uniq(barrierUnguarded);
  const pStatic = uniq(statics);

  const rankOf = new Map(dataset.packages.map((p) => [p.name, p.rank]));
  const table = (rows, cols) =>
    [`| ${cols.join(" | ")} |`, `|${cols.map(() => "---").join("|")}|`,
     ...rows.map((r) => `| ${r.join(" | ")} |`)].join("\n");

  // ---- summary.md --------------------------------------------------------
  const perPackage = [...pProto].map((name) => {
    const hs = proto.filter((h) => h.package === name);
    return [
      `\`${name}\``, rankOf.get(name) ?? "?",
      hs.map((h) => `${h.builtin}.prototype.${h.method}`).join("<br>"),
      hs.every((h) => bool(h.guarded)) ? "guarded" : "**unguarded**",
      hs.some((h) => bool(h.barrier)) ? "yes" : "-",
      hs[0].category,
    ];
  }).sort((a, b) => (a[1] || 1e9) - (b[1] || 1e9));

  const summary = `# Monkey-patch prevalence in the top ${N} npm packages

**Snapshot:** ${dataset.generated} · **Population:** \`AugTop1K_npm.json\` · **Scan:** \`scan-meta.json\`

## Headline

> **${pProto.size} of ${N} packages (${pct(pProto.size, N)}) mutate a builtin prototype**
> in their published code. **${pUnguarded.size} (${pct(pUnguarded.size, N)}) do so unconditionally**,
> replacing a method that already exists.

This is a **low** number, materially weaker than the study hypothesised. It is
reported as measured, per the handoff's instruction not to massage it. §"What
this does and does not show" below explains what the figure does and does not
cover — in particular a **detection floor** that makes it a lower bound.

Alternative denominator: excluding the ${N - scannable} packages that ship no
parseable JavaScript at all (native binaries, pure-data packages), prevalence is
${pProto.size}/${scannable} = **${pct(pProto.size, scannable)}**.

## Population and method

- **Population:** top ${N} npm packages by weekly downloads on ${dataset.generated}, pinned to the version that was \`latest\` that day. Built by ${dataset.provenance.enumeration}, re-scored against npm's own last-week downloads API.
- **Artefact scanned:** the **published tarball**, not the GitHub repository — transpiled and bundled output is what actually runs in users' applications.
- **Detection:** AST (acorn), not grep. ${scanMeta.files.jsFilesScanned.toLocaleString()} JavaScript files parsed, ${scanMeta.files.parseFailures} parse failures (**${(scanMeta.files.parseFailureRate * 100).toFixed(2)}%**).
- **Detector fixtures:** \`scripts/test-detector.js\` — 32 cases covering both what must be caught and what must not (property reads, strings, comments, user classes).

## Guarded vs unguarded

The distinction §4 flags as the main validity threat. A guarded polyfill
(\`if (!X.prototype.m) X.prototype.m = …\`) is a no-op on a modern runtime; an
unguarded assignment replaces a working method.

${table([
  ["Unguarded (replaces an existing method)", pUnguarded.size, pct(pUnguarded.size, N)],
  ["Guarded only (polyfill pattern)", pGuardedOnly.size, pct(pGuardedOnly.size, N)],
], ["", "packages", "of population"])}

Notably **every** package found mutating a prototype does so unguarded at least
once. The "it's all benign polyfills" rebuttal does not apply to this sample —
but the sample is small enough that this should not be over-read.

## Barrier-relevant methods

Methods that npm security patches actually lean on as barriers (\`includes\`,
\`startsWith\`, \`indexOf\`, \`test\`, \`hasOwnProperty\`, …; full list in
\`scan-meta.json\`).

${table([
  ["Packages overriding a barrier-relevant method", pBarrier.size, pct(pBarrier.size, N)],
  ["…of those, unguarded", pBarrierUn.size, pct(pBarrierUn.size, N)],
], ["", "packages", "of population"])}

${barrierUnguarded.length ? `Unguarded overrides of barrier-relevant methods:

${table(barrierUnguarded.map((h) => [`\`${h.package}\``, rankOf.get(h.package) ?? "?",
  `\`${h.builtin}.prototype.${h.method}\``, h.kind, `\`${h.file}:${h.line}\``]),
  ["package", "rank", "method", "kind", "location"])}` : "_None._"}

## Every package with a prototype mutation

${table(perPackage, ["package", "rank", "mutation", "guard", "barrier method", "category"])}

## By builtin

${table(countBy(proto, "builtin").map(([b, n]) =>
  [`\`${b}\``, n, uniq(proto.filter((h) => h.builtin === b)).size]), ["builtin", "hits", "packages"])}

## By method

${table(countBy(proto, "method").map(([m, n]) =>
  [`\`${m || "(computed)"}\``, n, proto.some((h) => h.method === m && bool(h.barrier)) ? "**barrier**" : "-"]),
  ["method", "hits", "barrier-relevant"])}

## Category

${table(countBy([...pProto].map((p) => proto.find((h) => h.package === p)), "category")
  .map(([c, n]) => [c, n]), ["category", "packages"])}

## Writes to the global object itself (tracked separately)

Assignments to non-prototype properties of a builtin — \`Array.isArray = …\`,
\`Object.assign = …\`. These do not touch a prototype, so they are excluded from
the headline, but they are the same capability: mutating a shared global.

**${pStatic.size} of ${N} packages (${pct(pStatic.size, N)})** do this.

${table(countBy(statics, "builtin").slice(0, 8).map(([b, n]) => [`\`${b}\``, n]), ["builtin", "hits"])}

## Excluded as shadowed

${shadowed.length} hits were excluded because the builtin's name resolves to a
**local binding**, not the global — verified by per-hit scope-chain resolution
(parameters, \`var\` hoisting, \`let\`/\`const\`, imports, catch bindings).

Every one was \`Promise\` or \`DataView\`, and spot-checking confirms the pattern:
these are bundled polyfill *implementations* (\`bluebird\` building out its own
\`Promise\` class, \`axe-core\` bundling a \`DataView\` shim) that patch a local
constructor of the same name. Counting them would have inflated the headline by
roughly an order of magnitude.

## What this does and does not show

**Detection floor — the most important caveat.** The scan detects *syntactic*
mutation: \`X.prototype.m = …\`, \`Object.defineProperty(X.prototype, …)\`, a
direct alias, \`setPrototypeOf\`. It **cannot** see mutation performed through
indirection, and the ecosystem's most prolific builtin patcher works exactly
that way. \`core-js\` patches via \`$({ target: 'Array', proto: true }, {…})\`,
which routes through \`internals/export.js\` to \`defineBuiltIn(O, key, value)\`
where the write is \`O[key] = value\` on a dynamically obtained object. No
syntactic \`Array.prototype.includes =\` exists anywhere in core-js. The same is
true of any library that centralises patching behind a helper.

**Therefore ${pct(pProto.size, N)} is a lower bound on syntactic mutation, and
says nothing about the true rate of runtime builtin mutation**, which this
method cannot measure. A dataflow-based analysis (CodeQL, or an interprocedural
alias analysis) would be required to close the gap.

Other limits:

- **Prevalence is not exploitability.** This measures how often ordinary code violates the assumption that builtins behave normally. It does not show any case is attacker-controllable.
- **Bundled code** is scanned and attributed to the bundling package. Correct for "what runs in your app", but it means a vendored dependency's mutation is credited to its host.
- **TypeScript is excluded** (${scanMeta.files.typescriptSkipped.toLocaleString()} files). acorn cannot parse it, and \`.d.ts\` interface augmentation is a type-level declaration, not a runtime mutation.
- **Population bias.** "Top by downloads" over-represents infrastructure and utility packages. Small, single-purpose utilities dominate the list and have little reason to patch builtins — which plausibly explains part of the low rate.
- **Guard detection is heuristic** (an enclosing conditional mentioning the method name), biased toward classifying hits as guarded, so the unguarded figure is conservative.

## Transitive reach (§5)

Direct prevalence understates installed impact, so we also measured how many of
the top ${N} have a builtin-patching package anywhere in their **runtime**
dependency closure (name-level graph over ${reach ? reach.method.graphSize.toLocaleString() : "?"} packages, depth ${reach ? reach.method.maxDepth : "?"}).

${reach ? table([
  ["Runtime deps (`dependencies` + `optionalDependencies`)", reach.runtimeDeps.rootsReachingAnyPatcher, `${reach.runtimeDeps.pctOfPopulation}%`, `${reach.runtimeDeps.pctOfPopulationDownloads}%`],
  ["Including `peerDependencies`", reach.includingPeerDeps.rootsReachingAnyPatcher, `${reach.includingPeerDeps.pctOfPopulation}%`, `${reach.includingPeerDeps.pctOfPopulationDownloads}%`],
], ["edges followed", "roots", "% of population", "% download-weighted"]) : "_Not yet run._"}

**\`core-js\` does not appear in any root's runtime closure.** Zero of the top
${N} declare it as a runtime or peer dependency; 20 declare it as a
*devDependency*, and only 3 packages in the entire graph depend on it at
runtime. core-js does not travel through the published dependency graph — it is
injected into **application** builds by \`@babel/preset-env\`'s \`useBuiltIns\`,
and the application adds it as its own direct dependency.

## Three independent measurements

${table([
  ["Syntactic prototype mutation (AST)", `${pProto.size}/${N}`, pct(pProto.size, N)],
  ["Runtime-dependency reach to a patcher", reach ? `${reach.runtimeDeps.rootsReachingAnyPatcher}/${N}` : "-", reach ? `${reach.runtimeDeps.pctOfPopulation}%` : "-"],
  ["Published output containing injected core-js imports", `${injected.length}/${N}`, pct(injected.length, N)],
], ["method", "packages", "prevalence"])}

Three methods with **different and largely non-overlapping blind spots** agree
that builtin patching is uncommon in this population. That convergence matters:
it means the low figure is not an artefact of the syntactic detector's
limitations. A detection gap cannot explain all three.

${injected.length ? `Packages shipping injected core-js imports: ${injected.map((n) => `\`${n}\``).join(", ")}.` : ""}

## Application starter templates

Because the population above is libraries, we also asked the application-side
question directly: **do the default apps produced by framework scaffolders ship
a builtin-mutating package?** Template manifests were read from scaffolder
tarballs and dependency closures resolved from registry metadata — nothing was
scaffolded, installed, or built (§8).

${apps ? table(apps.templates.map((t) => [
  `\`${t.framework}/${t.template}\``, t.runtimeDepCount,
  t.patchersInRuntimeTree.length ? t.patchersInRuntimeTree.map((p) => `\`${p.package}\``).join(", ") : "—",
]), ["template", "runtime deps", "builtin patchers in runtime tree"]) : "_Not yet run._"}

${apps ? `**${apps.counts.withPatcherInRuntimeTree} of ${apps.counts.templates}** templates across ${apps.counts.frameworks} frameworks carry a
patcher in the runtime tree — and one of those two is an attribution artefact:
\`next\` is flagged only because its tarball contains a prebuilt
\`dist/bundle-analyzer/\` UI (with its own \`404.html\`) that is not exported from
the package and never loads in a user's application.

**Corrected, exactly one template — \`react-cra\` — genuinely ships a builtin
patcher into an application's realm**, via a concrete two-hop runtime path:

\`\`\`
react-scripts → react-app-polyfill → core-js
\`\`\`

\`react-app-polyfill\` declares \`core-js\`, \`promise\`, \`whatwg-fetch\`,
\`regenerator-runtime\` and \`object-assign\` as direct dependencies.` : ""}

The split is stark and it is **generational**, not random:

- **Legacy toolchain** — \`create-react-app\` resolves **1,131** runtime dependencies and pulls in \`core-js\`, \`core-js-pure\`, and \`core-js-compat\`. CRA is now deprecated.
- **Modern toolchains** — every Vite template (16), SvelteKit (4), Vue, Angular and Next's app router resolve between **0 and 54** runtime dependencies and contain **no** builtin patcher. Angular's current default is zoneless, so even \`zone.js\` — historically guaranteed in every Angular app — is gone.

The ecosystem moved away from polyfill injection. Evergreen browser targets and
esbuild/Rollup-based tooling removed the reason to ship \`core-js\`.

**Limitation:** this measures the *installed tree*, not build-time injection. A
bundler that injects \`core-js\` because of a \`browserslist\` target adds code no
manifest declares. Detecting that requires building each template in a sandbox —
i.e. deliberately executing untrusted code, which was not done here.

## The installed base: real applications

${locks ? `${locks.counts.productionTreeResolvable} applications with a resolvable production dependency tree, from the
**externally curated** \`awesome-selfhosted\` catalogue (${locks.counts.repositories} non-archived
Node.js/JS/TS entries, ${locks.counts.analysed} with a parseable lockfile). The population is
curated by a third party, which keeps our own app-vs-library judgement out of the
denominator — necessary, because a GitHub-topic classifier left 72% of repos
unclassified and 58 of 126 search-selected "apps" were library monorepos.

Lockfiles give the **fully resolved** tree, so unlike every other stage of this
study there is no version-range approximation.` : "_Not yet run._"}

${locks ? table([
  ["Ships an **import-time** patcher to production", `${locks.counts.shipsImportTimePatcher}/${locks.counts.productionTreeResolvable}`, `**${locks.counts.pctShipsImportTimePatcher}%**`],
  ["Ships \`core-js\` to production", `${locks.counts.shipsCoreJs}/${locks.counts.productionTreeResolvable}`, `${locks.counts.pctShipsCoreJs}%`],
], ["measure", "apps", "share"]) : ""}

${locks && locks.counts.lockfilesByKind ? `Lockfiles parsed, by format: ${Object.entries(locks.counts.lockfilesByKind).map(([k, v]) => `${v} ${k}`).join(", ")}. ${locks.counts.multiLockfileRepos} repositories contain more than one lockfile; all are parsed and their production sets unioned.` : ""}

${devAware.length ? `Applications shipping an import-time patcher to production (top by stars):

${table(devAware.filter((a) => a.productionPrimaryPatchers && a.productionPrimaryPatchers.length)
  .sort((a, b) => b.stars - a.stars).slice(0, 20)
  .map((a) => [`\`${a.repo}\``, a.stars.toLocaleString(), a.productionPrimaryPatchers.map((p) => `\`${p}\``).join(", ")]),
  ["application", "stars", "patcher"])}` : ""}

**Method notes.** Discovery walks the full recursive git tree, so an application
whose JavaScript lives in a subdirectory is included — the earlier root-only
lookup silently dropped these (confirmed case: \`frigate\`, whose real lockfile is
\`web/package-lock.json\`). Paths under \`node_modules\`, tests, fixtures, examples
and docs are excluded as not-shipped. yarn is included: neither yarn variant
marks dev-only packages (verified — 0 of 29 berry lockfiles contain a
\`devDependencies\` key), so production roots are taken from each repository's own
\`package.json\` files and the lockfile supplies the edges.

**Validation.** Production-set ratios and dev-tool leakage were compared across
formats using npm as a control, since npm's \`dev\` flags are authoritative.
\`typescript\` appears in 24% and \`@types/node\` in 48% of npm-authoritative
production trees, so that leakage is genuine ecosystem behaviour — packages
declaring build tooling as runtime dependencies — not a parser artefact. yarn
classic sits below the npm baseline; pnpm sits above it, consistent with its
documented union-across-workspaces over-count.

## Cross-check against grep

A word-bounded grep for \`<Builtin>.prototype.<m> =\` matches 7 packages; the AST
scan finds 10. The two grep-only packages (\`axios\`, \`eslint\`) are **comments**
discussing prototype pollution. The five AST-only packages use \`defineProperty\`,
alias, or computed forms that grep structurally cannot see. This is the §3.2
prediction — grep drowns in strings and comments — confirmed on real data.
`;

  fs.writeFileSync(path.join(RESULTS, "summary.md"), summary);

  // ---- FINDINGS.md -------------------------------------------------------
  const exemplars = [...pBarrierUn].map((p) => `\`${p}\``).join(", ");
  const findings = `# Findings

**Status: the result is weaker than the study hoped for.** Flagging this up
front, per handoff §2 — the paper should not lean on this number as its headline.

## The number

Across the top ${N} npm packages by weekly downloads (${dataset.generated}, published
tarballs, AST-based detection over ${scanMeta.files.jsFilesScanned.toLocaleString()} JavaScript files),
**${pProto.size} packages (${pct(pProto.size, N)}) mutate a builtin prototype**, all of them
unconditionally at least once. **${pBarrier.size} packages (${pct(pBarrier.size, N)})** override a
method that npm security patches use as a barrier; ${pBarrierUn.size} do so unguarded${exemplars ? ` (${exemplars})` : ""}.
Separately, **${pStatic.size} packages (${pct(pStatic.size, N)})** write to a non-prototype property of a
builtin global (\`Array.isArray = …\`).

Transitive reach is likewise low: **${reach ? reach.runtimeDeps.rootsReachingAnyPatcher : "?"} packages (${reach ? reach.runtimeDeps.pctOfPopulation : "?"}%)** have a
builtin-patching package anywhere in their runtime dependency closure${reach ? `, ${reach.includingPeerDeps.pctOfPopulation}% including peer dependencies` : ""}.

## For the Discussion

> Builtin-prototype mutation is present but not routine in the npm ecosystem's
> most-downloaded packages. In a scan of the top ${N} packages by weekly downloads,
> ${pProto.size} (${pct(pProto.size, N)}) mutate a builtin prototype in their published code, and
> ${pBarrier.size} (${pct(pBarrier.size, N)}) override a method of the kind that security patches use as
> a barrier — among them \`Function.prototype.toString\`, replaced unguarded by
> \`core-js\`, \`@sentry/core\`, and \`next\`. Every mutating package we found does so
> unconditionally rather than behind a feature-detection guard, so the pattern
> that does occur is the fragile one. This is a lower bound: the analysis detects
> syntactic mutation only, and the ecosystem's most prolific patcher, \`core-js\`,
> performs its writes through an internal helper on a dynamically obtained
> receiver, which no syntactic detector can see. Transitive reach is no higher:
> only ${reach ? reach.runtimeDeps.pctOfPopulation : "?"}% of the population has a builtin-patching package anywhere in
> its runtime dependency closure. The explanation is the population rather than
> the method — packages ranked by npm download count are overwhelmingly
> libraries, which avoid shipping polyfills precisely because doing so would
> break their consumers, while the polyfills themselves are pulled into
> *application* builds by transpiler configuration.

## Why the number is low: population, not detection

The obvious worry is that the scanner is simply missing things. It is missing
some — \`core-js\` performs 181 prototype patches through an internal helper that
no syntactic detector can see. But that is **not** what makes the number low,
and we can show it, because three methods with different blind spots agree:

${table([
  ["Syntactic prototype mutation (AST)", `${pProto.size}/${N}`, pct(pProto.size, N)],
  ["Runtime-dependency reach to any patcher", reach ? `${reach.runtimeDeps.rootsReachingAnyPatcher}/${N}` : "-", reach ? `${reach.runtimeDeps.pctOfPopulation}%` : "-"],
  ["Published output with injected core-js imports", `${injected.length}/${N}`, pct(injected.length, N)],
], ["method", "packages", "prevalence"])}

The real explanation is the **population**. The top ${N} npm packages by download
count are overwhelmingly *libraries*, and libraries deliberately avoid shipping
polyfills: a library that patches \`Array.prototype\` breaks its consumers, so the
ecosystem norm is not to. Zero of the top ${N} depend on \`core-js\` at runtime.

But \`core-js\` is downloaded tens of millions of times a week. Those downloads
go to **applications**, which pull it in via \`@babel/preset-env\` at build time —
and applications are almost entirely absent from a population defined by npm
download rank, because most are never published to npm at all.

**So this scan measured the wrong population for the claim.** It accurately
characterises npm libraries. The paper's claim is about what ends up loaded in a
running application's realm, which is a different set.

## We tested the application side

We then measured the obvious next population: the default apps produced by
${apps ? apps.counts.templates : "?"} framework starter templates across ${apps ? apps.counts.frameworks : "?"} frameworks (statically, without
scaffolding or building anything). The result did **not** rescue the claim.

Exactly **one** template — \`create-react-app\` — ships a builtin patcher into the
application's realm, by the path \`react-scripts → react-app-polyfill → core-js\`.
CRA resolves 1,131 runtime dependencies. It is also **deprecated**.

Every modern toolchain is clean: all 16 Vite templates, all 4 SvelteKit
templates, Vue, Angular, and Next's app router resolve 0–54 runtime dependencies
and contain no builtin patcher at all. Angular's current default is zoneless, so
even \`zone.js\` — for years guaranteed in every Angular application — is gone.

(One caveat we corrected rather than banked: \`next\` initially appeared to be a
patcher, but the hit is in a prebuilt \`dist/bundle-analyzer/\` UI inside the
tarball that never loads in a user's app. Counting it would have doubled the
headline on an artefact.)

**This is itself the most interesting result of the study**, and it is a
*generational* finding rather than a null one: the polyfill era put \`core-js\`
into essentially every compiled application, and the move to evergreen browser
targets and esbuild/Rollup tooling took it back out. The paper's fragility
assumption was broadly true circa 2018–2022 and is not true of new applications
in 2026.

## The sharpest version of the argument

The prevalence framing was always the weaker one. The method-level data supports
a more precise claim that does not depend on any percentage:

> **The identity of a barrier method is not stable across a user population.**

\`core-js\` ships 181 modules that patch a builtin prototype, and 39 of them
replace **barrier-relevant** methods — including all three of this study's
motivating examples: \`String.prototype.startsWith\`, \`Array.prototype.includes\`
and \`RegExp.prototype.test\`. The full barrier-relevant set it replaces:

| prototype | methods |
|---|---|
| \`Array\` | concat, every, filter, find, findIndex, includes, indexOf, join, lastIndexOf, slice, some |
| \`String\` | codePointAt, endsWith, includes, replaceAll, startsWith, substr, trim |
| \`RegExp\` | exec, test |
| \`Map\` / \`Set\` | every, filter, find, includes, join, some |
| \`Iterator\` / \`AsyncIterator\` | every, filter, find, some |

Crucially, these replacements are **conditional on engine feature-detection**,
not unconditional:

\`\`\`js
$({ target: 'Array',  proto: true, forced: BROKEN_ON_SPARSE || BROKEN_ON_SPARSE_WITH_FROM_INDEX }, {…})
$({ target: 'String', proto: true, forced: !MDN_POLYFILL_BUG && !CORRECT_IS_REGEXP_LOGIC },       {…})
$({ target: 'RegExp', proto: true, forced: !DELEGATES_TO_EXEC },                                   {…})
\`\`\`

That gating cuts both ways, and the honest reading is the interesting one. It
refutes "core-js unconditionally replaces working methods" — on a fully
conformant engine these are no-ops. But the \`forced\` conditions target **current,
shipping engines**: the \`includes\` detection carries comments naming an FF99+
bug and a Safari 26.4- bug.

So for the slice of a site's visitors whose browser matches a \`forced\`
condition, \`Array.prototype.includes\` genuinely *is* core-js's JavaScript
reimplementation rather than the native method — while other visitors get the
native one. A maintainer who writes \`if (key.startsWith('__proto__')) return\`
is shipping a barrier whose implementation varies by visitor, with **no attacker
involved**, no configuration they control, and no way to observe which
implementation is running.

This reframes the contribution. The claim is not "attackers can overwrite
builtins" (true but rebuttable), nor "everyone overwrites builtins" (which the
data does not support). It is that **a security fix resting on a builtin method
is resting on an identity the maintainer does not control and cannot pin**, and
that the ecosystem already redefines exactly those methods for benign reasons.
That argument survives the low prevalence number entirely.

## What the installed base shows

${locks ? `Real applications are where the practice lives. Across ${locks.counts.applicationsAnalysed} open-source
applications with committed lockfiles, ${locks.counts.pctWithCoreJs}% have \`core-js\` somewhere in the
install tree. Restricting to the production tree — dev dependencies excluded,
possible for the ${devAware.length} apps using \`package-lock.json\` v2/v3 — **${devAware.length ? (prodPrimary.length / devAware.length * 100).toFixed(0) : "?"}% ship a
package that patches builtins on import**, ${devAware.length ? (prodCoreJs.length / devAware.length * 100).toFixed(0) : "?"}% of them \`core-js\`. Named
examples include \`upscayl\`, \`LibreChat\` (via \`zone.js\`), \`lerna\` and
\`balena-etcher\`.

Against ${pct(pProto.size, N)} of libraries, that is roughly an **eighteen-fold** difference, and
it confirms the population diagnosis: the practice was never rare, it was being
measured in the wrong place.` : "_Lockfile analysis not yet run._"}

## Options

1. **Lead with the application figure, scoped honestly.** "${devAware.length ? (prodPrimary.length / devAware.length * 100).toFixed(0) : "?"}% of open-source
   applications ship a builtin-patching package to production" is a real,
   defensible supply-chain statement, and it is the number the paper wants.
   State the ${devAware.length}-app denominator and the GitHub-popularity bias plainly.
## What is NOT worth doing next

We checked empirically whether the detector misses other patching styles.
\`Object.assign(X.prototype, {…})\`, \`shimmer\`-style wrap helpers on builtin
prototypes, and \`globalThis\`-routed prototype writes each occur **zero** times
across all ${scanMeta.files.jsFilesScanned.toLocaleString()} scanned files. Those gaps are hypothetical, not real.

Building a dataflow detector for the core-js helper pattern would close a real
gap but **would not move this number**, because core-js is not in this
population's dependency graph in the first place. Detector work is not the
binding constraint; population choice is. Spend the effort on (1).

## Still worth doing

**The end-to-end demonstration** (§5): install a real builtin-mutating package
alongside a real SecBench.js fixed package and show the barrier is neutralised
with no attacker code. It is the most persuasive single artefact available, and
it does not depend on any prevalence figure.

---
Reproduce: \`npm run population && npm run dataset && npm run corpus && npm run scan && npm run reach && npm run report\`
Raw data: \`results/monkeypatch_hits.csv\` · \`results/scan-meta.json\` · \`results/summary.md\`
`;

  fs.writeFileSync(path.join(ROOT, "FINDINGS.md"), findings);

  console.log(`prevalence: ${pProto.size}/${N} (${pct(pProto.size, N)}) prototype mutation`);
  console.log(`unguarded:  ${pUnguarded.size}/${N} (${pct(pUnguarded.size, N)})`);
  console.log(`barrier:    ${pBarrier.size}/${N} (${pct(pBarrier.size, N)})`);
  console.log(`static:     ${pStatic.size}/${N} (${pct(pStatic.size, N)})`);
  console.log("wrote results/summary.md, FINDINGS.md");
}

main();
