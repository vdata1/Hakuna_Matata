#!/usr/bin/env node
/**
 * Measure the INSTALLED BASE: do real, deployed open-source applications have a
 * builtin-mutating package in their resolved dependency tree?
 *
 * Why this population: the top-1,000-by-downloads scan
 * measured libraries, which avoid patching builtins by norm. Framework starter
 * templates measured what NEW apps get, which is clean since the ecosystem
 * moved off polyfill injection. Neither measures what is actually deployed
 * today -- applications built during the polyfill era and still in production.
 *
 * A committed lockfile is the ideal artefact: it records the FULLY RESOLVED
 * tree, so unlike every earlier stage there is no version-range approximation.
 * Every name in a lockfile is genuinely installed.
 *
 * Selection is systematic, not curated: popular JS/TS repositories are taken
 * from GitHub search, then filtered to those that look like APPLICATIONS rather
 * than published libraries (a committed lockfile, plus `private: true` or the
 * absence of publishing fields). Selection criteria and all rejects are
 * recorded so the population is auditable.
 *
 * Nothing is executed and nothing is installed: lockfiles are parsed as data.
 *
 * Usage:  node scripts/app-lockfiles.js [--limit N]
 * Output: results/app-lockfiles.json
 */

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const LOCKS = path.join(CACHE, "lockfiles");
const RESULTS = path.join(ROOT, "results");

const CONCURRENCY = 6;
const log = (...a) => console.error("[locks]", ...a);

/**
 * Packages tiered by WHAT THEY ACTUALLY DO on install, established by the scan
 * (`importTime` / `guarded` columns in monkeypatch_hits.csv) and by reading the
 * sources. The tiering matters more than the membership: the paper's claim
 * needs a patch that fires merely because the module was loaded.
 *
 *   importTime  patches global builtins as a side effect of being imported.
 *               This is the tier that supports the claim.
 *   optIn       defines a patch that only applies when the consumer calls
 *               something -- `once.proto()`, an es-shim `shim()`, `chai.should()`.
 *               Present in the tree does NOT mean the builtin was modified.
 *   guarded     patches on import, but behind feature detection, so on a modern
 *               runtime the assignment never executes.
 *
 * DELIBERATELY EXCLUDED, having previously been counted in error:
 *   core-js-pure    the whole point of the `pure` build is that it does NOT
 *                   touch globals; it exposes polyfills as plain modules.
 *   core-js-compat  metadata only (browser-support tables), patches nothing.
 * Both are extremely common in lockfiles, so including them inflated an early
 * version of this measurement badly.
 */
const PATCHERS = {
  "core-js": "importTime", "core-js-bundle": "importTime",
  "@babel/polyfill": "importTime", "zone.js": "importTime",
  "es5-shim": "guarded", "es6-shim": "guarded", "axe-core": "guarded",
  "@sentry/core": "optIn", "chai": "optIn", "bowser": "optIn",
  "once": "optIn", "d3-array": "optIn", "array.prototype.tosorted": "optIn",
};

/** The tier that actually supports the paper's claim. */
const PRIMARY = new Set(Object.keys(PATCHERS).filter((k) => PATCHERS[k] === "importTime"));

const LOCKFILES = ["package-lock.json", "pnpm-lock.yaml", "yarn.lock", "npm-shrinkwrap.json"];

const gh = (endpoint, jq) => {
  const args = ["api", endpoint];
  if (jq) args.push("--jq", jq);
  return execFileSync("gh", args, { encoding: "utf8", maxBuffer: 64 * 1024 * 1024 });
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------

/** Popular JS/TS repositories, several queries for breadth. */
function discover(limit) {
  const cachePath = path.join(CACHE, "gh-candidates.json");
  if (fs.existsSync(cachePath)) {
    const c = JSON.parse(fs.readFileSync(cachePath, "utf8"));
    if (c.length >= limit) { log(`using ${c.length} cached candidates`); return c.slice(0, limit); }
  }
  const queries = [
    "stars:>2000 language:TypeScript archived:false",
    "stars:>2000 language:JavaScript archived:false",
    "stars:>500 language:TypeScript topic:app archived:false",
    "stars:>500 language:JavaScript topic:webapp archived:false",
  ];
  const seen = new Map();
  for (const q of queries) {
    for (let page = 1; page <= 5 && seen.size < limit * 2; page++) {
      let out;
      try {
        out = gh(`search/repositories?q=${encodeURIComponent(q)}&sort=stars&order=desc&per_page=100&page=${page}`,
          ".items[] | {full_name, default_branch, stargazers_count}");
      } catch (e) { log(`search failed (${q} p${page}): ${e.message.split("\n")[0]}`); break; }
      const rows = out.trim().split("\n").filter(Boolean).map((l) => JSON.parse(l));
      if (!rows.length) break;
      for (const r of rows) if (!seen.has(r.full_name)) seen.set(r.full_name, r);
    }
  }
  const list = [...seen.values()].sort((a, b) => b.stargazers_count - a.stargazers_count);
  fs.writeFileSync(cachePath, JSON.stringify(list));
  log(`discovered ${list.length} candidate repositories`);
  return list.slice(0, limit);
}

async function raw(full, branch, file) {
  const url = `https://raw.githubusercontent.com/${full}/${branch}/${file}`;
  const res = await fetch(url);
  if (!res.ok) return null;
  return await res.text();
}

// ---------------------------------------------------------------------------
// Lockfile parsing -- names only; versions are irrelevant to "is it present"
// ---------------------------------------------------------------------------

function parsePackageLock(text) {
  const doc = JSON.parse(text);
  const names = new Set();
  const prod = new Set();
  if (doc.packages) {                       // lockfileVersion 2/3
    for (const [key, meta] of Object.entries(doc.packages)) {
      if (!key) continue;                   // "" is the root project
      const i = key.lastIndexOf("node_modules/");
      if (i === -1) continue;
      const name = key.slice(i + "node_modules/".length);
      names.add(name);
      // npm marks dev-only packages; everything else ships to production.
      if (meta && meta.dev !== true) prod.add(name);
    }
    names.prod = prod;
  }
  const walk = (deps) => {                  // lockfileVersion 1
    for (const [n, v] of Object.entries(deps || {})) {
      names.add(n);
      if (v && v.dependencies) walk(v.dependencies);
    }
  };
  if (doc.dependencies && !doc.packages) walk(doc.dependencies);
  return names;
}

/**
 * pnpm lockfiles carry everything needed to separate production from dev:
 *   importers:  per-workspace `dependencies` / `devDependencies` / `optionalDependencies`
 *   snapshots:  (v9) resolution edges, `name@version` -> its own dependencies
 *               (v6 and earlier keep the edges under `packages:` with a leading `/`)
 *
 * Production roots are the union of every workspace's `dependencies` and
 * `optionalDependencies`. Union semantics are deliberate: in a monorepo a package
 * that is a devDependency of one workspace and a runtime dependency of another
 * genuinely ships, so it must count as production. This slightly over-counts
 * (a workspace that is itself only a dev tool still contributes its runtime
 * deps), which keeps the production figure conservative in the safe direction.
 *
 * `link:` entries point at sibling workspaces rather than registry packages;
 * they are skipped, and the target workspace contributes its own roots anyway.
 */
function pnpmKeyName(key) {
  let k = key.startsWith("/") ? key.slice(1) : key;
  const paren = k.indexOf("(");
  if (paren !== -1) k = k.slice(0, paren);          // drop peer-dep suffix
  const at = k.lastIndexOf("@");
  return at > 0 ? k.slice(0, at) : null;
}

function parsePnpmLock(text) {
  const YAML = require("yaml");
  const doc = YAML.parse(text, { maxAliasCount: -1 });
  const names = new Set();
  if (!doc || typeof doc !== "object") return names;

  const edges = doc.snapshots || doc.packages || {};
  for (const key of Object.keys(edges)) {
    const n = pnpmKeyName(key);
    if (n) names.add(n);
  }

  // Index bare `name@version` -> full snapshot key, since a dependency may be
  // recorded without the peer suffix that the snapshot key carries.
  const index = new Map();
  for (const key of Object.keys(edges)) {
    const bare = (key.startsWith("/") ? key.slice(1) : key).split("(")[0];
    if (!index.has(bare)) index.set(bare, key);
  }
  /**
   * Resolve a dependency entry to (real installed name, snapshot key).
   *
   * pnpm records an aliased dependency by putting the REAL package in the value:
   *   string-width-cjs: string-width@4.2.3      (v9 form)
   *   some-alias: npm:real-pkg@1.2.3            (npm: form)
   * The key is only the import specifier; the installed package -- and the only
   * thing that appears in the snapshot keys -- is the real one. A plain entry is
   * just a version (`4.2.3`), possibly with a peer suffix (`18.2.0(react@18.2.0)`),
   * so the peer suffix must be stripped BEFORE testing for an alias, or the `@`
   * inside the parentheses is mistaken for one.
   */
  const resolve = (name, version) => {
    let v = String(version);
    if (v.startsWith("npm:")) v = v.slice(4);
    const paren = v.indexOf("(");
    const core = paren === -1 ? v : v.slice(0, paren);
    const at = core.lastIndexOf("@");
    let real = name, ver = core;
    if (at > 0) { real = core.slice(0, at); ver = core.slice(at + 1); }
    return { real, key: index.get(`${real}@${ver}`) || null };
  };

  const roots = [];
  for (const imp of Object.values(doc.importers || {})) {
    if (!imp) continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, spec] of Object.entries(imp[field] || {})) {
        const v = spec && typeof spec === "object" ? spec.version : spec;
        if (!v || String(v).startsWith("link:") || String(v).startsWith("file:")) continue;
        roots.push([n, v]);
      }
    }
  }

  // No importers section => cannot separate; report all names, no prod set.
  if (!doc.importers) return names;

  const prod = new Set();
  const seenKeys = new Set();
  const stack = [];
  for (const [n, v] of roots) {
    const { real, key } = resolve(n, v);
    prod.add(real);
    if (key && !seenKeys.has(key)) { seenKeys.add(key); stack.push(key); }
  }
  while (stack.length) {
    const key = stack.pop();
    const entry = edges[key];
    if (!entry || typeof entry !== "object") continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, v] of Object.entries(entry[field] || {})) {
        if (!v || String(v).startsWith("link:")) continue;
        const { real, key: k } = resolve(n, v);
        prod.add(real);
        if (k && !seenKeys.has(k)) { seenKeys.add(k); stack.push(k); }
      }
    }
  }
  names.prod = prod;
  // Workspace shape is a population signal, not a dependency fact: a repo whose
  // workspaces are mostly `packages/*` is a library monorepo, which passes the
  // `private: true` application filter but is not an application.
  const imps = Object.keys(doc.importers || {});
  const pkgs = imps.filter((k) => /^packages\//.test(k)).length;
  const appDirs = imps.filter((k) => /^(apps|examples|www|docs|web|site|playground)\//.test(k)).length;
  names.shape = imps.length <= 1 ? "single-workspace"
    : pkgs > appDirs ? "library-monorepo" : "app-style";
  return names;
}

function parseYarnLock(text) {
  const names = new Set();
  for (const line of text.split("\n")) {
    if (!line || /^\s/.test(line) || line.startsWith("#")) continue;
    // `foo@^1.0.0, foo@^1.2.0:`  or  `"@scope/foo@^1.0.0":`
    for (const spec of line.replace(/:\s*$/, "").split(",")) {
      const s = spec.trim().replace(/^"|"$/g, "");
      if (!s) continue;
      const at = s.lastIndexOf("@");
      if (at > 0) names.add(s.slice(0, at));
    }
  }
  return names;
}

function parseLock(file, text) {
  if (file === "package-lock.json" || file === "npm-shrinkwrap.json") return parsePackageLock(text);
  if (file === "pnpm-lock.yaml") return parsePnpmLock(text);
  if (file === "yarn.lock") return parseYarnLock(text);
  return new Set();
}

// ---------------------------------------------------------------------------

/**
 * Application, or published library?
 *
 * `private: true` is the strongest signal a package is not published. Absent
 * that, the lack of any publishing entry point (main/module/exports/bin) is a
 * decent proxy. Repos that look like libraries are rejected and recorded.
 */
function classify(pkg) {
  if (!pkg) return { app: false, reason: "no root package.json" };
  if (pkg.private === true) return { app: true, reason: "private: true" };
  const publishes = pkg.main || pkg.module || pkg.exports || pkg.bin || pkg.types;
  if (!publishes) return { app: true, reason: "no publishing entry point" };
  return { app: false, reason: "looks like a published library" };
}

async function main() {
  fs.mkdirSync(LOCKS, { recursive: true });
  fs.mkdirSync(RESULTS, { recursive: true });
  const limitArg = process.argv.indexOf("--limit");
  const limit = limitArg !== -1 ? Number(process.argv[limitArg + 1]) : 250;
  const reposArg = process.argv.indexOf("--repos");
  const outArg = process.argv.indexOf("--out");
  const outName = outArg !== -1 ? process.argv[outArg + 1] : "app-lockfiles.json";

  // An externally curated repo list (see selfhosted-population.js) removes our
  // own app-vs-library classification from the loop entirely.
  const candidates = reposArg !== -1
    ? JSON.parse(fs.readFileSync(path.resolve(process.argv[reposArg + 1]), "utf8")).slice(0, limit)
    : discover(limit);
  const curated = reposArg !== -1;
  log(`examining ${candidates.length} repositories`);

  const analysed = [];
  const rejected = [];
  let next = 0, done = 0;

  await Promise.all(Array.from({ length: CONCURRENCY }, async () => {
    while (next < candidates.length) {
      const repo = candidates[next++];
      const full = repo.full_name;
      const branch = repo.default_branch || "main";
      try {
        const pkgText = await raw(full, branch, "package.json");
        let pkg = null;
        try { pkg = pkgText ? JSON.parse(pkgText) : null; } catch {}
        const cls = curated
          ? { app: true, reason: "curated population (awesome-selfhosted)" }
          : classify(pkg);
        if (!cls.app) { rejected.push({ repo: full, reason: cls.reason }); continue; }

        // Find whichever lockfile the project committed.
        let lockName = null, lockText = null;
        for (const f of LOCKFILES) {
          const cached = path.join(LOCKS, `${full.replace("/", "+")}.${f}`);
          if (fs.existsSync(cached)) { lockName = f; lockText = fs.readFileSync(cached, "utf8"); break; }
          const t = await raw(full, branch, f);
          if (t) { lockName = f; lockText = t; fs.writeFileSync(cached, t); break; }
        }
        if (!lockName) { rejected.push({ repo: full, reason: "no committed lockfile" }); continue; }

        let names;
        try { names = parseLock(lockName, lockText); }
        catch (e) { rejected.push({ repo: full, reason: `lockfile parse failed: ${e.message}` }); continue; }
        if (names.size === 0) { rejected.push({ repo: full, reason: `lockfile parsed to 0 packages (${lockName})` }); continue; }

        const found = [...names].filter((n) => PATCHERS[n]);
        // package-lock v2/v3 flags dev-only packages, so we can isolate the
        // production tree -- what actually ships. Other lockfile formats do
        // not carry that information, recorded here rather than guessed at.
        const prod = names.prod || null;
        const shape = names.shape || null;
        const foundProd = prod ? [...prod].filter((n) => PATCHERS[n]) : null;
        analysed.push({
          repo: full, stars: repo.stargazers_count, lockfile: lockName,
          resolvedPackages: names.size,
          productionPackages: prod ? prod.size : null,
          devDistinctionAvailable: Boolean(prod),
          workspaceShape: shape,
          appType: cls.reason,
          patchers: found.map((p) => ({ package: p, tier: PATCHERS[p] })),
          primaryPatchers: found.filter((p) => PRIMARY.has(p)),
          productionPatchers: foundProd ? foundProd.map((p) => ({ package: p, tier: PATCHERS[p] })) : null,
          productionPrimaryPatchers: foundProd ? foundProd.filter((p) => PRIMARY.has(p)) : null,
        });
      } catch (e) {
        rejected.push({ repo: full, reason: `error: ${String(e.message).split("\n")[0]}` });
      } finally {
        if (++done % 25 === 0) log(`  ${done}/${candidates.length} examined, ${analysed.length} apps`);
      }
    }
  }));

  analysed.sort((a, b) => b.stars - a.stars);

  const withAny = analysed.filter((a) => a.patchers.length);
  const withPrimary = analysed.filter((a) => a.primaryPatchers.length);
  const withCoreJs = analysed.filter((a) => a.patchers.some((p) => p.package.startsWith("core-js")));
  const devAware = analysed.filter((a) => a.devDistinctionAvailable);
  const prodPrimary = devAware.filter((a) => a.productionPrimaryPatchers.length);

  const tally = {};
  for (const a of analysed) for (const p of a.patchers) tally[p.package] = (tally[p.package] || 0) + 1;

  const out = {
    generated: new Date().toISOString().slice(0, 10),
    question: "Do real deployed open-source applications have a builtin-mutating package in their resolved dependency tree?",
    method: {
      selection: curated
        ? "externally curated: non-archived Node.js/JS/TS entries of the awesome-selfhosted catalogue. Removes our own app-vs-library classification, which proved unreliable (a GitHub-topic classifier left 72% of repos unclassified, and 58 of 126 search-selected repos were library monorepos)."
        : "GitHub search for popular JS/TS repositories, filtered to applications (committed lockfile, plus `private: true` or no publishing entry point). Systematic, not curated; all rejects recorded.",
      population: curated ? "self-hosted applications (awesome-selfhosted)" : "popular GitHub JS/TS repositories",
      resolution: "committed lockfiles give the FULLY RESOLVED tree -- no version-range approximation, unlike the name-level graphs used elsewhere in this study",
      execution: "none; lockfiles parsed as data",
      caveat: "popular GitHub repos over-represent developer tooling, demos and self-hosted software relative to commercial web applications; it is a better proxy than npm download rank, not an unbiased sample",
    },
    counts: {
      candidatesExamined: candidates.length,
      applicationsAnalysed: analysed.length,
      rejected: rejected.length,
      withAnyPatcher: withAny.length,
      withPrimaryPatcher: withPrimary.length,
      withCoreJs: withCoreJs.length,
      devAwareLockfiles: devAware.length,
      withPrimaryInProductionTree: prodPrimary.length,
      pctPrimaryInProductionTree: devAware.length ? +((prodPrimary.length / devAware.length) * 100).toFixed(1) : null,
      pctWithAnyPatcher: analysed.length ? +((withAny.length / analysed.length) * 100).toFixed(1) : null,
      pctWithCoreJs: analysed.length ? +((withCoreJs.length / analysed.length) * 100).toFixed(1) : null,
    },
    patcherFrequency: Object.entries(tally).sort((a, b) => b[1] - a[1])
      .map(([pkg, n]) => ({ package: pkg, apps: n, evidence: PATCHERS[pkg],
        pct: analysed.length ? +((n / analysed.length) * 100).toFixed(1) : null })),
    rejectionReasons: Object.entries(
      rejected.reduce((m, r) => { const k = r.reason.replace(/:.*/, ""); m[k] = (m[k] || 0) + 1; return m; }, {})
    ).sort((a, b) => b[1] - a[1]),
    applications: analysed,
    rejected,
  };

  fs.writeFileSync(path.join(RESULTS, outName), JSON.stringify(out, null, 2) + "\n");
  log(`wrote results/${outName}`);

  console.log(`\napplications analysed: ${analysed.length} (from ${candidates.length} candidates)`);
  console.log(`with ANY builtin patcher:    ${withAny.length} (${out.counts.pctWithAnyPatcher}%)`);
  console.log(`with core-js specifically:   ${withCoreJs.length} (${out.counts.pctWithCoreJs}%)`);
  console.log(`\nimport-time patcher (any tree):   ${withPrimary.length}/${analysed.length}`);
  console.log(`import-time in PRODUCTION tree:   ${prodPrimary.length}/${devAware.length} (dev-aware lockfiles only)`);
  console.log("\nmost common patchers:");
  for (const p of out.patcherFrequency.slice(0, 10)) {
    console.log(`  ${p.package.padEnd(26)} ${String(p.apps).padStart(4)} apps (${p.pct}%)  [${p.evidence}]`);
  }
}

// Only run as a CLI -- importing must not kick off a 250-repository crawl.
if (require.main === module) {
  main().catch((e) => { console.error("[locks] FAILED:", e); process.exit(1); });
}

module.exports = { parsePackageLock, parsePnpmLock, parseYarnLock, pnpmKeyName, classify, PATCHERS };
