#!/usr/bin/env node
/**
 * Build the study population: the top N npm packages by weekly downloads.
 *
 * The output of this script is the
 * frozen input to every later stage of the scan.
 *
 * Three stages:
 *   1. ENUMERATE  Read every package name in the registry from a pinned,
 *                 immutable snapshot (download-counts@SEED_VERSION). npm has no
 *                 "top N by downloads" endpoint, and the registry search API is
 *                 keyword-scoped, so a static dump is the only way to get a
 *                 global candidate list. Used ORDINALLY only -- to decide who to
 *                 consider, never as a published figure.
 *   2. RESCORE    Re-score the top SEED_SIZE candidates against npm's own
 *                 last-week downloads API, then cut at POPULATION_SIZE. These
 *                 are the numbers that get published.
 *   3. RESOLVE    Fetch each survivor's packument for the exact version,
 *                 tarball URL, integrity hash, and repository metadata.
 *
 * Seeding at SEED_SIZE > POPULATION_SIZE gives headroom for rank drift between
 * the snapshot date and the run date. Measured Spearman rho between the March
 * 2026 snapshot and live data over ranks 1-1300 was 0.85, so a 3x seed margin
 * is comfortable.
 *
 * No package code is executed at any point: the seed tarball is read as data,
 * and nothing is ever `npm install`ed or `require`d. (Handoff §8.)
 *
 * Usage:  node scripts/build-population.js
 * Output: results/population-<date>.csv  +  results/population-<date>.meta.json
 */

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

// ---------------------------------------------------------------------------
// Configuration -- every knob that affects the published number lives here.
// ---------------------------------------------------------------------------

/** Pinned immutable snapshot used to enumerate registry package names. */
const SEED_PACKAGE = "download-counts";
const SEED_VERSION = "2.20260301.0";

/** How many candidates to re-score (headroom for drift since the snapshot). */
const SEED_SIZE = 3000;

/** Final population size -- the N in "top N packages". */
const POPULATION_SIZE = 1000;

/** npm's bulk downloads endpoint caps at 128 names and rejects scoped ones. */
const BULK_LIMIT = 100;

const CONCURRENCY = 12;

/**
 * api.npmjs.org (downloads) rate-limits far more aggressively than
 * registry.npmjs.org (packuments). Measured empirically: 13 sequential requests
 * succeeded in 7.5s before a 429, i.e. a sustained ceiling near 1.7 req/s, and
 * the 429 carries `Retry-After: 0` (useless as a backoff hint). Scoped packages
 * cannot be batched -- one request each -- so this stage is rate-limited
 * globally rather than merely concurrency-capped. Expect ~10-15 minutes for a
 * cold run; results are cached, so it is a one-time cost.
 */
const DOWNLOADS_RATE_PER_SEC = 1.4;

const MAX_RETRIES = 8;

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const RESULTS = path.join(ROOT, "results");

const SNAPSHOT_DATE = new Date().toISOString().slice(0, 10);

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

const log = (...a) => console.error("[population]", ...a);

function readJSON(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data));
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Global minimum-interval gate shared by every worker hitting one host.
 *
 * Concurrency caps alone do not bound request *rate*, which is what the
 * downloads API actually limits. On a 429 the limiter both pauses and
 * permanently slows its interval, so a run adapts to whatever the server is
 * willing to serve instead of repeatedly rediscovering the ceiling.
 */
class RateLimiter {
  constructor(ratePerSec) {
    this.interval = 1000 / ratePerSec;
    this.nextSlot = 0;
  }
  async take() {
    const now = Date.now();
    const slot = Math.max(now, this.nextSlot);
    this.nextSlot = slot + this.interval;
    if (slot > now) await sleep(slot - now);
  }
  /** Pause all workers for at least `ms`. */
  penalise(ms) {
    this.nextSlot = Math.max(this.nextSlot, Date.now() + ms);
  }
  /** Permanently ease off after a rejection, up to a floor of 0.5 req/s. */
  slowDown() {
    this.interval = Math.min(this.interval * 1.5, 2000);
  }
}

/**
 * GET with retry. Returns null on a hard 404 (package unpublished since the
 * snapshot); throws once retries are exhausted on anything else.
 */
async function getJSON(url, { allow404 = false, limiter = null } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (limiter) await limiter.take();
    let throttled = false;
    let retryAfterMs = null;
    try {
      const res = await fetch(url, {
        headers: { accept: "application/json" },
      });
      if (res.status === 404 && allow404) return null;
      if (res.status === 429 || res.status >= 500) {
        throttled = res.status === 429;
        // npm sends `Retry-After: 0` on 429, which is not a usable hint --
        // only honour a positive value, otherwise fall back to our backoff.
        const secs = Number(res.headers.get("retry-after"));
        if (Number.isFinite(secs) && secs > 0) retryAfterMs = secs * 1000;
        throw new Error(`HTTP ${res.status}`);
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      lastErr = err;
      if (attempt < MAX_RETRIES) {
        // Exponential backoff with jitter, so a pool of workers that all get
        // 429ed at once does not retry in lockstep and 429 again.
        const backoff =
          retryAfterMs ?? Math.min(500 * 2 ** attempt, 30_000);
        const wait = backoff + Math.floor(Math.random() * 250);
        if (limiter && throttled) {
          // Slow every worker, not just this one -- the limit is per-host.
          limiter.slowDown();
          limiter.penalise(wait);
        }
        await sleep(wait);
      }
    }
  }
  throw new Error(`${url}: ${lastErr.message}`);
}

/**
 * Run `worker` over `items` with bounded concurrency, reporting progress.
 *
 * `onProgress` fires periodically so long stages can checkpoint partial work;
 * a rate-limit failure 900 requests in should not discard the first 900.
 */
async function pooled(
  items,
  worker,
  label,
  { concurrency = CONCURRENCY, progressEvery = 250, onProgress = null } = {}
) {
  const out = new Array(items.length);
  const started = Date.now();
  let next = 0;
  let done = 0;
  async function run() {
    while (next < items.length) {
      const i = next++;
      out[i] = await worker(items[i], i);
      done++;
      if (done % progressEvery === 0 || done === items.length) {
        const rate = done / ((Date.now() - started) / 1000);
        const eta = Math.round((items.length - done) / rate);
        log(
          `  ${label}: ${done}/${items.length}` +
            (done < items.length ? ` (${rate.toFixed(1)}/s, ~${eta}s left)` : "")
        );
        if (onProgress) onProgress();
      }
    }
  }
  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, run)
  );
  if (onProgress) onProgress();
  return out;
}

// ---------------------------------------------------------------------------
// Stage 1 -- enumerate candidates from the pinned snapshot
// ---------------------------------------------------------------------------

async function loadSeedCounts() {
  const countsPath = path.join(CACHE, `counts-${SEED_VERSION}.json`);
  if (fs.existsSync(countsPath)) {
    log(`stage 1: using cached ${path.basename(countsPath)}`);
    return readJSON(countsPath);
  }

  const tgz = path.join(CACHE, `${SEED_PACKAGE}-${SEED_VERSION}.tgz`);
  if (!fs.existsSync(tgz)) {
    // Resolve the tarball URL from the packument rather than constructing it:
    // scoped packages drop the scope from the tarball basename.
    const doc = await getJSON(
      `https://registry.npmjs.org/${SEED_PACKAGE}/${SEED_VERSION}`
    );
    log(`stage 1: fetching ${SEED_PACKAGE}@${SEED_VERSION} (~27MB)`);
    const res = await fetch(doc.dist.tarball);
    if (!res.ok) throw new Error(`seed tarball: HTTP ${res.status}`);
    fs.writeFileSync(tgz, Buffer.from(await res.arrayBuffer()));
  }

  // Extract as data only. `tar` never executes package contents; this package
  // has no dependencies and no lifecycle scripts (verified against the
  // packument), but we avoid npm install / require regardless.
  log("stage 1: extracting counts.json");
  execFileSync("tar", ["xzf", tgz, "-C", CACHE, "package/counts.json"]);
  fs.renameSync(path.join(CACHE, "package", "counts.json"), countsPath);
  fs.rmSync(path.join(CACHE, "package"), { recursive: true, force: true });

  return readJSON(countsPath);
}

// ---------------------------------------------------------------------------
// Stage 2 -- re-score candidates against npm's live downloads API
// ---------------------------------------------------------------------------

async function fetchLiveDownloads(names) {
  const cachePath = path.join(CACHE, `live-downloads-${SNAPSHOT_DATE}.json`);
  if (fs.existsSync(cachePath)) {
    log("stage 2: using cached live download counts");
    return readJSON(cachePath);
  }

  // Partial progress from an earlier interrupted run, if any.
  const partialPath = path.join(CACHE, `live-downloads-${SNAPSHOT_DATE}.partial.json`);
  const counts = fs.existsSync(partialPath) ? readJSON(partialPath) : {};
  const resumed = Object.keys(counts).length;
  if (resumed) log(`stage 2: resuming with ${resumed} counts already fetched`);
  const checkpoint = () => writeJSON(partialPath, counts);
  const limiter = new RateLimiter(DOWNLOADS_RATE_PER_SEC);

  const pending = names.filter((n) => !(n in counts));
  const unscoped = pending.filter((n) => !n.startsWith("@"));
  const scoped = pending.filter((n) => n.startsWith("@"));
  log(`stage 2: ${unscoped.length} unscoped (bulk), ${scoped.length} scoped (individual)`);

  // Bulk endpoint: up to BULK_LIMIT names per call, unscoped only.
  const batches = [];
  for (let i = 0; i < unscoped.length; i += BULK_LIMIT) {
    batches.push(unscoped.slice(i, i + BULK_LIMIT));
  }
  await pooled(
    batches,
    async (batch) => {
      const url =
        "https://api.npmjs.org/downloads/point/last-week/" + batch.join(",");
      const res = await getJSON(url, { limiter });
      for (const [name, entry] of Object.entries(res || {})) {
        // Unknown names come back as null rather than being omitted.
        if (entry && typeof entry === "object") {
          counts[name] = entry.downloads ?? 0;
        }
      }
    },
    "bulk batches",
    { concurrency: 4, progressEvery: 10, onProgress: checkpoint }
  );
  checkpoint();

  // Scoped packages are rejected by bulk lookups -- one request each.
  await pooled(
    scoped,
    async (name) => {
      const url =
        "https://api.npmjs.org/downloads/point/last-week/" +
        encodeURIComponent(name);
      const res = await getJSON(url, { allow404: true, limiter });
      if (res && typeof res.downloads === "number") counts[name] = res.downloads;
    },
    "scoped lookups",
    { concurrency: 4, progressEvery: 100, onProgress: checkpoint }
  );

  writeJSON(cachePath, counts);
  fs.rmSync(partialPath, { force: true });
  return counts;
}

// ---------------------------------------------------------------------------
// Stage 3 -- resolve version, tarball, integrity, repository
// ---------------------------------------------------------------------------

/** Normalise the many shapes of packument `repository` into a plain URL. */
function normaliseRepo(repository) {
  if (!repository) return "";
  const raw =
    typeof repository === "string" ? repository : repository.url || "";
  return raw
    .replace(/^git\+/, "")
    .replace(/^git:\/\//, "https://")
    .replace(/^ssh:\/\/git@/, "https://")
    .replace(/^git@([^:]+):/, "https://$1/")
    .replace(/\.git$/, "");
}

async function resolveManifests(names) {
  const cachePath = path.join(CACHE, `manifests-${SNAPSHOT_DATE}.json`);
  if (fs.existsSync(cachePath)) {
    log("stage 3: using cached manifests");
    return readJSON(cachePath);
  }

  const out = await pooled(
    names,
    async (name) => {
      const doc = await getJSON(
        `https://registry.npmjs.org/${name.replace("/", "%2f")}/latest`,
        { allow404: true }
      );
      if (!doc) return { name, missing: true };
      const dist = doc.dist || {};
      const repository = doc.repository || null;
      return {
        name,
        version: doc.version || "",
        tarball: dist.tarball || "",
        integrity: dist.integrity || "",
        shasum: dist.shasum || "",
        unpackedSize: dist.unpackedSize ?? "",
        repository: normaliseRepo(repository),
        // Present when a package lives in a subdirectory of its repo -- an
        // explicit monorepo marker, and the reason repo-based scanning cannot
        // attribute a finding to a single package.
        repoDirectory:
          (repository && typeof repository === "object" && repository.directory) ||
          "",
        deprecated: doc.deprecated ? "yes" : "",
      };
    },
    "manifests"
  );

  writeJSON(cachePath, out);
  return out;
}

// ---------------------------------------------------------------------------
// CSV
// ---------------------------------------------------------------------------

const CSV_COLUMNS = [
  "rank",
  "name",
  "version",
  "weekly_downloads",
  "seed_rank",
  "scoped",
  "repository",
  "repo_directory",
  "is_monorepo",
  "tarball",
  "integrity",
  "shasum",
  "unpacked_size",
  "deprecated",
];

function toCSV(rows) {
  const esc = (v) => {
    const s = v === null || v === undefined ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [CSV_COLUMNS.join(",")];
  for (const r of rows) lines.push(CSV_COLUMNS.map((c) => esc(r[c])).join(","));
  return lines.join("\n") + "\n";
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  fs.mkdirSync(CACHE, { recursive: true });
  fs.mkdirSync(RESULTS, { recursive: true });

  // Stage 1 --------------------------------------------------------------
  const seedCounts = await loadSeedCounts();
  const seedRanked = Object.entries(seedCounts).sort((a, b) => b[1] - a[1]);
  log(
    `stage 1: ${seedRanked.length.toLocaleString()} packages in snapshot; ` +
      `taking top ${SEED_SIZE} as candidates`
  );
  const candidates = seedRanked.slice(0, SEED_SIZE).map(([name], i) => ({
    name,
    seedRank: i + 1,
  }));
  const seedRankOf = new Map(candidates.map((c) => [c.name, c.seedRank]));

  // Stage 2 --------------------------------------------------------------
  const live = await fetchLiveDownloads(candidates.map((c) => c.name));
  const scored = candidates
    .map((c) => ({ ...c, downloads: live[c.name] }))
    .filter((c) => typeof c.downloads === "number" && c.downloads > 0)
    .sort((a, b) => b.downloads - a.downloads);

  const unresolved = candidates.length - scored.length;
  log(
    `stage 2: scored ${scored.length}/${candidates.length} candidates ` +
      `(${unresolved} unresolved/zero)`
  );

  const population = scored.slice(0, POPULATION_SIZE);

  // How much did the cut actually depend on re-scoring? If a package outside
  // the snapshot's own top-POPULATION_SIZE made the final cut, the headroom
  // earned its keep -- worth reporting in the methodology.
  const promoted = population.filter((p) => p.seedRank > POPULATION_SIZE);
  log(
    `stage 2: ${promoted.length} packages promoted into the top ` +
      `${POPULATION_SIZE} by live re-scoring`
  );

  // Stage 3 --------------------------------------------------------------
  const manifests = await resolveManifests(population.map((p) => p.name));
  const manifestOf = new Map(manifests.map((m) => [m.name, m]));

  const missing = manifests.filter((m) => m.missing).map((m) => m.name);
  if (missing.length) log(`stage 3: ${missing.length} packument(s) missing: ${missing.join(", ")}`);

  const rows = population.map((p, i) => {
    const m = manifestOf.get(p.name) || {};
    return {
      rank: i + 1,
      name: p.name,
      version: m.version || "",
      weekly_downloads: p.downloads,
      seed_rank: seedRankOf.get(p.name) ?? "",
      scoped: p.name.startsWith("@") ? "yes" : "",
      repository: m.repository || "",
      repo_directory: m.repoDirectory || "",
      is_monorepo: m.repoDirectory ? "yes" : "",
      tarball: m.tarball || "",
      integrity: m.integrity || "",
      shasum: m.shasum || "",
      unpacked_size: m.unpackedSize ?? "",
      deprecated: m.deprecated || "",
    };
  });

  const csvPath = path.join(RESULTS, `population-${SNAPSHOT_DATE}.csv`);
  fs.writeFileSync(csvPath, toCSV(rows));

  // Methodology sidecar: everything a reviewer needs to reproduce the cut.
  const noRepo = rows.filter((r) => !r.repository).length;
  const monorepo = rows.filter((r) => r.is_monorepo).length;
  const meta = {
    snapshotDate: SNAPSHOT_DATE,
    populationSize: rows.length,
    method: {
      enumeration: `${SEED_PACKAGE}@${SEED_VERSION} (pinned immutable npm artifact, read as data; used ordinally only)`,
      seedSize: SEED_SIZE,
      rescoring:
        "https://api.npmjs.org/downloads/point/last-week/ -- bulk for unscoped, individual for scoped",
      cut: `top ${POPULATION_SIZE} by live weekly downloads`,
      versionResolution:
        "https://registry.npmjs.org/<pkg>/latest as of snapshotDate",
    },
    counts: {
      snapshotPackages: seedRanked.length,
      candidatesScored: scored.length,
      candidatesUnresolved: unresolved,
      promotedByRescoring: promoted.length,
      scopedInPopulation: rows.filter((r) => r.scoped).length,
      missingPackuments: missing.length,
      deprecated: rows.filter((r) => r.deprecated).length,
    },
    repositoryMapping: {
      withRepository: rows.length - noRepo,
      withoutRepository: noRepo,
      monorepoSubdirectory: monorepo,
      note: "is_monorepo reflects an explicit repository.directory field; it is a lower bound, since many monorepo packages omit it.",
    },
    downloadsRange: {
      max: rows[0]?.weekly_downloads ?? null,
      min: rows[rows.length - 1]?.weekly_downloads ?? null,
    },
  };
  const metaPath = path.join(RESULTS, `population-${SNAPSHOT_DATE}.meta.json`);
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2) + "\n");

  log(`wrote ${csvPath}`);
  log(`wrote ${metaPath}`);
  console.log(JSON.stringify(meta, null, 2));
}

main().catch((err) => {
  console.error("[population] FAILED:", err);
  process.exit(1);
});
