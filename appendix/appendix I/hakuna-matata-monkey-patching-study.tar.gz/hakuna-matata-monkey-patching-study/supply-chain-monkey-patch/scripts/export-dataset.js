#!/usr/bin/env node
/**
 * Export the population as a standalone, self-describing dataset artifact.
 *
 * The artifact is deliberately decoupled from the monkey-patch analysis: it is
 * just "the top 1,000 npm packages by weekly downloads, version-pinned, as of
 * a stated date", reusable by any task. It carries its own provenance block so
 * it remains interpretable after it travels away from this repository.
 *
 * Two formats, for two kinds of consumer:
 *   AugTop1K_npm.json  canonical -- full records + provenance. Use this.
 *   AugTop1K_npm.txt   bare package names, one per line, in rank order, for
 *                      shell pipelines. Names only: `name@version` would be
 *                      ambiguous for scoped packages, whose names already
 *                      begin with '@'.
 *
 * Usage:  node scripts/export-dataset.js
 */

const fs = require("node:fs");
const path = require("node:path");
const { parseCSV } = require("./fetch-corpus.js");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const DATASET = "AugTop1K_npm";

const log = (...a) => console.error("[dataset]", ...a);

function latest(pattern) {
  const found = fs.readdirSync(RESULTS).filter((f) => pattern.test(f)).sort();
  if (!found.length) throw new Error(`no file matching ${pattern} in results/`);
  return path.join(RESULTS, found[found.length - 1]);
}

const num = (v) => (v === "" || v == null ? null : Number(v));

function main() {
  const popPath = latest(/^population-\d{4}-\d{2}-\d{2}\.csv$/);
  const metaPath = popPath.replace(/\.csv$/, ".meta.json");
  const rows = parseCSV(fs.readFileSync(popPath, "utf8"));
  const meta = JSON.parse(fs.readFileSync(metaPath, "utf8"));
  log(`source: ${path.basename(popPath)} (${rows.length} packages)`);

  const packages = rows.map((r) => ({
    rank: num(r.rank),
    name: r.name,
    version: r.version,
    weeklyDownloads: num(r.weekly_downloads),
    scoped: r.scoped === "yes",
    repository: r.repository || null,
    repoDirectory: r.repo_directory || null,
    isMonorepo: r.is_monorepo === "yes",
    tarball: r.tarball,
    integrity: r.integrity,
    shasum: r.shasum,
    unpackedSize: num(r.unpacked_size),
    deprecated: r.deprecated === "yes",
  }));

  const artifact = {
    dataset: DATASET,
    version: 1,
    generated: meta.snapshotDate,
    description:
      "The top 1,000 npm packages by weekly downloads as of " +
      `${meta.snapshotDate}, pinned to the version that was 'latest' on that date, ` +
      "with published-tarball URLs and registry integrity hashes.",

    // Provenance travels with the data: a consumer should be able to judge and
    // reproduce this list without access to the repository that built it.
    provenance: {
      ...meta.method,
      note:
        "Package NAMES were enumerated from a pinned immutable npm artifact " +
        "(download-counts) and used ordinally only, to decide which candidates " +
        "to score. Every published download figure comes from npm's own " +
        "last-week API, queried on the generated date. Seeding at " +
        `${meta.method.seedSize} for a ${packages.length}-package cut provided ` +
        "drift headroom; " +
        `${meta.counts.promotedByRescoring} packages in this list ranked outside ` +
        "the seed snapshot's own top 1,000 and would have been missed without it.",
    },

    caveats: [
      "Download counts are a popularity proxy, not usage: CI, mirrors, and bots inflate them.",
      "'Top by downloads' over-represents infrastructure, polyfills, and transitive utility packages.",
      `${meta.counts.deprecated} packages in this list are deprecated but still heavily downloaded as transitive dependencies.`,
      `Only ${meta.repositoryMapping.withRepository} of ${packages.length} declare a repository, and they map to far fewer distinct repositories than packages -- isMonorepo (${meta.repositoryMapping.monorepoSubdirectory} packages) reflects an explicit repository.directory field and is a lower bound.`,
      "Versions are pinned to 'latest' as of the generated date; they are not the only versions in use.",
    ],

    schema: {
      rank: "1-based position by weeklyDownloads, descending",
      name: "npm package name (scoped names begin with '@')",
      version: "version that was 'latest' on the generated date",
      weeklyDownloads: "npm last-week downloads, queried on the generated date",
      scoped: "true if the package name is scoped",
      repository: "normalised repository URL, or null if undeclared",
      repoDirectory: "subdirectory within the repository, when declared (monorepo marker)",
      isMonorepo: "true when repoDirectory is present; a lower bound",
      tarball: "published tarball URL from the registry (dist.tarball)",
      integrity: "registry dist.integrity (SRI, sha512)",
      shasum: "registry dist.shasum (legacy hex sha1)",
      unpackedSize: "bytes, as reported by the registry, or null if unreported",
      deprecated: "true if the package is marked deprecated",
    },

    counts: {
      packages: packages.length,
      scoped: packages.filter((p) => p.scoped).length,
      deprecated: packages.filter((p) => p.deprecated).length,
      withRepository: packages.filter((p) => p.repository).length,
      monorepoSubdirectory: packages.filter((p) => p.isMonorepo).length,
      distinctRepositories: new Set(
        packages.map((p) => p.repository).filter(Boolean)
      ).size,
      weeklyDownloadsMax: packages[0]?.weeklyDownloads ?? null,
      weeklyDownloadsMin: packages[packages.length - 1]?.weeklyDownloads ?? null,
    },

    packages,
  };

  const jsonPath = path.join(ROOT, `${DATASET}.json`);
  const txtPath = path.join(ROOT, `${DATASET}.txt`);
  fs.writeFileSync(jsonPath, JSON.stringify(artifact, null, 2) + "\n");
  fs.writeFileSync(txtPath, packages.map((p) => p.name).join("\n") + "\n");

  log(`wrote ${path.relative(ROOT, jsonPath)}`);
  log(`wrote ${path.relative(ROOT, txtPath)}`);
  console.log(JSON.stringify(artifact.counts, null, 2));
}

main();
