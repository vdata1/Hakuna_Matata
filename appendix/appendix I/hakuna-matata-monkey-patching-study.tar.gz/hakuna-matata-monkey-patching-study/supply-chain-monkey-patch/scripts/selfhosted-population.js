#!/usr/bin/env node
/**
 * Build an application population that does not depend on us classifying
 * anything.
 *
 * Earlier stages tried to separate applications from libraries with the signals
 * available cheaply -- `private: true`, workspace shape, GitHub topics. All were
 * inadequate: 58 of 126 repos selected that way were library monorepos
 * (`angular`, `rxjs`, `nx`), and a topic-keyword classifier left 72% of repos
 * unclassified. Rather than launder a guess into a denominator, we take the
 * population from an **externally curated** source.
 *
 * `awesome-selfhosted` is a community-maintained catalogue of self-hosted
 * applications, with machine-readable per-entry metadata (platform tags,
 * archived flag, source URL). Taking its non-archived Node.js/JS/TS entries
 * gives a population that is:
 *   - unambiguously applications (deployable services, not libraries),
 *   - curated by someone other than us, so the selection is not ours to bias,
 *   - reproducible and citable.
 *
 * Known bias, to be stated: self-hosted open-source software over-represents
 * developer and infrastructure tooling relative to consumer web applications,
 * and under-represents commercial SaaS front-ends entirely.
 *
 * Usage:  node scripts/selfhosted-population.js
 * Output: cache/selfhosted-repos.json  [{ full_name, default_branch, stargazers_count }]
 */

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
const YAML = require("yaml");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const SRC = "https://codeload.github.com/awesome-selfhosted/awesome-selfhosted-data/tar.gz/refs/heads/master";
const JS_PLATFORMS = new Set(["Nodejs", "Node.js", "JavaScript", "TypeScript", "Deno", "Bun"]);
const CONCURRENCY = 8;

const log = (...a) => console.error("[selfhosted]", ...a);

async function main() {
  fs.mkdirSync(CACHE, { recursive: true });
  const dir = path.join(CACHE, "awesome-selfhosted");

  if (!fs.existsSync(dir)) {
    log("fetching awesome-selfhosted-data");
    const tgz = path.join(CACHE, "awesome-selfhosted.tgz");
    const res = await fetch(SRC);
    if (!res.ok) throw new Error(`catalogue fetch: HTTP ${res.status}`);
    fs.writeFileSync(tgz, Buffer.from(await res.arrayBuffer()));
    fs.mkdirSync(dir, { recursive: true });
    execFileSync("tar", ["xzf", tgz, "-C", dir, "--strip-components=1"],
      { stdio: ["ignore", "ignore", "pipe"] });
  }

  const files = fs.readdirSync(path.join(dir, "software")).filter((f) => f.endsWith(".yml"));
  log(`catalogue entries: ${files.length}`);

  const picked = [];
  const skipped = { notJs: 0, archived: 0, noGithub: 0, unparsed: 0 };
  for (const f of files) {
    let doc;
    try { doc = YAML.parse(fs.readFileSync(path.join(dir, "software", f), "utf8")); }
    catch { skipped.unparsed++; continue; }
    if (!doc) { skipped.unparsed++; continue; }
    const platforms = (doc.platforms || []).map(String);
    if (!platforms.some((p) => JS_PLATFORMS.has(p))) { skipped.notJs++; continue; }
    if (doc.archived === true) { skipped.archived++; continue; }
    const url = String(doc.source_code_url || "");
    const m = /^https?:\/\/github\.com\/([^/]+\/[^/#?]+)/.exec(url);
    if (!m) { skipped.noGithub++; continue; }
    picked.push({
      full_name: m[1].replace(/\.git$/, ""),
      stargazers_count: Number(doc.stargazers_count) || 0,
      catalogueName: doc.name || null,
      platforms,
    });
  }
  log(`JS/TS, non-archived, on GitHub: ${picked.length}`);
  log(`skipped -> ${JSON.stringify(skipped)}`);

  // Default branch is needed to fetch raw files; resolve it per repo.
  log("resolving default branches");
  let next = 0, done = 0;
  const resolved = [];
  await Promise.all(Array.from({ length: CONCURRENCY }, async () => {
    while (next < picked.length) {
      const r = picked[next++];
      try {
        const out = execFileSync("gh", ["api", `repos/${r.full_name}`, "--jq",
          "{default_branch, stargazers_count, archived}"], { encoding: "utf8" });
        const j = JSON.parse(out);
        if (!j.archived) {
          resolved.push({ ...r, default_branch: j.default_branch,
                          stargazers_count: j.stargazers_count ?? r.stargazers_count });
        }
      } catch { /* repo moved, renamed or deleted -- dropped, counted below */ }
      if (++done % 50 === 0) log(`  ${done}/${picked.length}`);
    }
  }));

  resolved.sort((a, b) => b.stargazers_count - a.stargazers_count);
  const outPath = path.join(CACHE, "selfhosted-repos.json");
  fs.writeFileSync(outPath, JSON.stringify(resolved, null, 1));
  log(`resolved ${resolved.length} repos (${picked.length - resolved.length} unreachable/archived)`);
  log(`wrote ${path.relative(ROOT, outPath)}`);
  console.log(JSON.stringify({ catalogueEntries: files.length, jsCandidates: picked.length,
    resolved: resolved.length, skipped }, null, 2));
}

if (require.main === module) main().catch((e) => { console.error("[selfhosted] FAILED:", e); process.exit(1); });
