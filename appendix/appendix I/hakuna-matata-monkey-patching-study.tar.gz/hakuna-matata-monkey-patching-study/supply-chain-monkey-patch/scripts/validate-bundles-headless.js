#!/usr/bin/env node
/**
 * Experiment 2, Arm B -- VALIDATION of the static crawl (fetch-bundles.js).
 *
 * The static crawl only sees scripts referenced by the initial HTML. It cannot
 * see runtime-injected scripts or lazy/route-split chunks, so its prevalence is
 * a lower bound. This script quantifies that undercount on a SMALL SAMPLE by
 * driving a real headless browser and capturing every JavaScript response the
 * page actually loads -- then diffing that set against what the static crawl
 * collected for the same domains.
 *
 * This is the ONLY part of Experiment 2 that executes site code (inside a
 * sandboxed headless Chromium). It is intentionally scoped to a small sample
 * (default 40 domains) so the browser dependency never touches the main run.
 *
 * PREREQUISITE (not installed by default -- keeps the main pipeline browser-free):
 *     npm i -D playwright && npx playwright install chromium
 *
 * Usage:  node scripts/validate-bundles-headless.js
 *             [--list cache/tranco-top1000-PYG5J.csv] [--sample 40]
 *             [--static results/bundles.json] [--out results/bundles-headless.json]
 *
 * Method per domain:
 *   1. Launch headless Chromium, navigate to https://<domain>/, wait for
 *      networkidle (bounded by a timeout).
 *   2. Record the URL + sha256 of every response whose content-type is
 *      JavaScript (or whose URL ends .mjs/.js). Bodies are content-addressed
 *      into cache/bundles/<sha>.js -- same store the scanner reads, so headless-
 *      only assets get scanned too.
 *   3. Compare per-domain: assets seen by headless vs by the static crawl.
 *
 * Output: the headless asset set per domain, plus an undercount summary:
 *   - domains where headless found JS the static crawl missed
 *   - count of headless-only assets (the lower-bound gap)
 * The decision this informs: if headless-only assets rarely add NEW builtin-
 * modification hits (checked downstream by the scanner), the static crawl is
 * validated as sufficient and the browser is not needed for the full corpus.
 */

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const BUNDLES = path.join(CACHE, "bundles");
const RESULTS = path.join(ROOT, "results");

const NAV_TIMEOUT_MS = 30000;
const IDLE_TIMEOUT_MS = 8000; // extra settle time after load for lazy chunks
const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const log = (...a) => console.error("[headless]", ...a);

function arg(flag, def) {
  const i = process.argv.indexOf(flag);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}

function loadSiteList(file, n) {
  return fs
    .readFileSync(file, "utf8")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => l.split(",").pop().trim())
    .slice(0, n);
}

const isJs = (url, ctype) =>
  /javascript|ecmascript|module/i.test(ctype || "") || /\.m?js(\?|#|$)/i.test(url);

async function main() {
  let chromium;
  try {
    ({ chromium } = require("playwright"));
  } catch {
    log("playwright is not installed. This validation step is intentionally");
    log("decoupled from the main (browser-free) pipeline. To run it:");
    log("    npm i -D playwright && npx playwright install chromium");
    process.exit(2);
  }

  fs.mkdirSync(BUNDLES, { recursive: true });
  const listFile = path.resolve(arg("--list", path.join(CACHE, "tranco-top1000-PYG5J.csv")));
  const sample = Number(arg("--sample", "40"));
  const staticPath = path.resolve(arg("--static", path.join(RESULTS, "bundles.json")));
  const outPath = path.resolve(arg("--out", path.join(RESULTS, "bundles-headless.json")));

  const domains = loadSiteList(listFile, sample);

  // static-crawl asset URLs per domain, for the diff
  const staticByDomain = {};
  if (fs.existsSync(staticPath)) {
    const sm = JSON.parse(fs.readFileSync(staticPath, "utf8"));
    for (const d of sm.domains || []) {
      staticByDomain[d.domain] = new Set(
        (d.assets || []).filter((a) => a.status === "ok").map((a) => a.sha)
      );
    }
  } else {
    log(`warning: ${path.basename(staticPath)} not found; running without a static diff`);
  }

  const browser = await chromium.launch({ headless: true });
  const results = [];

  for (const domain of domains) {
    const rec = { domain, status: "ok", assets: [] };
    const ctx = await browser.newContext({ userAgent: UA });
    const page = await ctx.newPage();
    const seen = new Map(); // url -> {sha, bytes, ctype}

    page.on("response", async (res) => {
      try {
        const url = res.url();
        const ctype = res.headers()["content-type"] || "";
        if (!isJs(url, ctype)) return;
        const buf = await res.body();
        if (!buf || !buf.length) return;
        const sha = crypto.createHash("sha256").update(buf).digest("hex");
        const file = path.join(BUNDLES, `${sha}.js`);
        if (!fs.existsSync(file)) fs.writeFileSync(file, buf);
        seen.set(url, { sha, bytes: buf.length, ctype });
      } catch {
        /* body unavailable (redirect, cached, cross-origin opaque) -- skip */
      }
    });

    try {
      await page.goto(`https://${domain}/`, { waitUntil: "load", timeout: NAV_TIMEOUT_MS });
      await page.waitForLoadState("networkidle", { timeout: IDLE_TIMEOUT_MS }).catch(() => {});
    } catch (err) {
      rec.status = "nav-failed";
      rec.error = String(err.message || err).split("\n")[0];
    }
    await ctx.close();

    for (const [url, v] of seen) rec.assets.push({ url, ...v });
    const headlessShas = new Set(rec.assets.map((a) => a.sha));
    const staticShas = staticByDomain[domain] || new Set();
    rec.headlessOnly = [...headlessShas].filter((s) => !staticShas.has(s)).length;
    rec.staticCount = staticShas.size;
    rec.headlessCount = headlessShas.size;
    results.push(rec);
    log(`${domain}: headless=${rec.headlessCount} static=${rec.staticCount} headless-only=${rec.headlessOnly} ${rec.status}`);
  }

  await browser.close();

  const summary = {
    generated: new Date().toISOString().slice(0, 10),
    sample: results.length,
    static: path.basename(staticPath),
    counts: {
      domainsWithHeadlessOnlyAssets: results.filter((r) => r.headlessOnly > 0).length,
      totalHeadlessOnlyAssets: results.reduce((n, r) => n + r.headlessOnly, 0),
      totalHeadlessAssets: results.reduce((n, r) => n + r.headlessCount, 0),
    },
    note:
      "headless-only assets are what the static crawl missed. Scan cache/bundles for " +
      "builtin-modification hits and check whether headless-only shas add NEW hits: if " +
      "they rarely do, the static crawl is validated as sufficient for the full corpus.",
    domains: results,
  };
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2) + "\n");
  log("summary:", JSON.stringify(summary.counts));
  log(`wrote ${outPath}`);
  console.log(JSON.stringify(summary.counts, null, 2));
}

if (require.main === module) {
  main().catch((err) => {
    console.error("[headless] FAILED:", err);
    process.exit(1);
  });
}
