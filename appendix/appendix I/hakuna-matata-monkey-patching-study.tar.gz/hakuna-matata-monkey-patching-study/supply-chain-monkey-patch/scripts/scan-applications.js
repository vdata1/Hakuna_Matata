#!/usr/bin/env node
/**
 * Do real applications ship a builtin-mutating package to production?
 *
 * Supersedes app-lockfiles.js, fixing its two known selection defects:
 *
 *   1. ROOT-ONLY LOOKUP. The old version only looked for a lockfile at the
 *      repository root, so an application whose JS project lives in a
 *      subdirectory was dropped entirely. Confirmed loss: `blakeblackshear/frigate`
 *      was excluded on an empty root lockfile while carrying a real
 *      `web/package-lock.json`. This version walks the full tree.
 *   2. YARN EXCLUDED. Neither yarn variant marks dev-only packages, so yarn
 *      repositories could not contribute a production figure. Roots are now
 *      taken from the repository's own package.json files, which the recursive
 *      tree gives us anyway, and the lockfile supplies the edges.
 *
 * A repository may legitimately contain several lockfiles (a separate frontend
 * and backend, say). All are parsed and their production sets unioned: every one
 * of them ships. Manifests are scoped to each lockfile's own subtree, so a
 * `web/` lockfile is rooted in `web/`'s package.json files rather than the whole
 * repository's.
 *
 * Nothing is executed and nothing is installed; lockfiles and manifests are
 * parsed as data.
 *
 * Usage:  node scripts/scan-applications.js --repos cache/selfhosted-repos.json
 *                                           [--limit N] [--out app-scan.json]
 */

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
const { parseLock, isBerry } = require("./lockfiles.js");
const { PATCHERS } = require("./app-lockfiles.js");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const TREES = path.join(CACHE, "trees");
const FILES = path.join(CACHE, "repo-files");
const RESULTS = path.join(ROOT, "results");

const CONCURRENCY = 6;
const MAX_LOCKFILES = 12;
const MAX_MANIFESTS = 60;

const PRIMARY = new Set(Object.keys(PATCHERS).filter((k) => PATCHERS[k] === "importTime"));
const LOCK_RE = /(^|\/)(package-lock\.json|npm-shrinkwrap\.json|pnpm-lock\.yaml|yarn\.lock)$/;

/**
 * Paths excluded from both lockfile and manifest discovery. These are not the
 * deployed application: vendored dependencies, test fixtures, example projects,
 * and documentation sites all carry their own manifests and would inflate the
 * production tree with things the application never ships.
 */
const EXCLUDED = /(^|\/)(node_modules|\.git|\.yarn|fixtures?|__fixtures__|__tests__|__mocks__|tests?|e2e|cypress|examples?|demos?|docs|website|benchmarks?|sandbox|playground)(\/|$)/i;

const log = (...a) => console.error("[apps]", ...a);

const gh = (endpoint, jq) =>
  execFileSync("gh", jq ? ["api", endpoint, "--jq", jq] : ["api", endpoint],
    { encoding: "utf8", maxBuffer: 128 * 1024 * 1024 });

async function raw(full, branch, file) {
  const res = await fetch(`https://raw.githubusercontent.com/${full}/${branch}/${file}`);
  if (!res.ok) return null;
  return await res.text();
}

/** Full recursive file listing, cached. Returns { paths, truncated }. */
function tree(full, branch) {
  const cache = path.join(TREES, `${full.replace("/", "+")}.json`);
  if (fs.existsSync(cache)) return JSON.parse(fs.readFileSync(cache, "utf8"));
  let out;
  try {
    out = JSON.parse(gh(`repos/${full}/git/trees/${branch}?recursive=1`));
  } catch {
    return { paths: [], truncated: false, error: true };
  }
  const result = {
    paths: (out.tree || []).filter((t) => t.type === "blob").map((t) => t.path),
    truncated: Boolean(out.truncated),
  };
  fs.mkdirSync(TREES, { recursive: true });
  fs.writeFileSync(cache, JSON.stringify(result));
  return result;
}

async function cachedRaw(full, branch, p) {
  const key = `${full.replace("/", "+")}__${p.replace(/\//g, "~")}`;
  const cache = path.join(FILES, key);
  if (fs.existsSync(cache)) return fs.readFileSync(cache, "utf8");
  const text = await raw(full, branch, p);
  if (text === null) return null;
  fs.mkdirSync(FILES, { recursive: true });
  fs.writeFileSync(cache, text);
  return text;
}

async function analyseRepo(repo) {
  const full = repo.full_name;
  const branch = repo.default_branch || "main";
  const t = tree(full, branch);
  if (t.error) return { repo: full, status: "tree-unavailable" };

  const usable = t.paths.filter((p) => !EXCLUDED.test(p));
  let lockPaths = usable.filter((p) => LOCK_RE.test(p));
  const manifestPaths = usable.filter((p) => /(^|\/)package\.json$/.test(p)).slice(0, MAX_MANIFESTS);

  if (!lockPaths.length) {
    return { repo: full, status: "no-lockfile", treeTruncated: t.truncated };
  }
  const lockCapped = lockPaths.length > MAX_LOCKFILES;
  lockPaths = lockPaths.slice(0, MAX_LOCKFILES);

  // Fetch manifests once; scope them per lockfile below.
  const manifests = new Map();
  for (const p of manifestPaths) {
    const text = await cachedRaw(full, branch, p);
    if (!text) continue;
    try { manifests.set(p, JSON.parse(text)); } catch { /* unparseable */ }
  }

  const all = new Set();
  const prod = new Set();
  const covered = new Set();   // packages from lockfiles that DID resolve dev/prod
  const parsed = [];

  for (const lp of lockPaths) {
    const text = await cachedRaw(full, branch, lp);
    if (!text) continue;
    const dir = lp.includes("/") ? lp.slice(0, lp.lastIndexOf("/") + 1) : "";
    // Manifests belonging to this lockfile's own subtree.
    const scoped = [...manifests.entries()]
      .filter(([mp]) => mp.startsWith(dir))
      .map(([, m]) => m);
    let r;
    try { r = parseLock(lp, text, scoped); }
    // A lockfile that fails to parse contributes to neither `all` nor
    // `covered`, so it lowers no coverage ratio -- but its packages are then
    // invisible, a false-negative risk recorded in `lockfiles[].error`.
    catch (e) { parsed.push({ path: lp, error: String(e.message).split("\n")[0] }); continue; }
    if (!r.all.size) { parsed.push({ path: lp, empty: true }); continue; }
    for (const n of r.all) all.add(n);
    if (r.prod) {
      for (const n of r.prod) prod.add(n);
      for (const n of r.all) covered.add(n);
    }
    parsed.push({
      path: lp,
      kind: /yarn\.lock$/.test(lp) ? (isBerry(text) ? "yarn-berry" : "yarn-classic")
           : /pnpm/.test(lp) ? "pnpm" : "npm",
      packages: r.all.size,
      productionPackages: r.prod ? r.prod.size : null,
      manifestsUsed: scoped.length,
    });
  }

  if (!all.size) return { repo: full, status: "no-packages-parsed", lockfiles: parsed };

  /**
   * A repository is treated as production-resolvable when the lockfiles that
   * could report dev/prod cover essentially the whole tree. Requiring EVERY
   * lockfile to resolve was too strict: `joplin` was discarded because two small
   * vendored lockfileVersion-1 files carry no dev marking, even though its main
   * yarn.lock accounts for 96% of packages.
   */
  const coverage = covered.size / all.size;
  const prodResolvable = coverage >= 0.9;

  const found = (s) => [...s].filter((n) => PATCHERS[n]).map((n) => ({ package: n, tier: PATCHERS[n] }));
  return {
    repo: full, status: "ok", stars: repo.stargazers_count,
    catalogueName: repo.catalogueName || null,
    lockfileCount: parsed.length, lockfiles: parsed,
    lockfilesCapped: lockCapped, treeTruncated: t.truncated,
    resolvedPackages: all.size,
    devCoverage: +coverage.toFixed(3),
    productionPackages: prodResolvable ? prod.size : null,
    devDistinctionAvailable: prodResolvable,
    patchers: found(all),
    productionPatchers: prodResolvable ? found(prod) : null,
    productionPrimaryPatchers: prodResolvable
      ? [...prod].filter((n) => PRIMARY.has(n)) : null,
  };
}

async function main() {
  fs.mkdirSync(RESULTS, { recursive: true });
  const reposArg = process.argv.indexOf("--repos");
  if (reposArg === -1) throw new Error("--repos <file> is required");
  const limitArg = process.argv.indexOf("--limit");
  const outArg = process.argv.indexOf("--out");
  const outName = outArg !== -1 ? process.argv[outArg + 1] : "app-scan.json";

  let repos = JSON.parse(fs.readFileSync(path.resolve(process.argv[reposArg + 1]), "utf8"));
  if (limitArg !== -1) repos = repos.slice(0, Number(process.argv[limitArg + 1]));
  log(`analysing ${repos.length} repositories`);

  const results = [];
  let next = 0, done = 0;
  await Promise.all(Array.from({ length: CONCURRENCY }, async () => {
    while (next < repos.length) {
      const r = repos[next++];
      try { results.push(await analyseRepo(r)); }
      catch (e) { results.push({ repo: r.full_name, status: "error", error: String(e.message).split("\n")[0] }); }
      if (++done % 25 === 0) log(`  ${done}/${repos.length}`);
    }
  }));

  const ok = results.filter((r) => r.status === "ok").sort((a, b) => (b.stars || 0) - (a.stars || 0));
  const dev = ok.filter((r) => r.devDistinctionAvailable);
  const hit = dev.filter((r) => r.productionPrimaryPatchers.length);
  const cj = dev.filter((r) => (r.productionPatchers || []).some((p) => p.package.startsWith("core-js")));

  const byKind = {};
  for (const r of dev) for (const l of r.lockfiles) if (l.kind) byKind[l.kind] = (byKind[l.kind] || 0) + 1;

  const out = {
    generated: new Date().toISOString().slice(0, 10),
    method: {
      discovery: "full recursive git tree per repository; every lockfile outside node_modules/tests/fixtures/examples/docs is parsed, not just the root one",
      yarn: "yarn (berry and classic) production roots come from the repository's package.json files, since neither format marks dev-only packages -- verified: 0 of 29 berry lockfiles contain a devDependencies key",
      multiLockfile: "a repository's production sets are unioned across all its lockfiles; manifests are scoped to each lockfile's own subtree",
      excludedPaths: String(EXCLUDED),
      execution: "none",
    },
    counts: {
      repositories: results.length,
      analysed: ok.length,
      productionTreeResolvable: dev.length,
      shipsImportTimePatcher: hit.length,
      pctShipsImportTimePatcher: dev.length ? +((hit.length / dev.length) * 100).toFixed(1) : null,
      shipsCoreJs: cj.length,
      pctShipsCoreJs: dev.length ? +((cj.length / dev.length) * 100).toFixed(1) : null,
      lockfilesByKind: byKind,
      multiLockfileRepos: ok.filter((r) => r.lockfileCount > 1).length,
      treesTruncated: ok.filter((r) => r.treeTruncated).length,
    },
    statusBreakdown: results.reduce((m, r) => { m[r.status] = (m[r.status] || 0) + 1; return m; }, {}),
    applications: ok,
  };
  fs.writeFileSync(path.join(RESULTS, outName), JSON.stringify(out, null, 2) + "\n");
  log(`wrote results/${outName}`);
  console.log(JSON.stringify(out.counts, null, 2));
  console.log("\nships an import-time patcher to production:");
  for (const r of hit.slice(0, 25)) {
    console.log(`  ${r.repo.padEnd(38)} ${String(r.stars).padStart(7)}*  ${r.productionPrimaryPatchers.join(", ")}`);
  }
}

if (require.main === module) main().catch((e) => { console.error("[apps] FAILED:", e); process.exit(1); });
