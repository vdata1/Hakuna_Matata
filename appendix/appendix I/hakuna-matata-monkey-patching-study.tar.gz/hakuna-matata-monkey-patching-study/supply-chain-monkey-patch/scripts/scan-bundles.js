#!/usr/bin/env node
/**
 * Experiment 2, Arm B -- scan the shipped website bundles (cache/bundles/,
 * collected by fetch-bundles.js) for builtin modification, and roll the hits up
 * to per-domain prevalence + breadth + RHS-form distribution.
 *
 * Reuses the AST detector from scan-monkeypatch.js (scanSource) PLUS the core-js
 * export-signature detector (detectCoreJsExports) -- without the latter the most
 * important benign modifier (core-js, which patches via an internal helper) is
 * invisible and Arm B understates routineness.
 *
 * The thesis: builtins are modified ROUTINELY and BROADLY
 * in code browsers actually run, so screening a modification by *what* was
 * modified is insufficient. So we report, per domain:
 *   - presence: does any shipped asset modify a builtin?
 *   - breadth:  how many DISTINCT builtins/methods, across which tiers?
 *   - form:     the rhsClass distribution (constant-return / wraps-original /
 *               semantics-preserving / ...) -- benign modification is varied.
 *
 * Assets are content-addressed by sha, so each unique asset is parsed ONCE even
 * when shared across sites (CDN chunks). Prevalence is a LOWER BOUND (static
 * crawl; see fetch-bundles.js). Bundle code is never executed.
 *
 * Usage:  node scripts/scan-bundles.js [--manifest results/bundles.json]
 *                                      [--bundles cache/bundles]
 * Output: results/bundle_hits.csv    per (asset, hit)
 *         results/bundle-scan.json   per-domain rollup + aggregates
 */

const fs = require("node:fs");
const path = require("node:path");
const {
  parse, scanSource, tierOf, detectCoreJsExports,
} = require("./scan-monkeypatch.js");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const RESULTS = path.join(ROOT, "results");
const MAX_FILE_BYTES = 10 * 1024 * 1024;

const log = (...a) => console.error("[scan-bundles]", ...a);
function arg(flag, def) {
  const i = process.argv.indexOf(flag);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}

/** Scan one asset's source: direct AST hits + core-js signature hits. */
function scanAsset(src) {
  let ast;
  try { ast = parse(src); } catch { return { parseFailed: true, hits: [] }; }

  const hits = [];
  try {
    for (const h of scanSource(src, ast)) {
      if (h.shadowed) continue; // builtin name is locally rebound -> not the global
      hits.push({
        source: "direct", builtin: h.builtin, target: h.target,
        method: h.method ?? "", kind: h.kind, guarded: !!h.guarded,
        tier: h.tier ?? "", rhsClass: h.rhsClass ?? "",
      });
    }
  } catch { /* scanSource threw on pathological input -- skip its direct hits */ }

  // core-js exporter: each patched method becomes a hit. rhsClass is the whole
  // point of core-js -- semantics-preserving polyfills -- so tag it as such.
  try {
    for (const ex of detectCoreJsExports(ast)) {
      for (const m of ex.methods) {
        hits.push({
          source: "corejs", builtin: ex.builtin, target: ex.target,
          method: m, kind: "corejs-export", guarded: true,
          tier: tierOf(ex.builtin, ex.target, m) ?? "", rhsClass: "semantics-preserving",
        });
      }
    }
  } catch { /* ignore */ }

  return { parseFailed: false, hits };
}

function main() {
  const manifestPath = path.resolve(arg("--manifest", path.join(RESULTS, "bundles.json")));
  const bundlesDir = path.resolve(arg("--bundles", path.join(CACHE, "bundles")));
  if (!fs.existsSync(manifestPath)) throw new Error(`missing ${manifestPath}; run fetch-bundles.js`);

  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));

  // sha -> Set(domains) and domain -> [{sha, kind}]
  const domainsOfSha = new Map();
  const assetsOfDomain = new Map();
  for (const d of manifest.domains || []) {
    const okAssets = (d.assets || []).filter((a) => a.status === "ok" && a.sha);
    if (okAssets.length) assetsOfDomain.set(d.domain, okAssets);
    for (const a of okAssets) {
      if (!domainsOfSha.has(a.sha)) domainsOfSha.set(a.sha, new Set());
      domainsOfSha.get(a.sha).add(d.domain);
    }
  }
  const shas = [...domainsOfSha.keys()];
  log(`manifest: ${manifest.domains.length} domains, ${assetsOfDomain.size} with JS, ${shas.length} unique assets`);

  // Scan each unique asset once.
  const scanBySha = new Map();
  let parseFailed = 0, missing = 0, done = 0;
  const started = Date.now();
  for (const sha of shas) {
    const file = path.join(bundlesDir, `${sha}.js`);
    let src;
    try {
      if (fs.statSync(file).size > MAX_FILE_BYTES) { scanBySha.set(sha, { hits: [] }); continue; }
      src = fs.readFileSync(file, "utf8");
    } catch { missing++; scanBySha.set(sha, { hits: [] }); continue; }
    const r = scanAsset(src);
    if (r.parseFailed) parseFailed++;
    scanBySha.set(sha, r);
    if (++done % 500 === 0 || done === shas.length) {
      const rate = done / ((Date.now() - started) / 1000);
      log(`  scanned ${done}/${shas.length} assets (${rate.toFixed(0)}/s)`);
    }
  }

  // ---- per-domain rollup ------------------------------------------------
  const domainRollup = [];
  const formTotals = { direct: {}, corejs: {} };   // source -> rhsClass -> count
  const tierDomains = { A: new Set(), B: new Set(), C: new Set() };
  const tierDomainsBySource = {                     // separate core-js (hardcoded class) from direct
    A: { direct: new Set(), corejs: new Set() },
    B: { direct: new Set(), corejs: new Set() },
    C: { direct: new Set(), corejs: new Set() },
  };
  const builtinDomains = new Map(); // "Builtin.method" -> Set(domains)
  const guarding = { direct: { guarded: 0, unguarded: 0 }, corejs: { guarded: 0, unguarded: 0 } };
  let corejsDomains = 0;

  for (const [domain, assets] of assetsOfDomain) {
    const seen = new Map(); // "src|builtin|target|method" -> hit (dedupe within domain)
    for (const a of assets) {
      const r = scanBySha.get(a.sha);
      if (!r) continue;
      for (const h of r.hits) {
        const key = `${h.source}|${h.builtin}|${h.target}|${h.method}`;
        if (!seen.has(key)) seen.set(key, h);
      }
    }
    const hits = [...seen.values()];
    if (!hits.length) { domainRollup.push({ domain, modifies: false }); continue; }

    const builtins = new Set(hits.map((h) => h.builtin));
    const methods = new Set(hits.map((h) => `${h.builtin}.${h.method}`));
    const tiers = new Set(hits.map((h) => h.tier).filter(Boolean));
    const hasCorejs = hits.some((h) => h.source === "corejs");
    if (hasCorejs) corejsDomains++;
    for (const t of tiers) tierDomains[t].add(domain);
    for (const m of methods) {
      if (!builtinDomains.has(m)) builtinDomains.set(m, new Set());
      builtinDomains.get(m).add(domain);
    }
    for (const h of hits) {
      const src = h.source === "corejs" ? "corejs" : "direct";
      const cls = h.rhsClass || "unknown";
      formTotals[src][cls] = (formTotals[src][cls] || 0) + 1;
      guarding[src][h.guarded ? "guarded" : "unguarded"]++;
      if (h.tier) tierDomainsBySource[h.tier][src].add(domain);
    }
    domainRollup.push({
      domain, modifies: true,
      distinctBuiltins: builtins.size,
      distinctMethods: methods.size,
      tiers: [...tiers].sort(),
      corejs: hasCorejs,
      methodsList: [...methods].sort(),
    });
  }

  // ---- CSV: per (asset, hit), with domain count + a domain sample ----
  const rows = [];
  for (const sha of shas) {
    const r = scanBySha.get(sha);
    if (!r || !r.hits.length) continue;
    const doms = [...(domainsOfSha.get(sha) || [])];
    for (const h of r.hits) {
      rows.push({
        sha: sha.slice(0, 12), domains: doms.length, domainSample: doms.slice(0, 3).join(" "),
        source: h.source, builtin: h.builtin, target: h.target, method: h.method,
        tier: h.tier, rhsClass: h.rhsClass, guarded: h.guarded, kind: h.kind,
      });
    }
  }
  const COLS = ["sha", "domains", "domainSample", "source", "builtin", "target", "method",
    "tier", "rhsClass", "guarded", "kind"];
  const esc = (v) => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  fs.writeFileSync(path.join(RESULTS, "bundle_hits.csv"),
    [COLS.join(","), ...rows.map((r) => COLS.map((c) => esc(r[c])).join(","))].join("\n") + "\n");

  // ---- aggregates -------------------------------------------------------
  const withJs = assetsOfDomain.size;
  const modifying = domainRollup.filter((d) => d.modifies);
  const breadthHist = {};
  for (const d of modifying) breadthHist[d.distinctBuiltins] = (breadthHist[d.distinctBuiltins] || 0) + 1;

  const pct = (n, d) => (d ? +(100 * n / d).toFixed(1) : 0);
  const summary = {
    generated: new Date().toISOString().slice(0, 10),
    manifest: path.basename(manifestPath),
    method: "static-crawl bundles; AST + core-js signature; shadowed hits excluded; LOWER BOUND",
    denominators: {
      domainsAttempted: manifest.domains.length,
      domainsWithJsAsset: withJs,
      uniqueAssets: shas.length,
      assetsParseFailed: parseFailed,
      assetsMissing: missing,
    },
    prevalence: {
      domainsModifyingBuiltin: modifying.length,
      pctOfDomainsWithJs: pct(modifying.length, withJs),
      pctOfDomainsAttempted: pct(modifying.length, manifest.domains.length),
      domainsWithCorejs: corejsDomains,
    },
    breadth: {
      distinctBuiltinMethodsAcrossCorpus: builtinDomains.size,
      distinctBuiltinsPerModifyingDomain: breadthHist, // {count: nDomains}
      topMethods: [...builtinDomains.entries()]
        .sort((a, b) => b[1].size - a[1].size).slice(0, 25)
        .map(([m, s]) => [m, s.size]),
    },
    tierLens: {
      A_domains: tierDomains.A.size, B_domains: tierDomains.B.size, C_domains: tierDomains.C.size,
      A_pctOfWithJs: pct(tierDomains.A.size, withJs),
      C_pctOfWithJs: pct(tierDomains.C.size, withJs),
      bySource: {
        A: { direct: tierDomainsBySource.A.direct.size, corejs: tierDomainsBySource.A.corejs.size },
        B: { direct: tierDomainsBySource.B.direct.size, corejs: tierDomainsBySource.B.corejs.size },
        C: { direct: tierDomainsBySource.C.direct.size, corejs: tierDomainsBySource.C.corejs.size },
      },
      // The two Tier-C members separated: the conspicuous clobber vs the core-js polyfill.
      tierC_members: {
        "Object.hasOwnProperty": (builtinDomains.get("Object.hasOwnProperty") || new Set()).size,
        "Reflect.getPrototypeOf": (builtinDomains.get("Reflect.getPrototypeOf") || new Set()).size,
      },
    },
    // Split by source: core-js hits are hardcoded guarded+semantics-preserving BY CONSTRUCTION
    // (core-js polyfills feature-detect and preserve semantics), so the DIRECT column is the
    // honest "how is benign modification actually written" measure.
    formDistribution: formTotals,     // { direct: {rhsClass:n}, corejs: {rhsClass:n} }
    guarding,                         // { direct:{guarded,unguarded}, corejs:{...} }
    note:
      "Prevalence is a lower bound (static crawl misses runtime-injected/lazy chunks). Breadth + " +
      "the DIRECT form distribution are the thesis evidence: builtins are modified routinely and " +
      "broadly, in varied forms, so screening by target identity is inadequate. Honest boundary: " +
      "the constant-return attack shape is near-absent benignly, and Object.prototype.hasOwnProperty " +
      "(the conspicuous Tier-C member) is not modified in the wild -- so category-level camouflage " +
      "holds while line-level (RHS form) and the narrowest conspicuous targets remain distinguishable.",
  };
  fs.writeFileSync(path.join(RESULTS, "bundle-scan.json"), JSON.stringify(summary, null, 2) + "\n");

  log(`domains modifying a builtin: ${modifying.length}/${withJs} (${summary.prevalence.pctOfDomainsWithJs}% of JS-bearing)`);
  log(`  via core-js signature: ${corejsDomains}`);
  log(`tier A/B/C domains: ${tierDomains.A.size}/${tierDomains.B.size}/${tierDomains.C.size}`);
  log(`distinct builtin.method modified across corpus: ${builtinDomains.size}`);
  log(`form distribution:`, JSON.stringify(formTotals));
  log("wrote results/bundle_hits.csv, results/bundle-scan.json");
  console.log(JSON.stringify(summary.prevalence, null, 2));
}

if (require.main === module) {
  try { main(); } catch (err) { console.error("[scan-bundles] FAILED:", err); process.exit(1); }
}

module.exports = { scanAsset };
