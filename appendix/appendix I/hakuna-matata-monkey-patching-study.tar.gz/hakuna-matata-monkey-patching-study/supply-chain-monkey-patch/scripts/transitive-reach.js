#!/usr/bin/env node
/**
 * Transitive reach of builtin-mutating packages (handoff §5).
 *
 * Direct prevalence ("N of the top 1,000 patch builtins") badly understates
 * installed impact: what matters for a supply-chain argument is how many
 * applications end up with a patcher *somewhere* in their dependency tree. A
 * package that mutates a builtin affects every dependent in its realm, whether
 * or not that dependent knows it exists.
 *
 * Method:
 *   1. Roots = the population (top 1,000).
 *   2. BFS the runtime dependency graph, fetching each newly-seen package's
 *      manifest. Corpus packages are read from disk; the rest are fetched.
 *   3. For each target patcher, count roots whose closure contains it.
 *
 * Graph is NAME-level, not version-resolved: an edge exists if a package
 * declares a dependency on a name, regardless of range. This overestimates
 * slightly (a range might resolve to a version without that dep) and is the
 * standard approximation for reach analyses -- stated in the output.
 *
 * Only `dependencies` and `optionalDependencies` are followed: those are what
 * npm installs into a production tree. devDependencies are excluded (they do
 * not ship to applications); peerDependencies are counted separately since
 * npm 7+ auto-installs them.
 *
 * Usage:  node scripts/transitive-reach.js
 * Output: results/transitive-reach.json
 */

const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const RESULTS = path.join(ROOT, "results");

const CONCURRENCY = 12;
const MAX_RETRIES = 5;

/**
 * Packages known to mutate builtins through INDIRECTION, which the syntactic
 * scanner provably cannot detect (see results/summary.md, "Detection floor").
 * core-js is included on hard evidence: 181 of its modules patch a prototype
 * via `$({ target, proto: true }, …)`, and the scan caught none of them.
 */
const KNOWN_INDIRECT_PATCHERS = [
  "core-js", "core-js-pure", "@babel/polyfill", "es5-shim", "es6-shim",
  "zone.js", "core-js-bundle",
];

const log = (...a) => console.error("[reach]", ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJSON(url) {
  let lastErr;
  for (let i = 0; i <= MAX_RETRIES; i++) {
    try {
      const res = await fetch(url, { headers: { accept: "application/json" } });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      lastErr = err;
      if (i < MAX_RETRIES) await sleep(400 * 2 ** i + Math.random() * 200);
    }
  }
  throw new Error(`${url}: ${lastErr.message}`);
}

async function pooled(items, worker, label) {
  const out = new Array(items.length);
  let next = 0, done = 0;
  async function run() {
    while (next < items.length) {
      const i = next++;
      out[i] = await worker(items[i]);
      if (++done % 500 === 0) log(`  ${label}: ${done}/${items.length}`);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, items.length) }, run));
  return out;
}

async function main() {
  const dataset = JSON.parse(fs.readFileSync(path.join(ROOT, "AugTop1K_npm.json"), "utf8"));
  const corpus = JSON.parse(fs.readFileSync(
    fs.readdirSync(RESULTS).filter((f) => /^corpus-.*\.json$/.test(f)).sort().pop()
      .replace(/^/, RESULTS + "/"), "utf8"));
  const { parseCSV } = require("./fetch-corpus.js");
  const hits = parseCSV(fs.readFileSync(path.join(RESULTS, "monkeypatch_hits.csv"), "utf8"));

  // Targets: syntactically-detected mutators + known indirection patchers.
  const detected = new Set(
    hits.filter((h) => h.target === "prototype" && h.shadowed !== "true")
        .map((h) => h.package)
  );
  const targets = [...new Set([...detected, ...KNOWN_INDIRECT_PATCHERS])];
  log(`targets: ${targets.length} (${detected.size} detected + known indirect)`);

  // ---- dependency graph --------------------------------------------------
  const depsCache = path.join(CACHE, "dep-graph.json");
  const graph = fs.existsSync(depsCache) ? JSON.parse(fs.readFileSync(depsCache, "utf8")) : {};
  log(`graph cache: ${Object.keys(graph).length} packages`);

  // Seed from corpus package.json files (no network needed).
  for (const p of corpus.packages) {
    if (graph[p.name]) continue;
    try {
      const pj = JSON.parse(fs.readFileSync(path.join(ROOT, p.dir, "package.json"), "utf8"));
      graph[p.name] = {
        deps: Object.keys({ ...pj.dependencies, ...pj.optionalDependencies }),
        peers: Object.keys(pj.peerDependencies || {}),
      };
    } catch { graph[p.name] = { deps: [], peers: [] }; }
  }

  // BFS outward, fetching manifests for names we have not seen.
  let frontier = [...new Set(Object.values(graph).flatMap((g) => [...g.deps, ...g.peers]))]
    .filter((n) => !graph[n]);
  let depth = 0;
  while (frontier.length) {
    depth++;
    log(`depth ${depth}: fetching ${frontier.length} new packages`);
    const fetched = await pooled(frontier, async (name) => {
      const doc = await getJSON(`https://registry.npmjs.org/${name.replace("/", "%2f")}/latest`);
      return [name, doc ? {
        deps: Object.keys({ ...doc.dependencies, ...doc.optionalDependencies }),
        peers: Object.keys(doc.peerDependencies || {}),
      } : { deps: [], peers: [], missing: true }];
    }, `depth ${depth}`);
    for (const [name, entry] of fetched) graph[name] = entry;
    fs.writeFileSync(depsCache, JSON.stringify(graph));
    frontier = [...new Set(fetched.flatMap(([, e]) => [...e.deps, ...e.peers]))]
      .filter((n) => !graph[n]);
  }
  log(`graph complete: ${Object.keys(graph).length} packages, depth ${depth}`);

  // ---- closure per root --------------------------------------------------
  /** Names reachable from `start` following runtime deps (optionally peers). */
  const closureOf = (start, includePeers) => {
    const seen = new Set();
    const stack = [start];
    while (stack.length) {
      const n = stack.pop();
      const g = graph[n];
      if (!g) continue;
      const edges = includePeers ? [...g.deps, ...g.peers] : g.deps;
      for (const d of edges) if (!seen.has(d)) { seen.add(d); stack.push(d); }
    }
    return seen;
  };

  const roots = dataset.packages;
  const totalDownloads = roots.reduce((n, p) => n + p.weeklyDownloads, 0);

  const measure = (includePeers) => {
    const perTarget = {};
    for (const t of targets) perTarget[t] = { packages: [], downloads: 0 };
    const anyRoots = [];
    let anyDownloads = 0;

    for (const r of roots) {
      const closure = closureOf(r.name, includePeers);
      let any = false;
      for (const t of targets) {
        // A root "reaches" a target if the target is in its closure. The root
        // itself being a patcher is reported separately as direct prevalence.
        if (closure.has(t)) {
          perTarget[t].packages.push(r.name);
          perTarget[t].downloads += r.weeklyDownloads;
          any = true;
        }
      }
      if (any) { anyRoots.push(r.name); anyDownloads += r.weeklyDownloads; }
    }
    return { perTarget, anyRoots, anyDownloads };
  };

  const runtime = measure(false);
  const withPeers = measure(true);

  const rank = (m) => Object.entries(m.perTarget)
    .map(([name, v]) => ({
      target: name,
      dependentRoots: v.packages.length,
      pctOfPopulation: +((v.packages.length / roots.length) * 100).toFixed(1),
      pctOfPopulationDownloads: +((v.downloads / totalDownloads) * 100).toFixed(1),
      examples: v.packages.slice(0, 8),
    }))
    .filter((x) => x.dependentRoots > 0)
    .sort((a, b) => b.dependentRoots - a.dependentRoots);

  const out = {
    generated: new Date().toISOString().slice(0, 10),
    method: {
      graph: "name-level runtime dependency graph; an edge exists if a package declares a dependency on a name, regardless of version range",
      edgesFollowed: "dependencies + optionalDependencies (what npm installs into a production tree); devDependencies excluded",
      peerHandling: "reported both without and with peerDependencies, since npm 7+ auto-installs peers",
      approximation: "name-level reach slightly OVERESTIMATES: a specific version range might resolve to a version lacking that dependency",
      graphSize: Object.keys(graph).length,
      maxDepth: depth,
    },
    targets: {
      syntacticallyDetected: [...detected],
      knownIndirectPatchers: KNOWN_INDIRECT_PATCHERS,
      note: "core-js is included on evidence: 181 of its modules patch a prototype via the $ export helper, none of which the syntactic scan can detect",
    },
    runtimeDeps: {
      rootsReachingAnyPatcher: runtime.anyRoots.length,
      pctOfPopulation: +((runtime.anyRoots.length / roots.length) * 100).toFixed(1),
      pctOfPopulationDownloads: +((runtime.anyDownloads / totalDownloads) * 100).toFixed(1),
      byTarget: rank(runtime),
    },
    includingPeerDeps: {
      rootsReachingAnyPatcher: withPeers.anyRoots.length,
      pctOfPopulation: +((withPeers.anyRoots.length / roots.length) * 100).toFixed(1),
      pctOfPopulationDownloads: +((withPeers.anyDownloads / totalDownloads) * 100).toFixed(1),
      byTarget: rank(withPeers),
    },
  };

  fs.writeFileSync(path.join(RESULTS, "transitive-reach.json"), JSON.stringify(out, null, 2) + "\n");
  log("wrote results/transitive-reach.json");
  console.log(JSON.stringify({
    graphSize: out.method.graphSize,
    runtime: {
      roots: out.runtimeDeps.rootsReachingAnyPatcher,
      pct: out.runtimeDeps.pctOfPopulation,
      pctDownloads: out.runtimeDeps.pctOfPopulationDownloads,
    },
    withPeers: {
      roots: out.includingPeerDeps.rootsReachingAnyPatcher,
      pct: out.includingPeerDeps.pctOfPopulation,
    },
    top: out.runtimeDeps.byTarget.slice(0, 6),
  }, null, 2));
}

main().catch((e) => { console.error("[reach] FAILED:", e); process.exit(1); });
