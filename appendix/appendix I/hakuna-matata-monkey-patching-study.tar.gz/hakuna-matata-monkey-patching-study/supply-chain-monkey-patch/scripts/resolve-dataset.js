#!/usr/bin/env node
/**
 * Experiment 2, Arm A -- resolve a curated list of package NAMES into the
 * dataset shape fetch-corpus.js consumes (name, version, tarball, integrity,
 * shasum), by asking the npm registry for each package's latest release.
 *
 * Arm A is the targeted known-modifier set: packages that modify built-ins for
 * legitimate reasons, scanned in their PUBLISHED source so we can ATTRIBUTE a
 * modification to a named package (which Arm B's minified bundles cannot). It is
 * selection-on-the-outcome, so it yields exemplars + form characterization, not
 * a base rate (Exp 2, Arm A).
 *
 * Usage:  node scripts/resolve-dataset.js [--names <file>] [--out results/armA-dataset.json]
 *         (with no --names, the built-in curated list below is used)
 * Output: results/armA-dataset.json   (AugTop1K_npm.json-compatible array)
 */

const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const REGISTRY = "https://registry.npmjs.org";
const log = (...a) => console.error("[armA-resolve]", ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Curated prototype-patching polyfills / shims / sugar libs. The point is
// attribution-worthy benign modifiers of the Tier-A/B/C surface.
const DEFAULT_NAMES = [
  // whole-surface polyfills
  "core-js", "es5-shim", "es6-shim", "es7-shim", "mdn-polyfills", "polyfill-library",
  // es-shims (individual, opt-in via .shim())
  "array-includes", "array.prototype.flat", "array.prototype.flatmap",
  "array.prototype.indexof", "string.prototype.matchall", "string.prototype.split",
  "string.prototype.trimstart", "string.prototype.trimend",
  "object.fromentries", "object.entries", "object.assign",
  // sugar libraries
  "sugar",
];

async function fetchJson(url) {
  for (let attempt = 0; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url, { headers: { accept: "application/json" } });
      if (res.status === 404) return { missing: true };
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return { json: await res.json() };
    } catch (err) {
      if (attempt < 3) await sleep(400 * 2 ** attempt);
      else throw err;
    }
  }
}

function arg(flag, def) {
  const i = process.argv.indexOf(flag);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}

async function main() {
  fs.mkdirSync(RESULTS, { recursive: true });
  const namesFile = arg("--names", null);
  const outPath = path.resolve(arg("--out", path.join(RESULTS, "armA-dataset.json")));
  const names = namesFile
    ? fs.readFileSync(path.resolve(namesFile), "utf8").split("\n").map((s) => s.trim()).filter(Boolean)
    : DEFAULT_NAMES;

  log(`resolving ${names.length} packages from the registry`);
  const rows = [];
  const failures = [];
  let rank = 0;
  for (const name of names) {
    rank++;
    try {
      const r = await fetchJson(`${REGISTRY}/${name.replace("/", "%2F")}/latest`);
      if (r.missing) { failures.push({ name, reason: "404" }); log(`  MISS ${name}`); continue; }
      const m = r.json;
      const dist = m.dist || {};
      if (!dist.tarball) { failures.push({ name, reason: "no-tarball" }); continue; }
      rows.push({
        rank, name: m.name, version: m.version,
        tarball: dist.tarball, integrity: dist.integrity, shasum: dist.shasum,
      });
      log(`  ok   ${m.name}@${m.version}`);
    } catch (err) {
      failures.push({ name, reason: String(err.message || err) });
      log(`  FAIL ${name}: ${err.message || err}`);
    }
  }

  fs.writeFileSync(outPath, JSON.stringify(rows, null, 2) + "\n");
  log(`resolved ${rows.length}/${names.length}; wrote ${path.relative(ROOT, outPath)}`);
  if (failures.length) log(`failures:`, JSON.stringify(failures));
  console.log(JSON.stringify({ resolved: rows.length, failed: failures.length }, null, 2));
}

if (require.main === module) {
  main().catch((err) => { console.error("[armA-resolve] FAILED:", err); process.exit(1); });
}
