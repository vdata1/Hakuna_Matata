#!/usr/bin/env node
/**
 * Do the DEFAULT applications produced by popular framework scaffolders contain
 * a builtin-mutating package?
 *
 * Motivation: the top-1,000-by-downloads population is
 * overwhelmingly *libraries*, which deliberately avoid patching builtins. The
 * paper's claim is about what ends up loaded in a running APPLICATION's realm.
 * Framework starter templates are the highest-leverage proxy: they are the
 * literal starting point of an enormous share of new applications, and the
 * resulting claim is checkable by a reviewer in one command.
 *
 * NOTHING IS EXECUTED. Running a scaffolder, or `npm install`ing its output,
 * would execute arbitrary third-party code and hundreds of lifecycle scripts,
 * which handoff §8 forbids. Instead each scaffolder's published tarball is
 * downloaded and its TEMPLATE MANIFESTS are read as data, then the dependency
 * closure is resolved from registry metadata.
 *
 * Limitation this creates, stated plainly: we measure the INSTALLED TREE, not
 * build-time injection. A bundler that injects `core-js` because of a
 * browserslist target adds code that no manifest declares. Closing that gap
 * requires actually building each template in a sandbox -- a deliberate
 * decision to execute untrusted code, not taken here.
 *
 * Usage:  node scripts/app-templates.js
 * Output: results/app-templates.json
 */

const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const TPL = path.join(CACHE, "templates");
const RESULTS = path.join(ROOT, "results");

const CONCURRENCY = 10;
const log = (...a) => console.error("[templates]", ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Packages that mutate builtins. Split by how we know:
 *  - detected: found syntactically by scan-monkeypatch.js
 *  - indirect: patch through helpers the syntactic scan cannot see (core-js:
 *    181 prototype-patching modules; zone.js: patches globals wholesale)
 */
const PATCHERS = {
  "core-js": "indirect", "core-js-pure": "indirect", "core-js-bundle": "indirect",
  "@babel/polyfill": "indirect", "es5-shim": "indirect", "es6-shim": "indirect",
  "zone.js": "indirect",
  "@sentry/core": "detected", "next": "detected", "chai": "detected",
  "bowser": "detected", "once": "detected", "d3-array": "detected",
  "axe-core": "detected", "array.prototype.tosorted": "detected",
  "core-js-compat": "indirect",
};

/**
 * Scaffolders and how their default template manifests are shipped.
 *  - "glob": template package.json files inside the tarball
 *  - "craTemplate": CRA's template.json { package: { dependencies } }
 *  - "declared": the scaffolder builds its dependency list in code, so the set
 *    is transcribed here from that source (path recorded for auditability)
 */
const SCAFFOLDERS = [
  { framework: "vite", pkg: "create-vite", mode: "glob",
    match: /^package\/template-([a-z0-9-]+)\/package\.json$/ },
  { framework: "vue", pkg: "create-vue", mode: "glob",
    match: /^package\/template\/base\/package\.json$/, label: () => "default" },
  { framework: "svelte", pkg: "sv", mode: "glob",
    match: /^package\/dist\/templates\/([a-z0-9-]+)\/package\.json$/ },
  // Angular ships its workspace manifest as an EJS template, so it is parsed
  // by extracting dependency blocks rather than JSON.parse.
  { framework: "angular", pkg: "@schematics/angular", mode: "ejs",
    match: /^package\/workspace\/files\/package\.json\.template$/ },
  { framework: "nuxt", pkg: "create-nuxt-app", mode: "glob",
    match: /^package\/(?:template|templates)\/.*package\.json$/, label: () => "default" },
  { framework: "react-cra", pkg: "cra-template", mode: "craTemplate",
    // CRA always installs these three alongside the template's own deps.
    base: { react: "*", "react-dom": "*", "react-scripts": "*" } },
  { framework: "next", pkg: "create-next-app", mode: "declared",
    source: "package/dist/index.js (dependency list constructed in code)",
    templates: {
      "app-router-ts": { deps: { next: "*", react: "*", "react-dom": "*" },
                         dev: { typescript: "*", "@types/node": "*", "@types/react": "*",
                                eslint: "*", "eslint-config-next": "*" } },
    } },
];

// ---------------------------------------------------------------------------

async function getJSON(url) {
  for (let i = 0; i <= 5; i++) {
    try {
      const res = await fetch(url, { headers: { accept: "application/json" } });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) {
      if (i === 5) throw e;
      await sleep(400 * 2 ** i + Math.random() * 200);
    }
  }
}

async function fetchAndExtract(pkg) {
  const safe = pkg.replace("/", "+");
  const dir = path.join(TPL, safe);
  if (fs.existsSync(dir)) return dir;
  const doc = await getJSON(`https://registry.npmjs.org/${pkg.replace("/", "%2f")}/latest`);
  if (!doc) return null;
  const res = await fetch(doc.dist.tarball);
  if (!res.ok) return null;
  const tgz = path.join(TPL, `${safe}.tgz`);
  fs.mkdirSync(TPL, { recursive: true });
  fs.writeFileSync(tgz, Buffer.from(await res.arrayBuffer()));
  fs.mkdirSync(dir, { recursive: true });
  // Extraction only -- tar writes files, it cannot execute them.
  execFileSync("tar", ["xzf", tgz, "-C", dir], { stdio: ["ignore", "ignore", "pipe"] });
  execFileSync("chmod", ["-R", "u+rwX", dir], { stdio: ["ignore", "ignore", "pipe"] });
  return dir;
}

function listAll(dir) {
  const out = [];
  const stack = [dir];
  while (stack.length) {
    let e;
    try { e = fs.readdirSync(stack.pop(), { withFileTypes: true }); } catch { continue; }
    for (const x of e) {
      const p = path.join(x.parentPath ?? x.path, x.name);
      if (x.isDirectory()) stack.push(p); else out.push(p);
    }
  }
  return out;
}

/**
 * Pull dependency names out of a manifest that may contain EJS tags (Angular
 * ships `package.json.template` with `<%= %>` placeholders, so it is not valid
 * JSON). Brace-matches the named block and collects its quoted keys, which
 * sidesteps template syntax entirely.
 */
function depNamesFrom(text, field) {
  const at = text.indexOf(`"${field}"`);
  if (at === -1) return {};
  const open = text.indexOf("{", at);
  if (open === -1) return {};
  let depth = 0, end = -1;
  for (let i = open; i < text.length; i++) {
    if (text[i] === "{") depth++;
    else if (text[i] === "}") { depth--; if (!depth) { end = i; break; } }
  }
  if (end === -1) return {};
  const block = text.slice(open + 1, end);
  const out = {};
  for (const m of block.matchAll(/"([^"<>%\s]+)"\s*:/g)) out[m[1]] = "*";
  return out;
}

/** Read every template manifest a scaffolder ships. */
function extractTemplates(sc, dir) {
  const apps = [];
  const files = listAll(dir);
  const rel = (f) => "package/" + path.relative(dir, f).split(path.sep).join("/").replace(/^package\//, "");

  if (sc.mode === "declared") {
    for (const [name, t] of Object.entries(sc.templates)) {
      apps.push({ template: name, deps: t.deps, dev: t.dev || {}, source: sc.source });
    }
    return apps;
  }

  if (sc.mode === "craTemplate") {
    const tj = files.find((f) => /template\.json$/.test(f));
    if (!tj) return apps;
    const doc = JSON.parse(fs.readFileSync(tj, "utf8"));
    apps.push({
      template: "default",
      deps: { ...sc.base, ...(doc.package?.dependencies || {}) },
      dev: doc.package?.devDependencies || {},
      source: "template.json + react-scripts base",
    });
    return apps;
  }

  if (sc.mode === "ejs") {
    for (const f of files) {
      const r = rel(f);
      if (!sc.match.test(r)) continue;
      const text = fs.readFileSync(f, "utf8");
      apps.push({
        template: "default",
        deps: depNamesFrom(text, "dependencies"),
        dev: depNamesFrom(text, "devDependencies"),
        source: r + " (EJS template; dependency names extracted)",
      });
    }
    return apps;
  }

  for (const f of files) {
    if (!/package\.json$/.test(f)) continue;
    const r = rel(f);
    const m = sc.match.exec(r);
    if (!m) continue;
    let doc;
    try { doc = JSON.parse(fs.readFileSync(f, "utf8")); } catch { continue; }
    const deps = doc.dependencies || {};
    const dev = doc.devDependencies || {};
    if (!Object.keys(deps).length && !Object.keys(dev).length) continue;
    apps.push({
      template: sc.label ? sc.label() : (m[1] || "default"),
      deps, dev, source: r,
    });
  }
  return apps;
}

// ---------------------------------------------------------------------------

async function main() {
  fs.mkdirSync(TPL, { recursive: true });
  fs.mkdirSync(RESULTS, { recursive: true });

  const graphPath = path.join(CACHE, "dep-graph.json");
  const graph = fs.existsSync(graphPath) ? JSON.parse(fs.readFileSync(graphPath, "utf8")) : {};
  log(`dep graph seeded with ${Object.keys(graph).length} packages`);

  // ---- collect app definitions ------------------------------------------
  const apps = [];
  const unresolved = [];
  for (const sc of SCAFFOLDERS) {
    const dir = await fetchAndExtract(sc.pkg);
    if (!dir) { unresolved.push({ ...sc, reason: "package not found" }); continue; }
    const found = extractTemplates(sc, dir);
    if (!found.length) {
      unresolved.push({ framework: sc.framework, pkg: sc.pkg,
        reason: "no template manifests in tarball (templates likely fetched from GitHub at run time)" });
      continue;
    }
    for (const a of found) apps.push({ framework: sc.framework, scaffolder: sc.pkg, ...a });
    log(`${sc.framework}: ${found.length} template(s)`);
  }
  log(`collected ${apps.length} templates; ${unresolved.length} scaffolders unresolved`);

  // ---- resolve dependency closures --------------------------------------
  const need = new Set();
  for (const a of apps) for (const n of [...Object.keys(a.deps), ...Object.keys(a.dev)]) need.add(n);

  let frontier = [...need].filter((n) => !graph[n]);
  let depth = 0;
  while (frontier.length) {
    depth++;
    log(`depth ${depth}: fetching ${frontier.length} manifests`);
    const results = [];
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, frontier.length) }, async () => {
      while (next < frontier.length) {
        const name = frontier[next++];
        const doc = await getJSON(`https://registry.npmjs.org/${name.replace("/", "%2f")}/latest`);
        results.push([name, doc
          ? { deps: Object.keys({ ...doc.dependencies, ...doc.optionalDependencies }),
              peers: Object.keys(doc.peerDependencies || {}) }
          : { deps: [], peers: [], missing: true }]);
      }
    }));
    for (const [n, e] of results) graph[n] = e;
    fs.writeFileSync(graphPath, JSON.stringify(graph));
    frontier = [...new Set(results.flatMap(([, e]) => e.deps))].filter((n) => !graph[n]);
  }
  log(`graph now ${Object.keys(graph).length} packages`);

  const closureOf = (roots) => {
    const seen = new Set();
    const stack = [...roots];
    while (stack.length) {
      const n = stack.pop();
      const g = graph[n];
      if (!g) continue;
      for (const d of g.deps) if (!seen.has(d)) { seen.add(d); stack.push(d); }
    }
    return seen;
  };

  // ---- evaluate ----------------------------------------------------------
  const evaluated = apps.map((a) => {
    const runtimeRoots = Object.keys(a.deps);
    const fullRoots = [...runtimeRoots, ...Object.keys(a.dev)];
    const runtime = new Set([...runtimeRoots, ...closureOf(runtimeRoots)]);
    const full = new Set([...fullRoots, ...closureOf(fullRoots)]);
    const found = (s) => Object.keys(PATCHERS).filter((p) => s.has(p))
      .map((p) => ({ package: p, evidence: PATCHERS[p] }));
    return {
      framework: a.framework, template: a.template, scaffolder: a.scaffolder,
      source: a.source,
      runtimeDepCount: runtime.size, fullInstallCount: full.size,
      patchersInRuntimeTree: found(runtime),
      patchersInFullInstall: found(full),
    };
  }).sort((a, b) => a.framework.localeCompare(b.framework) || a.template.localeCompare(b.template));

  const withRuntime = evaluated.filter((e) => e.patchersInRuntimeTree.length);
  const withFull = evaluated.filter((e) => e.patchersInFullInstall.length);

  const out = {
    generated: new Date().toISOString().slice(0, 10),
    question: "Do default framework starter applications ship a builtin-mutating package?",
    method: {
      execution: "NONE. Scaffolder tarballs are downloaded and their template manifests read as data; dependency closures resolved from registry metadata. No scaffolder was run and no application was installed or built.",
      closure: "name-level over `dependencies` (+`optionalDependencies`); slightly overestimates, as a version range might resolve to a version lacking a dep",
      runtimeVsFull: "runtime = closure of `dependencies` only (what ships to the app's realm); fullInstall = plus `devDependencies` (what lands in node_modules)",
      limitation: "measures the INSTALLED TREE, not build-time injection. A bundler injecting core-js due to a browserslist target adds code no manifest declares; detecting that requires building each template in a sandbox, which would mean executing untrusted code.",
    },
    patcherDefinitions: PATCHERS,
    counts: {
      templates: evaluated.length,
      withPatcherInRuntimeTree: withRuntime.length,
      withPatcherInFullInstall: withFull.length,
      frameworks: [...new Set(evaluated.map((e) => e.framework))].length,
    },
    unresolvedScaffolders: unresolved,
    templates: evaluated,
  };

  fs.writeFileSync(path.join(RESULTS, "app-templates.json"), JSON.stringify(out, null, 2) + "\n");
  log("wrote results/app-templates.json");

  console.log(`\ntemplates analysed: ${evaluated.length} across ${out.counts.frameworks} frameworks`);
  console.log(`with a builtin-patcher in the RUNTIME tree:  ${withRuntime.length}/${evaluated.length}`);
  console.log(`with a builtin-patcher in the FULL install:  ${withFull.length}/${evaluated.length}\n`);
  for (const e of evaluated) {
    const r = e.patchersInRuntimeTree.map((p) => p.package).join(", ");
    const f = e.patchersInFullInstall.map((p) => p.package).join(", ");
    console.log(`  ${(e.framework + "/" + e.template).padEnd(28)} runtime[${e.runtimeDepCount.toString().padStart(4)}]: ${r || "-"}`
      + (f && f !== r ? `   full: ${f}` : ""));
  }
  if (unresolved.length) {
    console.log("\nunresolved scaffolders (templates not statically extractable):");
    for (const u of unresolved) console.log(`  ${u.framework || u.pkg}: ${u.reason}`);
  }
}

main().catch((e) => { console.error("[templates] FAILED:", e); process.exit(1); });
