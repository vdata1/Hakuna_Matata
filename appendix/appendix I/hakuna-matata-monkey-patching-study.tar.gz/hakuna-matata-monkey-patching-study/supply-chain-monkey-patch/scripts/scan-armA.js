#!/usr/bin/env node
/**
 * Experiment 2, Arm A -- scan the curated known-modifier packages (fetched into
 * corpus/ via resolve-dataset.js + fetch-corpus.js) and produce the NAMED
 * benign-exemplar table Arm B cannot: which package overrides which built-in
 * method, in what RHS form, guarded or not, at import time or opt-in.
 *
 * Reuses scanSource (direct AST hits) + detectCoreJsExports (the core-js helper
 * signature). Attribution is per package. Not a base rate (Exp 2,
 * Arm A). Package code is never executed.
 *
 * Usage:  node scripts/scan-armA.js [--corpus results/armA-corpus.json]
 * Output: results/armA_hits.csv        per (package, distinct modification)
 *         results/armA-exemplars.json  per-package summary + Tier-A exemplar table
 */

const fs = require("node:fs");
const path = require("node:path");
const { parse, scanSource, tierOf, detectCoreJsExports, detectHelperProtoDefine } = require("./scan-monkeypatch.js");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const SCANNABLE = /\.(c|m)?jsx?$/;
const TS = /\.(c|m)?tsx?$/;
const MAX_FILE_BYTES = 10 * 1024 * 1024;
const log = (...a) => console.error("[armA-scan]", ...a);

function arg(flag, def) {
  const i = process.argv.indexOf(flag);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}
function listFiles(dir) {
  const out = [], stack = [dir];
  while (stack.length) {
    let entries; try { entries = fs.readdirSync(stack.pop(), { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      const p = path.join(e.parentPath ?? e.path, e.name);
      if (e.isDirectory()) stack.push(p); else if (e.isFile()) out.push(p);
    }
  }
  return out;
}

function main() {
  const manifestPath = path.resolve(arg("--corpus", path.join(RESULTS, "armA-corpus.json")));
  if (!fs.existsSync(manifestPath)) throw new Error(`missing ${manifestPath}; run resolve-dataset.js + fetch-corpus.js --dataset results/armA-dataset.json`);
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  log(`corpus: ${path.basename(manifestPath)} (${manifest.packages.length} packages)`);

  const rows = [];           // flat, deduped per (package, builtin, target, method, source)
  const perPackage = [];

  for (const pkg of manifest.packages) {
    const dir = path.join(ROOT, pkg.dir);
    const files = listFiles(dir);
    const byKey = new Map();  // key -> hit (+ importTime OR'd, first file/line)

    for (const file of files) {
      if (TS.test(file) || !SCANNABLE.test(file)) continue;
      let src;
      try { if (fs.statSync(file).size > MAX_FILE_BYTES) continue; src = fs.readFileSync(file, "utf8"); }
      catch { continue; }
      let ast; try { ast = parse(src); } catch { continue; }
      const rel = path.relative(dir, file);

      // direct AST hits
      let hits = [];
      try { hits = scanSource(src, ast); } catch { hits = []; }
      for (const h of hits) {
        if (h.shadowed) continue;
        const key = `direct|${h.builtin}|${h.target}|${h.method}`;
        const rec = byKey.get(key);
        if (rec) { rec.importTime = rec.importTime || h.importTime; }
        else byKey.set(key, {
          source: "direct", builtin: h.builtin, target: h.target, method: h.method ?? "",
          tier: h.tier ?? "", rhsClass: h.rhsClass ?? "", guarded: !!h.guarded,
          importTime: !!h.importTime, kind: h.kind, file: rel, line: h.line,
        });
      }
      // core-js helper signature
      let ex = []; try { ex = detectCoreJsExports(ast); } catch { ex = []; }
      for (const e of ex) for (const m of e.methods) {
        const key = `corejs|${e.builtin}|${e.target}|${m}`;
        if (!byKey.has(key)) byKey.set(key, {
          source: "corejs", builtin: e.builtin, target: e.target, method: m,
          tier: tierOf(e.builtin, e.target, m) ?? "", rhsClass: "semantics-preserving",
          guarded: true, importTime: true, kind: "corejs-export", file: rel, line: null,
        });
      }
      // define-properties helper (the es-shims pattern) -- opt-in via .shim()
      let hd = []; try { hd = detectHelperProtoDefine(ast); } catch { hd = []; }
      for (const h of hd) {
        const key = `helper-define|${h.builtin}|${h.target}|${h.method}`;
        if (!byKey.has(key)) byKey.set(key, {
          source: "helper-define", builtin: h.builtin, target: h.target, method: h.method,
          tier: tierOf(h.builtin, h.target, h.method) ?? "", rhsClass: h.rhsClass,
          guarded: false, importTime: false, kind: "helper-define", file: rel, line: null,
        });
      }
    }

    const hits = [...byKey.values()];
    for (const h of hits) rows.push({ package: pkg.name, version: pkg.version, ...h });

    const tiers = new Set(hits.map((h) => h.tier).filter(Boolean));
    const builtins = new Set(hits.map((h) => h.builtin));
    const forms = {}; for (const h of hits) forms[h.rhsClass || "?"] = (forms[h.rhsClass || "?"] || 0) + 1;
    perPackage.push({
      package: pkg.name, version: pkg.version,
      modifications: hits.length,
      viaDirect: hits.filter((h) => h.source === "direct").length,
      viaCorejsSignature: hits.filter((h) => h.source === "corejs").length,
      viaHelperDefine: hits.filter((h) => h.source === "helper-define").length,
      tiers: [...tiers].sort(),
      distinctBuiltins: builtins.size,
      importTimeHits: hits.filter((h) => h.importTime).length,
      optInHits: hits.filter((h) => !h.importTime).length,
      forms,
    });
    log(`  ${pkg.name}: ${hits.length} mods (direct ${perPackage.at(-1).viaDirect} / corejs ${perPackage.at(-1).viaCorejsSignature}), tiers=${[...tiers].sort().join("")||"-"}`);
  }

  // ---- CSV ----
  const COLS = ["package", "version", "source", "builtin", "target", "method", "tier",
    "rhsClass", "guarded", "importTime", "kind", "file", "line"];
  const esc = (v) => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  rows.sort((a, b) => a.package.localeCompare(b.package) || String(a.builtin).localeCompare(b.builtin) || String(a.method).localeCompare(String(b.method)));
  fs.writeFileSync(path.join(RESULTS, "armA_hits.csv"),
    [COLS.join(","), ...rows.map((r) => COLS.map((c) => esc(r[c])).join(","))].join("\n") + "\n");

  // ---- Tier-A exemplar table: method -> packages that override it ----
  const tierAExemplars = {};
  for (const r of rows) {
    if (r.tier !== "A") continue;
    const m = `${r.builtin}.${r.method}`;
    (tierAExemplars[m] ||= new Set()).add(r.package);
  }
  const tierATable = Object.fromEntries(
    Object.entries(tierAExemplars).sort((a, b) => b[1].size - a[1].size).map(([m, s]) => [m, [...s].sort()]));

  const summary = {
    generated: "2026-08-10",
    corpus: path.basename(manifestPath),
    note: "Arm A is selection-on-outcome (curated modifiers): exemplars + form characterization, NOT a base rate. importTime=false means the patch is opt-in (e.g. es-shims .shim()); import-time patches apply merely on require.",
    packagesScanned: manifest.packages.length,
    totalModifications: rows.length,
    perPackage,
    tierA_exemplars: tierATable,       // "String.includes" -> [packages]
  };
  fs.writeFileSync(path.join(RESULTS, "armA-exemplars.json"), JSON.stringify(summary, null, 2) + "\n");

  log(`total modifications: ${rows.length} across ${manifest.packages.length} packages`);
  log(`Tier-A methods with named exemplars: ${Object.keys(tierATable).length}`);
  log("wrote results/armA_hits.csv, results/armA-exemplars.json");
  console.log(JSON.stringify({ packages: manifest.packages.length, modifications: rows.length, tierAMethods: Object.keys(tierATable).length }, null, 2));
}

if (require.main === module) {
  try { main(); } catch (err) { console.error("[armA-scan] FAILED:", err); process.exit(1); }
}
