#!/usr/bin/env node
/**
 * Experiment 2, Arm B -- fetch the JavaScript bundles that popular websites
 * actually ship to browsers, so we can scan the code that RUNS IN THE WILD for
 * builtin modification. Applications are absent from an npm-download-ranked
 * population, but their shipped bundles are on the public
 * web -- and that is where @babel/preset-env injects core-js polyfills.
 *
 * STATIC CRAWL, no browser (Exp 2, Arm B):
 *   Per domain:
 *     1. GET https://<domain>/ with a browser-like UA, following redirects.
 *     2. Parse the returned HTML for script references -- NOT just <script src>:
 *          <script src>, <script type=module src>,
 *          <link rel=modulepreload href>   (webpack/vite vendor chunks --
 *                                            where core-js lives),
 *          <link rel=preload as=script href>
 *     3. Resolve to absolute URLs (cross-origin CDN hosts included -- that is
 *        what the browser loads), dedupe, and download each JS asset under
 *        per-site caps (MAX_ASSETS, MAX_ASSET_BYTES) to bound cost.
 *     4. Content-address each asset into cache/bundles/<sha256>.js so re-runs
 *        and cross-site shared CDN assets are free.
 *
 * Why static is enough for THIS measurement: babel preset-env injects core-js
 * into the entry/vendor chunk at BUILD time, and that chunk (plus the vendor
 * chunks it modulepreloads) is referenced in the initial HTML. Prototype
 * modification concentrates there, not in lazy route chunks. A Playwright pass
 * over a small sample (scripts/validate-bundles-headless.js) checks the
 * undercount. Arm-B prevalence is reported as a LOWER BOUND regardless.
 *
 * Site code is NEVER executed: fetch + hash + write are the only operations.
 * No eval, no browser, no rendering.
 *
 * Usage:  node scripts/fetch-bundles.js [--list cache/tranco-top1000-PYG5J.csv]
 *                                       [--n 1000] [--out results/bundles.json]
 * Output: cache/bundles/            content-addressed JS assets
 *         results/bundles.json      manifest: domain -> [{url, sha, bytes, kind}]
 */

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const CONCURRENCY = 8;
const MAX_RETRIES = 3;
const NAV_TIMEOUT_MS = 20000;      // per HTTP request
const MAX_ASSETS = 12;             // JS assets downloaded per site (cost cap)
const MAX_ASSET_BYTES = 8_000_000; // skip any single asset larger than this
const MAX_HTML_BYTES = 5_000_000;  // stop reading HTML past this
// A real browser UA: many sites 403 non-browser agents. This only makes us
// look like Chrome to a static GET; we still never execute anything.
const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const BUNDLES = path.join(CACHE, "bundles");
const RESULTS = path.join(ROOT, "results");

const log = (...a) => console.error("[bundles]", ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Fetch with timeout + retry (mirrors fetch-corpus.js download())
// ---------------------------------------------------------------------------

async function httpGet(url, { accept } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), NAV_TIMEOUT_MS);
    try {
      const res = await fetch(url, {
        redirect: "follow",
        signal: ctl.signal,
        headers: {
          "user-agent": UA,
          accept: accept || "*/*",
          "accept-language": "en-US,en;q=0.9",
        },
      });
      clearTimeout(timer);
      if (res.status === 404 || res.status === 410) return { missing: true, status: res.status };
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return { res, finalUrl: res.url };
    } catch (err) {
      clearTimeout(timer);
      lastErr = err;
      if (attempt < MAX_RETRIES) await sleep(400 * 2 ** attempt + Math.floor(Math.random() * 200));
    }
  }
  throw lastErr;
}

/** Read a response body up to `cap` bytes, aborting the stream once exceeded. */
async function readCapped(res, cap) {
  const reader = res.body.getReader();
  const chunks = [];
  let total = 0;
  let truncated = false;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > cap) { truncated = true; try { await reader.cancel(); } catch {} break; }
    chunks.push(value);
  }
  return { buf: Buffer.concat(chunks.map((c) => Buffer.from(c))), truncated };
}

// ---------------------------------------------------------------------------
// HTML script-reference extraction (regex, not a DOM -- we only need URLs)
// ---------------------------------------------------------------------------

/**
 * Pull every script-ish URL out of an HTML document. Regex rather than a parser
 * because we want speed and resilience on malformed markup, and we only need
 * the `src`/`href` strings -- not a faithful DOM. Kinds are recorded so the
 * report can distinguish an entry <script> from a modulepreloaded vendor chunk.
 */
function extractScriptRefs(html) {
  const refs = [];
  const push = (url, kind) => { if (url) refs.push({ url: url.trim(), kind }); };

  // <script ... src="...">  (covers type=module too -- attr order-independent)
  for (const m of html.matchAll(/<script\b[^>]*\bsrc\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))[^>]*>/gi)) {
    const isModule = /\btype\s*=\s*("|')?module\1?/i.test(m[0]);
    push(m[2] ?? m[3] ?? m[4], isModule ? "script-module" : "script");
  }
  // <link rel="modulepreload" href="..."> and rel="preload" as="script"
  for (const m of html.matchAll(/<link\b[^>]*>/gi)) {
    const tag = m[0];
    const rel = (tag.match(/\brel\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/i) || [])[0] || "";
    const href = tag.match(/\bhref\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/i);
    if (!href) continue;
    const url = href[2] ?? href[3] ?? href[4];
    if (/modulepreload/i.test(rel)) push(url, "modulepreload");
    else if (/preload/i.test(rel) && /\bas\s*=\s*("|')?script/i.test(tag)) push(url, "preload-script");
  }
  return refs;
}

/**
 * Extract inline <script> bodies (no src). These are part of what the browser
 * runs, and some sites (e.g. google.com) inline their bootstrap JS rather than
 * linking a bundle -- so without this they read as "no-js-refs". We skip
 * non-executable script types (JSON, importmap, ld+json, templates).
 */
function extractInlineScripts(html) {
  const bodies = [];
  for (const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
    const attrs = m[1] || "";
    if (/\bsrc\s*=/i.test(attrs)) continue; // external -- handled as a ref
    const type = (attrs.match(/\btype\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))/i) || [])[0] || "";
    // Empty type, text/javascript, or module are executable; everything else
    // (application/json, importmap, application/ld+json, text/x-template) is not.
    if (type && !/module|(text|application)\/(java|ecma)script/i.test(type)) continue;
    const body = m[2].trim();
    if (body.length >= 40) bodies.push(body); // skip trivial one-liners/config blips
  }
  return bodies;
}

/** Resolve, filter, and dedupe refs into absolute http(s) JS URLs. */
function resolveRefs(refs, baseUrl) {
  const seen = new Set();
  const out = [];
  for (const { url, kind } of refs) {
    let abs;
    try { abs = new URL(url, baseUrl); } catch { continue; }
    if (abs.protocol !== "https:" && abs.protocol !== "http:") continue; // skip data:, blob:
    const key = abs.href;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ url: abs.href, kind });
  }
  return out;
}

const looksLikeJs = (url, contentType) =>
  /javascript|ecmascript|module/i.test(contentType || "") ||
  /\.m?js(\?|#|$)/i.test(url);

// ---------------------------------------------------------------------------
// Per-domain crawl
// ---------------------------------------------------------------------------

async function crawlDomain(domain) {
  const rec = { domain, status: "ok", assets: [], notes: [] };

  // Try https first; the redirect handler covers http->https and www<->apex.
  let page;
  try {
    page = await httpGet(`https://${domain}/`, {
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    });
  } catch (err) {
    return { ...rec, status: "html-fetch-failed", error: String(err.message || err) };
  }
  if (page.missing) return { ...rec, status: `html-${page.status}` };

  const ctype = page.res.headers.get("content-type") || "";
  if (!/html/i.test(ctype)) {
    // Infra/CDN/API domains (gtld-servers.net, akamai.net, ...) land here.
    return { ...rec, status: "not-html", contentType: ctype };
  }
  const { buf: htmlBuf, truncated } = await readCapped(page.res, MAX_HTML_BYTES);
  if (truncated) rec.notes.push("html-truncated");
  const html = htmlBuf.toString("utf8");
  rec.finalUrl = page.finalUrl;

  // Inline <script> bodies: hashed and cached exactly like external assets, so
  // the scanner treats them uniformly. kind="inline", no URL.
  const inline = extractInlineScripts(html);
  for (const body of inline) {
    const buf = Buffer.from(body, "utf8");
    const sha = crypto.createHash("sha256").update(buf).digest("hex");
    const file = path.join(BUNDLES, `${sha}.js`);
    if (!fs.existsSync(file)) fs.writeFileSync(file, buf);
    rec.assets.push({ url: `${page.finalUrl}#inline`, kind: "inline", status: "ok", sha, bytes: buf.length });
  }
  rec.inlineFound = inline.length;

  const refs = resolveRefs(extractScriptRefs(html), page.finalUrl);
  rec.refsFound = refs.length;
  if (!refs.length && !inline.length) { rec.status = "no-script-refs"; return rec; }

  let downloaded = 0;
  for (const { url, kind } of refs) {
    if (downloaded >= MAX_ASSETS) { rec.notes.push(`asset-cap-hit(${refs.length} refs)`); break; }
    if (!looksLikeJs(url)) continue; // cheap pre-filter; confirmed by content-type below

    let asset;
    try {
      asset = await httpGet(url, { accept: "*/*" });
    } catch (err) {
      rec.assets.push({ url, kind, status: "fetch-failed", error: String(err.message || err) });
      continue;
    }
    if (asset.missing) { rec.assets.push({ url, kind, status: `${asset.status}` }); continue; }

    const act = asset.res.headers.get("content-type") || "";
    if (!looksLikeJs(url, act)) { rec.assets.push({ url, kind, status: "not-js", contentType: act }); continue; }

    const { buf, truncated: tr } = await readCapped(asset.res, MAX_ASSET_BYTES);
    if (tr) { rec.assets.push({ url, kind, status: "too-large" }); continue; }

    const sha = crypto.createHash("sha256").update(buf).digest("hex");
    const file = path.join(BUNDLES, `${sha}.js`);
    if (!fs.existsSync(file)) fs.writeFileSync(file, buf);
    rec.assets.push({ url, kind, status: "ok", sha, bytes: buf.length });
    downloaded++;
  }

  const okAssets = rec.assets.filter((a) => a.status === "ok");
  if (!okAssets.length) rec.status = rec.assets.length ? "no-js-assets" : "no-js-refs";
  return rec;
}

// ---------------------------------------------------------------------------
// Site list + pool (pooled() copied from fetch-corpus.js conventions)
// ---------------------------------------------------------------------------

function loadSiteList(file, n) {
  const rows = fs
    .readFileSync(file, "utf8")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => l.split(",").pop().trim()); // "rank,domain" -> domain
  return rows.slice(0, n);
}

async function pooled(items, worker, label) {
  const out = new Array(items.length);
  const started = Date.now();
  let next = 0;
  let done = 0;
  async function run() {
    while (next < items.length) {
      const i = next++;
      out[i] = await worker(items[i], i);
      done++;
      if (done % 50 === 0 || done === items.length) {
        const rate = done / ((Date.now() - started) / 1000);
        const eta = Math.round((items.length - done) / rate);
        log(`  ${label}: ${done}/${items.length}` +
            (done < items.length ? ` (${rate.toFixed(1)}/s, ~${eta}s left)` : ""));
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, items.length) }, run));
  return out;
}

function arg(flag, def) {
  const i = process.argv.indexOf(flag);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}

async function main() {
  fs.mkdirSync(BUNDLES, { recursive: true });
  fs.mkdirSync(RESULTS, { recursive: true });

  const listFile = path.resolve(arg("--list", path.join(CACHE, "tranco-top1000-PYG5J.csv")));
  const n = Number(arg("--n", "1000"));
  const outPath = path.resolve(arg("--out", path.join(RESULTS, "bundles.json")));

  const domains = loadSiteList(listFile, n);
  log(`site list: ${path.basename(listFile)} (${domains.length} domains)`);

  const results = await pooled(domains, (d) => crawlDomain(d), "domains");

  const withJs = results.filter((r) => r.assets.some((a) => a.status === "ok"));
  const allOkAssets = results.flatMap((r) => r.assets.filter((a) => a.status === "ok"));
  const uniqueAssets = new Set(allOkAssets.map((a) => a.sha));

  // status histogram, so blocked/empty domains are visible not silent
  const statusHist = {};
  for (const r of results) statusHist[r.status] = (statusHist[r.status] || 0) + 1;

  const manifest = {
    generated: new Date().toISOString().slice(0, 10),
    list: path.basename(listFile),
    caps: { MAX_ASSETS, MAX_ASSET_BYTES, MAX_HTML_BYTES, NAV_TIMEOUT_MS },
    method:
      "static crawl; no browser; site code never executed. Prevalence is a LOWER BOUND: " +
      "runtime-injected and lazy/route-split chunks are not loaded.",
    counts: {
      domains: results.length,
      domainsWithJsAsset: withJs.length,
      okAssets: allOkAssets.length,
      uniqueAssets: uniqueAssets.size,
      totalAssetBytes: allOkAssets.reduce((n, a) => n + (a.bytes || 0), 0),
    },
    statusHistogram: statusHist,
    domains: results,
  };
  fs.writeFileSync(outPath, JSON.stringify(manifest, null, 2) + "\n");

  log(`domains with >=1 JS asset: ${withJs.length}/${results.length}`);
  log(`unique JS assets cached:   ${uniqueAssets.size} (${allOkAssets.length} refs)`);
  log("status:", JSON.stringify(statusHist));
  log(`wrote ${outPath}`);
  console.log(JSON.stringify(manifest.counts, null, 2));
}

if (require.main === module) {
  main().catch((err) => {
    console.error("[bundles] FAILED:", err);
    process.exit(1);
  });
}

module.exports = { extractScriptRefs, extractInlineScripts, resolveRefs, looksLikeJs, crawlDomain };
