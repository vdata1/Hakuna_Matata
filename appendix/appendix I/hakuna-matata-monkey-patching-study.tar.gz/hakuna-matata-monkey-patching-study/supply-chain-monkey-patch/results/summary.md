# Monkey-patch prevalence in the top 1000 npm packages

**Snapshot:** 2026-08-03 · **Population:** `AugTop1K_npm.json` · **Scan:** `scan-meta.json`

## Headline

> **9 of 1000 packages (0.9%) mutate a builtin prototype**
> in their published code. **9 (0.9%) do so unconditionally**,
> replacing a method that already exists.

This is a **low** number, materially weaker than the study hypothesised. It is
reported as measured, per the handoff's instruction not to massage it. §"What
this does and does not show" below explains what the figure does and does not
cover — in particular a **detection floor** that makes it a lower bound.

Alternative denominator: excluding the 60 packages that ship no
parseable JavaScript at all (native binaries, pure-data packages), prevalence is
9/940 = **1.0%**.

## Population and method

- **Population:** top 1000 npm packages by weekly downloads on 2026-08-03, pinned to the version that was `latest` that day. Built by download-counts@2.20260301.0 (pinned immutable npm artifact, read as data; used ordinally only), re-scored against npm's own last-week downloads API.
- **Artefact scanned:** the **published tarball**, not the GitHub repository — transpiled and bundled output is what actually runs in users' applications.
- **Detection:** AST (acorn), not grep. 32,334 JavaScript files parsed, 15 parse failures (**0.05%**).
- **Detector fixtures:** `scripts/test-detector.js` — 32 cases covering both what must be caught and what must not (property reads, strings, comments, user classes).

## Guarded vs unguarded

The distinction §4 flags as the main validity threat. A guarded polyfill
(`if (!X.prototype.m) X.prototype.m = …`) is a no-op on a modern runtime; an
unguarded assignment replaces a working method.

|  | packages | of population |
|---|---|---|
| Unguarded (replaces an existing method) | 9 | 0.9% |
| Guarded only (polyfill pattern) | 0 | 0.0% |

Notably **every** package found mutating a prototype does so unguarded at least
once. The "it's all benign polyfills" rebuttal does not apply to this sample —
but the sample is small enough that this should not be over-read.

## Barrier-relevant methods

Methods that npm security patches actually lean on as barriers (`includes`,
`startsWith`, `indexOf`, `test`, `hasOwnProperty`, …; full list in
`scan-meta.json`).

|  | packages | of population |
|---|---|---|
| Packages overriding a barrier-relevant method | 4 | 0.4% |
| …of those, unguarded | 3 | 0.3% |

Unguarded overrides of barrier-relevant methods:

| package | rank | method | kind | location |
|---|---|---|---|---|
| `core-js` | 701 | `Function.prototype.toString` | assignment | `internals/make-built-in.js:53` |
| `@sentry/core` | 876 | `Function.prototype.toString` | assignment | `build/esm/integrations/functiontostring.js:13` |
| `next` | 887 | `Function.prototype.toString` | assignment | `dist/bundle-analyzer/_next/static/chunks/a6dad97d9634a72d.js:1` |

## Every package with a prototype mutation

| package | rank | mutation | guard | barrier method | category |
|---|---|---|---|---|---|
| `once` | 211 | Function.prototype.once<br>Function.prototype.onceStrict | **unguarded** | - | other |
| `chai` | 388 | Object.prototype.should | **unguarded** | - | other |
| `d3-array` | 450 | Array.prototype. | **unguarded** | - | other |
| `core-js` | 701 | Function.prototype.toString | **unguarded** | yes | transpiler-runtime |
| `axe-core` | 748 | Array.prototype.find<br>Array.prototype.findIndex<br>Array.prototype.flat<br>Array.prototype.includes<br>Array.prototype.some<br>Object.prototype.__global__<br>Object.prototype.__magic__<br>String.prototype.includes | **unguarded** | yes | other |
| `@sentry/core` | 876 | Function.prototype.toString | **unguarded** | yes | instrumentation-apm |
| `next` | 887 | Array.prototype.abbrev<br>Array.prototype.at<br>Array.prototype.flat<br>Array.prototype.flatMap<br>Function.prototype.once<br>Function.prototype.onceStrict<br>Function.prototype.toString<br>Object.prototype.abbrev<br>Promise.prototype.finally<br>String.prototype.trimEnd<br>String.prototype.trimStart<br>Symbol.prototype.description | **unguarded** | yes | other |
| `array.prototype.tosorted` | 935 | Array.prototype.3 | **unguarded** | - | other |
| `bowser` | 954 | Array.prototype.constructor | **unguarded** | - | other |

## By builtin

| builtin | hits | packages |
|---|---|---|
| `Array` | 12 | 5 |
| `Function` | 7 | 4 |
| `Object` | 4 | 3 |
| `String` | 3 | 2 |
| `Promise` | 1 | 1 |
| `Symbol` | 1 | 1 |

## By method

| method | hits | barrier-relevant |
|---|---|---|
| `toString` | 3 | **barrier** |
| `once` | 2 | - |
| `onceStrict` | 2 | - |
| `flat` | 2 | - |
| `includes` | 2 | **barrier** |
| `abbrev` | 2 | - |
| `should` | 1 | - |
| `(computed)` | 1 | - |
| `find` | 1 | **barrier** |
| `findIndex` | 1 | **barrier** |
| `some` | 1 | **barrier** |
| `__global__` | 1 | - |
| `__magic__` | 1 | - |
| `at` | 1 | - |
| `flatMap` | 1 | - |
| `finally` | 1 | - |
| `trimEnd` | 1 | - |
| `trimStart` | 1 | - |
| `description` | 1 | - |
| `3` | 1 | - |
| `constructor` | 1 | - |

## Category

| category | packages |
|---|---|
| other | 7 |
| transpiler-runtime | 1 |
| instrumentation-apm | 1 |

## Writes to the global object itself (tracked separately)

Assignments to non-prototype properties of a builtin — `Array.isArray = …`,
`Object.assign = …`. These do not touch a prototype, so they are excluded from
the headline, but they are the same capability: mutating a shared global.

**41 of 1000 packages (4.1%)** do this.

| builtin | hits |
|---|---|
| `Error` | 55 |
| `Object` | 11 |
| `String` | 3 |
| `Symbol` | 3 |
| `Array` | 3 |
| `Math` | 1 |

## Excluded as shadowed

208 hits were excluded because the builtin's name resolves to a
**local binding**, not the global — verified by per-hit scope-chain resolution
(parameters, `var` hoisting, `let`/`const`, imports, catch bindings).

Every one was `Promise` or `DataView`, and spot-checking confirms the pattern:
these are bundled polyfill *implementations* (`bluebird` building out its own
`Promise` class, `axe-core` bundling a `DataView` shim) that patch a local
constructor of the same name. Counting them would have inflated the headline by
roughly an order of magnitude.

## What this does and does not show

**Detection floor — the most important caveat.** The scan detects *syntactic*
mutation: `X.prototype.m = …`, `Object.defineProperty(X.prototype, …)`, a
direct alias, `setPrototypeOf`. It **cannot** see mutation performed through
indirection, and the ecosystem's most prolific builtin patcher works exactly
that way. `core-js` patches via `$({ target: 'Array', proto: true }, {…})`,
which routes through `internals/export.js` to `defineBuiltIn(O, key, value)`
where the write is `O[key] = value` on a dynamically obtained object. No
syntactic `Array.prototype.includes =` exists anywhere in core-js. The same is
true of any library that centralises patching behind a helper.

**Therefore 0.9% is a lower bound on syntactic mutation, and
says nothing about the true rate of runtime builtin mutation**, which this
method cannot measure. A dataflow-based analysis (CodeQL, or an interprocedural
alias analysis) would be required to close the gap.

Other limits:

- **Prevalence is not exploitability.** This measures how often ordinary code violates the assumption that builtins behave normally. It does not show any case is attacker-controllable.
- **Bundled code** is scanned and attributed to the bundling package. Correct for "what runs in your app", but it means a vendored dependency's mutation is credited to its host.
- **TypeScript is excluded** (13,917 files). acorn cannot parse it, and `.d.ts` interface augmentation is a type-level declaration, not a runtime mutation.
- **Population bias.** "Top by downloads" over-represents infrastructure and utility packages. Small, single-purpose utilities dominate the list and have little reason to patch builtins — which plausibly explains part of the low rate.
- **Guard detection is heuristic** (an enclosing conditional mentioning the method name), biased toward classifying hits as guarded, so the unguarded figure is conservative.

## Transitive reach (§5)

Direct prevalence understates installed impact, so we also measured how many of
the top 1000 have a builtin-patching package anywhere in their **runtime**
dependency closure (name-level graph over 1,808 packages, depth 12).

| edges followed | roots | % of population | % download-weighted |
|---|---|---|---|
| Runtime deps (`dependencies` + `optionalDependencies`) | 29 | 2.9% | 1.9% |
| Including `peerDependencies` | 42 | 4.2% | 3% |

**`core-js` does not appear in any root's runtime closure.** Zero of the top
1000 declare it as a runtime or peer dependency; 20 declare it as a
*devDependency*, and only 3 packages in the entire graph depend on it at
runtime. core-js does not travel through the published dependency graph — it is
injected into **application** builds by `@babel/preset-env`'s `useBuiltIns`,
and the application adds it as its own direct dependency.

## Three independent measurements

| method | packages | prevalence |
|---|---|---|
| Syntactic prototype mutation (AST) | 9/1000 | 0.9% |
| Runtime-dependency reach to a patcher | 29/1000 | 2.9% |
| Published output containing injected core-js imports | 1/1000 | 0.1% |

Three methods with **different and largely non-overlapping blind spots** agree
that builtin patching is uncommon in this population. That convergence matters:
it means the low figure is not an artefact of the syntactic detector's
limitations. A detection gap cannot explain all three.

Packages shipping injected core-js imports: `next`.

## Application starter templates

Because the population above is libraries, we also asked the application-side
question directly: **do the default apps produced by framework scaffolders ship
a builtin-mutating package?** Template manifests were read from scaffolder
tarballs and dependency closures resolved from registry metadata — nothing was
scaffolded, installed, or built (§8).

| template | runtime deps | builtin patchers in runtime tree |
|---|---|---|
| `angular/default` | 10 | — |
| `next/app-router-ts` | 54 | `next` |
| `react-cra/default` | 1131 | `core-js`, `core-js-pure`, `once`, `axe-core`, `array.prototype.tosorted`, `core-js-compat` |
| `svelte/addon` | 0 | — |
| `svelte/demo` | 0 | — |
| `svelte/library` | 0 | — |
| `svelte/minimal` | 0 | — |
| `vite/lit` | 6 | — |
| `vite/lit-ts` | 6 | — |
| `vite/preact` | 1 | — |
| `vite/preact-ts` | 1 | — |
| `vite/qwik` | 34 | — |
| `vite/qwik-ts` | 34 | — |
| `vite/react` | 3 | — |
| `vite/react-ts` | 3 | — |
| `vite/solid` | 4 | — |
| `vite/solid-ts` | 4 | — |
| `vite/svelte` | 0 | — |
| `vite/svelte-ts` | 0 | — |
| `vite/vanilla` | 0 | — |
| `vite/vanilla-ts` | 0 | — |
| `vite/vue` | 24 | — |
| `vite/vue-ts` | 24 | — |
| `vue/default` | 24 | — |

**2 of 24** templates across 6 frameworks carry a
patcher in the runtime tree — and one of those two is an attribution artefact:
`next` is flagged only because its tarball contains a prebuilt
`dist/bundle-analyzer/` UI (with its own `404.html`) that is not exported from
the package and never loads in a user's application.

**Corrected, exactly one template — `react-cra` — genuinely ships a builtin
patcher into an application's realm**, via a concrete two-hop runtime path:

```
react-scripts → react-app-polyfill → core-js
```

`react-app-polyfill` declares `core-js`, `promise`, `whatwg-fetch`,
`regenerator-runtime` and `object-assign` as direct dependencies.

The split is stark and it is **generational**, not random:

- **Legacy toolchain** — `create-react-app` resolves **1,131** runtime dependencies and pulls in `core-js`, `core-js-pure`, and `core-js-compat`. CRA is now deprecated.
- **Modern toolchains** — every Vite template (16), SvelteKit (4), Vue, Angular and Next's app router resolve between **0 and 54** runtime dependencies and contain **no** builtin patcher. Angular's current default is zoneless, so even `zone.js` — historically guaranteed in every Angular app — is gone.

The ecosystem moved away from polyfill injection. Evergreen browser targets and
esbuild/Rollup-based tooling removed the reason to ship `core-js`.

**Limitation:** this measures the *installed tree*, not build-time injection. A
bundler that injects `core-js` because of a `browserslist` target adds code no
manifest declares. Detecting that requires building each template in a sandbox —
i.e. deliberately executing untrusted code, which was not done here.

## The installed base: real applications

171 applications with a resolvable production dependency tree, from the
**externally curated** `awesome-selfhosted` catalogue (193 non-archived
Node.js/JS/TS entries, 173 with a parseable lockfile). The population is
curated by a third party, which keeps our own app-vs-library judgement out of the
denominator — necessary, because a GitHub-topic classifier left 72% of repos
unclassified and 58 of 126 search-selected "apps" were library monorepos.

Lockfiles give the **fully resolved** tree, so unlike every other stage of this
study there is no version-range approximation.

| measure | apps | share |
|---|---|---|
| Ships an **import-time** patcher to production | 51/171 | **29.8%** |
| Ships `core-js` to production | 48/171 | 28.1% |

Lockfiles parsed, by format: 79 pnpm, 176 npm, 12 yarn-berry, 36 yarn-classic. 58 repositories contain more than one lockfile; all are parsed and their production sets unioned.

Applications shipping an import-time patcher to production (top by stars):

| application | stars | patcher |
|---|---|---|
| `n8n-io/n8n` | 199,568 | `core-js` |
| `hoppscotch/hoppscotch` | 79,983 | `core-js` |
| `nocodb/nocodb` | 64,429 | `core-js` |
| `laurent22/joplin` | 55,846 | `core-js` |
| `TryGhost/Ghost` | 54,694 | `core-js` |
| `calcom/cal.diy` | 47,290 | `core-js` |
| `DIYgod/RSSHub` | 45,624 | `core-js` |
| `danny-avila/LibreChat` | 41,724 | `zone.js` |
| `outline/outline` | 40,014 | `core-js` |
| `ToolJet/ToolJet` | 38,294 | `core-js` |
| `Requarks/wiki` | 28,721 | `core-js` |
| `Budibase/budibase` | 28,182 | `core-js` |
| `hcengineering/platform` | 27,246 | `core-js` |
| `docmost/docmost` | 21,274 | `core-js` |
| `linkwarden/linkwarden` | 19,355 | `core-js` |
| `alam00000/bentopdf` | 14,531 | `core-js` |
| `alexta69/metube` | 14,346 | `zone.js`, `core-js` |
| `documenso/documenso` | 14,284 | `core-js` |
| `HabitRPG/habitica` | 14,044 | `core-js` |
| `advplyr/audiobookshelf` | 13,880 | `core-js` |

**Method notes.** Discovery walks the full recursive git tree, so an application
whose JavaScript lives in a subdirectory is included — the earlier root-only
lookup silently dropped these (confirmed case: `frigate`, whose real lockfile is
`web/package-lock.json`). Paths under `node_modules`, tests, fixtures, examples
and docs are excluded as not-shipped. yarn is included: neither yarn variant
marks dev-only packages (verified — 0 of 29 berry lockfiles contain a
`devDependencies` key), so production roots are taken from each repository's own
`package.json` files and the lockfile supplies the edges.

**Validation.** Production-set ratios and dev-tool leakage were compared across
formats using npm as a control, since npm's `dev` flags are authoritative.
`typescript` appears in 24% and `@types/node` in 48% of npm-authoritative
production trees, so that leakage is genuine ecosystem behaviour — packages
declaring build tooling as runtime dependencies — not a parser artefact. yarn
classic sits below the npm baseline; pnpm sits above it, consistent with its
documented union-across-workspaces over-count.

## Cross-check against grep

A word-bounded grep for `<Builtin>.prototype.<m> =` matches 7 packages; the AST
scan finds 10. The two grep-only packages (`axios`, `eslint`) are **comments**
discussing prototype pollution. The five AST-only packages use `defineProperty`,
alias, or computed forms that grep structurally cannot see. This is the §3.2
prediction — grep drowns in strings and comments — confirmed on real data.
