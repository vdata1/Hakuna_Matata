#!/usr/bin/env node
/**
 * Quick check: run the study's real detectors over ONE small project
 * with a known answer, and assert what they find.
 *
 * This is not a reproduction of any published number -- it uses a synthetic
 * fixture, not the measured corpora. Its job is narrower and more useful for a
 * reviewer with limited time: confirm in seconds, and without fetching the
 * ~12 GB corpus, that the toolchain is intact and behaves as the paper claims
 * it does. Every stage calls the same functions the real pipeline calls.
 *
 * Four stages, matching the four code paths the study depends on:
 *
 *   1. built-in scan       supply-chain-monkey-patch/scripts/scan-monkeypatch.js
 *   2. server-mechanism    server-side-measure/scripts/detect-server-patch.js
 *   3. closure resolution  server-side-measure/scripts/rooted-closure.js
 *   4. dynamic probe       server-side-measure/scripts/{probe,s1-load}.js
 *
 * Stages 1-3 need the relevant arm's `npm install` (they parse with acorn);
 * stage 4 has no dependencies at all and always runs. Missing dependencies
 * SKIP a stage with an explanatory line rather than failing it.
 *
 * Usage: node smoke/run-smoke.js
 * Exit:  0 = every stage that ran passed, 1 = something failed
 */
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawnSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const CLIENT = path.join(ROOT, "supply-chain-monkey-patch");
const SERVER = path.join(ROOT, "server-side-measure");
const VENDOR = path.join(__dirname, "fixture-app", "vendor");

let pass = 0, fail = 0, skipped = 0;
const ok = (label, cond, detail) => {
  if (cond) { console.log("  PASS   " + label); pass++; }
  else { console.log("  FAIL   " + label + (detail ? "\n         got: " + detail : "")); fail++; }
};
const skip = (label, why) => { console.log("  SKIP   " + label + " -- " + why); skipped++; };
const head = (n, title) => console.log(`\n[${n}] ${title}`);

/** Load an arm's module, or null if its dependencies are not installed. */
function tryRequire(p) {
  try { return require(p); }
  catch (e) { return e.code === "MODULE_NOT_FOUND" ? null : (() => { throw e; })(); }
}
const src = (pkg) => fs.readFileSync(path.join(VENDOR, pkg, "index.js"), "utf8");

// ---------------------------------------------------------------------------
// 1. Built-in modification scanner (the Exp-1 / Arm-B detector)
// ---------------------------------------------------------------------------
head(1, "Built-in scan -- scan-monkeypatch.js over the fixture's packages");
const client = tryRequire(path.join(CLIENT, "scripts", "scan-monkeypatch.js"));
if (!client) {
  skip("all built-in scan checks", "run `npm install` in supply-chain-monkey-patch/");
} else {
  const scan = (pkg) => { const s = src(pkg); return client.scanSource(s, client.parse(s)); };

  const shim = scan("polyfill-shim");
  ok("guarded polyfill on the guard surface is caught, and marked guarded",
    shim.length === 1 && shim[0].builtin === "String" && shim[0].method === "includes" &&
    shim[0].tier === "A" && shim[0].guarded === true,
    JSON.stringify(shim));

  const eviljs = scan("guard-bypass");
  ok("unguarded constant-return override is caught, tier A, rhsClass constant-return",
    eviljs.length === 1 && eviljs[0].builtin === "Array" && eviljs[0].method === "includes" &&
    eviljs[0].tier === "A" && eviljs[0].guarded === false &&
    eviljs[0].rhsClass === "constant-return",
    JSON.stringify(eviljs));

  const instr = scan("stack-instrument");
  const keys = instr.map((h) => `${h.builtin}.${h.target}.${h.method}`).sort();
  ok("instrumentation on the broad surface is caught, incl. Function.prototype.toString",
    instr.length === 2 &&
    keys.join(" ") === "Error.static.prepareStackTrace Function.prototype.toString" &&
    instr.every((h) => h.tier === null),
    JSON.stringify(keys));

  ok("negative control produces zero hits (user class, string, non-global property)",
    scan("negative-control").length === 0, JSON.stringify(scan("negative-control")));

  ok("core-module wrapping is NOT reported as built-in modification",
    scan("fs-wrapper").length === 0, JSON.stringify(scan("fs-wrapper")));
}

// ---------------------------------------------------------------------------
// 2. Server-mechanism detector
// ---------------------------------------------------------------------------
head(2, "Server-mechanism scan -- detect-server-patch.js");
const serverDetect = tryRequire(path.join(SERVER, "scripts", "detect-server-patch.js"));
const serverParse = tryRequire(path.join(SERVER, "scripts", "scan-monkeypatch.js"));
if (!serverDetect || !serverParse) {
  skip("all server-mechanism checks", "run `npm install` in server-side-measure/");
} else {
  const sscan = (pkg) => { const s = src(pkg); return serverDetect.scanServerSource(s, serverParse.parse(s)); };

  const wrap = sscan("fs-wrapper");
  ok("fs.readFile wrap lands in the coremodule bucket, mechanism=wrap",
    wrap.length === 1 && wrap[0].bucket === "coremodule" && wrap[0].namespace === "fs" &&
    wrap[0].method === "readFile" && wrap[0].mechanism === "wrap" &&
    wrap[0].rhsClass === "wraps-original",
    JSON.stringify(wrap));

  const optin = sscan("optin-patcher");
  ok("opt-in patcher's fs.realpath wrap is detected statically",
    optin.length === 1 && optin[0].namespace === "fs" && optin[0].method === "realpath",
    JSON.stringify(optin));

  ok("negative control produces zero server-mechanism hits",
    sscan("negative-control").length === 0, JSON.stringify(sscan("negative-control")));
}

// ---------------------------------------------------------------------------
// 3. Dependency-closure resolution
// ---------------------------------------------------------------------------
head(3, "Closure resolution -- rooted-closure.js over the fixture lockfile");
const closureMod = tryRequire(path.join(SERVER, "scripts", "rooted-closure.js"));
if (!closureMod) {
  skip("all closure checks", "run `npm install` in server-side-measure/");
} else {
  const lock = fs.readFileSync(path.join(__dirname, "fixture-app", "package-lock.json"), "utf8");
  const res = closureMod.npmClosure(lock, (k) => k === "");
  const reached = [...res.reached].sort();

  ok("direct runtime dependencies are reached",
    ["fs-wrapper", "polyfill-shim", "stack-instrument"].every((p) => reached.includes(p)),
    reached.join(", "));
  ok("transitive dependency (guard-bypass, via polyfill-shim) is reached",
    reached.includes("guard-bypass"), reached.join(", "));
  ok("devDependency (dev-only-tool) is NOT in the server closure",
    !reached.includes("dev-only-tool"), reached.join(", "));
  ok("nothing left unresolved", res.unresolved === 0, String(res.unresolved));
}

// ---------------------------------------------------------------------------
// 4. Dynamic probe -- the S-1 load-and-diff, on a throwaway tree
// ---------------------------------------------------------------------------
head(4, "Dynamic probe -- probe.js + s1-load.js, one target per process");
const probeJs = path.join(SERVER, "scripts", "probe.js");
const loadJs = path.join(SERVER, "scripts", "s1-load.js");
if (!fs.existsSync(probeJs) || !fs.existsSync(loadJs)) {
  skip("all dynamic checks", "probe.js / s1-load.js missing");
} else {
  /**
   * The loader resolves its target from the CWD, so the fixture packages are
   * copied into a throwaway node_modules rather than shipped as one. The real
   * arm additionally wraps this in `sandbox-exec` with `(deny network*)`,
   * because it loads untrusted packages; these two are ours and inert, so the
   * envelope is not reproduced here.
   */
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "hm-smoke-"));
  try {
    fs.mkdirSync(path.join(tmp, "node_modules"));
    for (const p of ["stack-instrument", "optin-patcher"]) {
      fs.cpSync(path.join(VENDOR, p), path.join(tmp, "node_modules", p), { recursive: true });
    }
    fs.writeFileSync(path.join(tmp, "package.json"), '{"name":"smoke-probe-host","version":"1.0.0"}\n');

    const run = (pkg) => {
      const out = path.join(tmp, pkg + ".json");
      const r = spawnSync(process.execPath, ["--require", probeJs, loadJs, pkg, out],
        { cwd: tmp, encoding: "utf8", timeout: 30000 });
      if (r.status !== 0 || !fs.existsSync(out)) {
        return { error: (r.stderr || "").slice(0, 200) || `exit ${r.status}` };
      }
      return JSON.parse(fs.readFileSync(out, "utf8"));
    };
    const keysOf = (o, phase) => new Set((o.phases[phase] || []).map((c) => c.key));

    const instr = run("stack-instrument");
    const optin = run("optin-patcher");

    if (instr.error || optin.error) {
      ok("probe runs", false, instr.error || optin.error);
    } else {
      ok("probe snapshots the full built-in surface (>1500 slots)",
        instr.baselineSlots > 1500, String(instr.baselineSlots));

      const iImport = keysOf(instr, "importTime");
      ok("import-time patcher is observed patching at import",
        iImport.has("Function|prototype|toString") && iImport.has("Error|static|prepareStackTrace"),
        [...iImport].join(", ") || "(none)");

      // diff() is cumulative against the baseline, so opt-in-only = setdiff.
      const oImport = keysOf(optin, "importTime");
      const oOptIn = [...keysOf(optin, "optIn")].filter((k) => !oImport.has(k));
      ok("opt-in patcher changes NOTHING at import time",
        oImport.size === 0, [...oImport].join(", "));
      ok("opt-in patcher patches fs.realpath only after the explicit call",
        oOptIn.includes("fs|module|realpath"), oOptIn.join(", ") || "(none)");

      /**
       * The paper's central server-side null, on a live runtime: neither target
       * replaces a String/Array/RegExp prototype method a guard dispatches
       * through. Tiers come from the study's own tierOf, not a local copy.
       *
       * A null is only worth asserting alongside a positive control. Without
       * one this check passes trivially whenever the probe reports nothing --
       * including when the probe is broken -- so the observed-change count is
       * asserted first, and the null is only meaningful given a non-zero count.
       */
      const tierOf = client ? client.tierOf : (serverParse ? serverParse.tierOf : null);
      if (!tierOf) {
        skip("guard-dispatch surface is untouched", "needs either arm's npm install for tierOf");
      } else {
        const guardHits = [];
        let observed = 0;
        for (const o of [instr, optin]) {
          for (const phase of ["importTime", "optIn"]) {
            for (const c of o.phases[phase] || []) {
              observed++;
              const [ns, target, method] = c.key.split("|");
              const tier = tierOf(ns, target, method);
              if (tier === "A" || tier === "B") guardHits.push(o.target + ":" + c.key);
            }
          }
        }
        ok("positive control: the probe observed real modifications to diff against",
          observed > 0, String(observed));
        ok("guard-dispatch surface is untouched by both targets (the S-1 null)",
          observed > 0 && guardHits.length === 0,
          observed === 0 ? "vacuous -- probe observed nothing" : guardHits.join(", "));
      }
    }
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

// ---------------------------------------------------------------------------
console.log(`\n${pass} passed, ${fail} failed, ${skipped} skipped`);
if (skipped && !fail) {
  console.log("Skipped stages need `npm install` in the arm named above.");
}
process.exit(fail ? 1 : 0);
