#!/usr/bin/env node
/**
 * Fixtures for the rooted-closure traversal.
 *
 * The closure decides the study's denominator, so each supported lockfile format
 * is tested in both directions: a server root MUST reach its own runtime deps,
 * and MUST NOT reach a client workspace's deps or anything dev-only.
 *
 * Three cases here are regressions for bugs found against real repositories and
 * are labelled REGRESSION; they are the reason this file exists.
 *
 * Usage: node scripts/test-closure.js
 */
const { pnpmClosure, npmClosure, yarnBerryClosure, yarnClassicClosure } = require("./rooted-closure.js");

let pass = 0, fail = 0;
function check(label, actual) {
  const ok = actual === true || actual === undefined;
  console.log((ok ? "PASS" : "FAIL").padEnd(6), label);
  if (!ok) console.log("       ", actual);
  ok ? pass++ : fail++;
}
const has = (set, x) => set.has(x);
const expect = (cond, msg) => (cond ? true : msg);

// ---------------------------------------------------------------------------
// pnpm
// ---------------------------------------------------------------------------
const PNPM = `
lockfileVersion: '9.0'
importers:
  apps/server:
    dependencies:
      express:
        specifier: ^4.0.0
        version: 4.18.2
      '@repo/db':
        specifier: workspace:*
        version: link:../../packages/db
  apps/web:
    dependencies:
      core-js:
        specifier: ^3.0.0
        version: 3.36.0
  packages/db:
    dependencies:
      graceful-fs:
        specifier: ^4.0.0
        version: 4.2.11
snapshots:
  express@4.18.2:
    dependencies:
      body-parser: 1.20.1
  body-parser@1.20.1: {}
  core-js@3.36.0: {}
  graceful-fs@4.2.11: {}
`;
{
  const srv = pnpmClosure(PNPM, (d) => d === "apps/server");
  check("pnpm: server reaches its own dep", expect(has(srv.reached, "express"), [...srv.reached]));
  check("pnpm: server reaches transitively", expect(has(srv.reached, "body-parser"), [...srv.reached]));
  check("pnpm: workspace link followed into linked package's deps",
        expect(has(srv.reached, "graceful-fs"), [...srv.reached]));
  check("pnpm: client-only dep NOT in server closure",
        expect(!has(srv.reached, "core-js"), [...srv.reached]));
  const cli = pnpmClosure(PNPM, (d) => d === "apps/web");
  check("pnpm: client closure reaches core-js", expect(has(cli.reached, "core-js"), [...cli.reached]));
  check("pnpm: client closure excludes server dep", expect(!has(cli.reached, "express"), [...cli.reached]));
}

// ---------------------------------------------------------------------------
// npm
// ---------------------------------------------------------------------------
const NPM = JSON.stringify({
  lockfileVersion: 3,
  packages: {
    "": { dependencies: { express: "^4.0.0" }, devDependencies: { typescript: "^5.0.0" } },
    "node_modules/express": { dependencies: { "body-parser": "^1.0.0" } },
    "node_modules/body-parser": {},
    "node_modules/typescript": { dev: true },
  },
});
{
  const c = npmClosure(NPM, () => true);
  check("npm: root reaches prod dep", expect(has(c.reached, "express"), [...c.reached]));
  check("npm: transitive prod dep reached", expect(has(c.reached, "body-parser"), [...c.reached]));
  check("npm: devDependency NOT reached", expect(!has(c.reached, "typescript"), [...c.reached]));
}
// REGRESSION: sibling workspace paths outside the lockfile dir (`../plugins`).
// The walk-up must climb one segment at a time or the nested install is missed.
const NPM_SIBLING = JSON.stringify({
  lockfileVersion: 3,
  packages: {
    "": { dependencies: {} },
    "../plugins": { dependencies: {} },
    "../plugins/packages/dynamodb": { dependencies: { "@aws-sdk/client-dynamodb": "^3.0.0" } },
    "../plugins/node_modules/@aws-sdk/client-dynamodb": {},
  },
});
{
  const c = npmClosure(NPM_SIBLING, () => true);
  check("npm REGRESSION: segment-wise walk-up finds sibling-tree nested install",
        expect(has(c.reached, "@aws-sdk/client-dynamodb"), [...c.reached]));
}

// ---------------------------------------------------------------------------
// yarn berry
// ---------------------------------------------------------------------------
// REGRESSION: a workspace entry's lockfile `dependencies` MERGES devDependencies,
// so workspaces must be expanded from their real package.json instead.
const BERRY = `
__metadata:
  version: 8
"srv@workspace:apps/server":
  version: 0.0.0-use.local
  resolution: "srv@workspace:apps/server"
  dependencies:
    express: ^4.0.0
    vitest: ^1.0.0
"express@npm:^4.0.0":
  version: 4.18.2
  resolution: "express@npm:4.18.2"
  dependencies:
    body-parser: ^1.0.0
"body-parser@npm:^1.0.0":
  version: 1.20.1
  resolution: "body-parser@npm:1.20.1"
"vitest@npm:^1.0.0":
  version: 1.0.0
  resolution: "vitest@npm:1.0.0"
"undici@npm:^6.27.0":
  version: 6.27.0
  resolution: "undici@npm:6.27.0"
`;
{
  const manifests = [{ dir: "apps/server", pkg: { name: "srv", dependencies: { express: "^4.0.0" },
                                                  devDependencies: { vitest: "^1.0.0" } } }];
  const c = yarnBerryClosure(BERRY, (d) => d === "apps/server", manifests);
  check("berry: workspace reaches its runtime dep", expect(has(c.reached, "express"), [...c.reached]));
  check("berry: transitive reached", expect(has(c.reached, "body-parser"), [...c.reached]));
  check("berry REGRESSION: devDependency merged into the lockfile entry is NOT counted",
        expect(!has(c.reached, "vitest"), [...c.reached]));

  // REGRESSION: berry dedupes descriptors; a requested range absent from the file
  // must still resolve by name rather than dropping a real edge.
  const m2 = [{ dir: "apps/server", pkg: { name: "srv", dependencies: { undici: "^6.23.0" } } }];
  const c2 = yarnBerryClosure(BERRY, (d) => d === "apps/server", m2);
  check("berry REGRESSION: dedup mismatch resolves by name",
        expect(has(c2.reached, "undici") && c2.looseResolutions === 1, [...c2.reached, "loose=" + c2.looseResolutions]));
}

// ---------------------------------------------------------------------------
// yarn classic
// ---------------------------------------------------------------------------
const CLASSIC = `
# yarn lockfile v1

express@^4.0.0:
  version "4.18.2"
  resolved "https://registry.yarnpkg.com/express/-/express-4.18.2.tgz#abc"
  dependencies:
    body-parser "^1.0.0"

body-parser@^1.0.0:
  version "1.20.1"
  resolved "https://registry.yarnpkg.com/body-parser/-/body-parser-1.20.1.tgz#def"

core-js@^3.0.0:
  version "3.36.0"
  resolved "https://registry.yarnpkg.com/core-js/-/core-js-3.36.0.tgz#ghi"
`;
{
  const manifests = [
    { dir: "server", pkg: { name: "@app/server", dependencies: { express: "^4.0.0", "@app/db": "^1.0.0" } } },
    { dir: "db",     pkg: { name: "@app/db", dependencies: {} } },
    { dir: "web",    pkg: { name: "@app/web", dependencies: { "core-js": "^3.0.0" } } },
  ];
  const c = yarnClassicClosure(CLASSIC, manifests, (d) => d === "server");
  check("classic: server reaches its dep", expect(has(c.reached, "express"), [...c.reached]));
  check("classic: transitive reached", expect(has(c.reached, "body-parser"), [...c.reached]));
  check("classic: internal workspace followed by name, not counted as an npm package",
        expect(!has(c.reached, "@app/db") && c.importersSeen.includes("db"), c.importersSeen));
  check("classic: client-only dep NOT in server closure",
        expect(!has(c.reached, "core-js"), [...c.reached]));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
