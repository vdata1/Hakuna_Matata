#!/usr/bin/env node
/**
 * Which files inside a package does the SERVER actually load?
 *
 * The dependency closure answers "can the server reach this package". It does not
 * answer "does the server run this file", and the difference is not academic:
 * `bowser` ships a browser UMD bundle (`bundled.js`) with core-js inlined, so
 * scanning every .js file credited bowser with patching RegExp.prototype.exec on
 * 41.5% of server closures -- from a file no Node process ever requires. That is
 * the same client/server confusion the closure resolver removes, one level down.
 *
 * Entry resolution deliberately ignores the `browser` condition and the `browser`
 * field, then follows relative require/import edges within the package.
 *
 * Returns BOTH sets so the writeup can state a range rather than a point estimate:
 *   reachable -- files reachable from the package's Node entry points
 *   all       -- every .js file, the upper bound including browser bundles
 */
const fs = require("node:fs");
const path = require("node:path");
const walk = require("acorn-walk");

const EXTS = [".js", ".cjs", ".mjs", ".json"];

function readManifest(pkgDir) {
  try { return JSON.parse(fs.readFileSync(path.join(pkgDir, "package.json"), "utf8")); }
  catch { return null; }
}

/** Collect string targets from an `exports` subtree, skipping browser conditions. */
function collectExports(node, out) {
  if (typeof node === "string") { out.push(node); return; }
  if (!node || typeof node !== "object") return;
  for (const [key, val] of Object.entries(node)) {
    if (key === "browser" || key === "types" || key === "deno" || key === "worker") continue;
    collectExports(val, out);
  }
}

function resolveFile(p) {
  if (!p) return null;
  if (fs.existsSync(p) && fs.statSync(p).isFile()) return p;
  for (const e of EXTS) if (fs.existsSync(p + e)) return p + e;
  for (const e of EXTS) {
    const idx = path.join(p, "index" + e);
    if (fs.existsSync(idx)) return idx;
  }
  return null;
}

/** Node entry points of a package: exports conditions, main, bin, then index.js. */
function entryPoints(pkgDirRaw) {
  const pkgDir = path.resolve(pkgDirRaw);          // containment checks need absolute paths
  const pkg = readManifest(pkgDir);
  const out = [];
  if (pkg) {
    if (pkg.exports) { const e = []; collectExports(pkg.exports, e); out.push(...e); }
    if (typeof pkg.main === "string") out.push(pkg.main);
    if (typeof pkg.bin === "string") out.push(pkg.bin);
    else if (pkg.bin && typeof pkg.bin === "object") out.push(...Object.values(pkg.bin).filter((v) => typeof v === "string"));
  }
  out.push("index.js");
  const resolved = [];
  for (const rel of out) {
    if (typeof rel !== "string" || rel.startsWith("#")) continue;
    const f = resolveFile(path.resolve(pkgDir, rel));
    if (f && f.startsWith(pkgDir) && /\.(js|cjs|mjs)$/.test(f)) resolved.push(f);
  }
  return [...new Set(resolved)];
}

/** Relative require/import targets in one parsed file. */
function relativeEdges(ast) {
  const out = [];
  const add = (v) => { if (typeof v === "string" && v.startsWith(".")) out.push(v); };
  walk.simple(ast, {
    CallExpression(node) {
      if (node.callee.type === "Identifier" && node.callee.name === "require" &&
          node.arguments[0] && node.arguments[0].type === "Literal") add(node.arguments[0].value);
      if (node.callee.type === "Import" && node.arguments[0] && node.arguments[0].type === "Literal")
        add(node.arguments[0].value);
    },
    ImportDeclaration(node) { if (node.source) add(node.source.value); },
    ExportNamedDeclaration(node) { if (node.source) add(node.source.value); },
    ExportAllDeclaration(node) { if (node.source) add(node.source.value); },
  });
  return out;
}

/**
 * @param {string} pkgDir
 * @param {(f:string)=>object|null} parseFile  returns an AST or null on failure
 * @returns {{reachable:Set<string>, entries:string[], unresolved:number}}
 */
function reachableFiles(pkgDirRaw, parseFile) {
  const pkgDir = path.resolve(pkgDirRaw);
  const entries = entryPoints(pkgDir);
  const reachable = new Set();
  const queue = [...entries];
  let unresolved = 0;
  while (queue.length) {
    const f = queue.pop();
    if (!f || reachable.has(f)) continue;
    reachable.add(f);
    const ast = parseFile(f);
    if (!ast) continue;
    for (const rel of relativeEdges(ast)) {
      const target = resolveFile(path.resolve(path.dirname(f), rel));
      if (target && target.startsWith(pkgDir) && /\.(js|cjs|mjs)$/.test(target)) {
        if (!reachable.has(target)) queue.push(target);
      } else if (!target) unresolved++;
    }
  }
  return { reachable, entries, unresolved };
}

module.exports = { entryPoints, reachableFiles, resolveFile, relativeEdges };
