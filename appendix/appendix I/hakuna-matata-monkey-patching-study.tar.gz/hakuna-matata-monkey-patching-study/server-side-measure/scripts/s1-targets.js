/**
 * The curated S-1 target list, shared by the Node arm (`s1-run.js`) and the
 * cross-runtime arm (`s1-crossruntime.js`).
 *
 * Curated from what S-2 ACTUALLY FOUND in server closures (parent handoff §3:
 * "curate from what S-2 finds present, not a guessed list") -- every entry
 * appears in the drivers table of results/server-prevalence.json, plus the named
 * APM/hook families S-2 confirmed present.
 *
 * It lives in its own file so the two arms cannot drift: the cross-runtime
 * comparison is only valid if all three runtimes load the SAME 30 packages.
 */
const TARGETS = [
  // polyfill / guard surface
  { pkg: "core-js", note: "guard surface, helper-routed" },
  { pkg: "core-js-pure", note: "guard surface, non-global variant" },
  // error / stack
  { pkg: "source-map-support", note: "Error.prepareStackTrace + Module._compile" },
  { pkg: "callsites", note: "Error.prepareStackTrace" },
  { pkg: "get-caller-file", note: "Error.prepareStackTrace" },
  { pkg: "depd", note: "Error.prepareStackTrace/stackTraceLimit" },
  { pkg: "stack-trace", note: "Error.prepareStackTrace" },
  // require hooks / APM
  { pkg: "shimmer", note: "the wrap helper itself" },
  { pkg: "require-in-the-middle", note: "Module.prototype.require" },
  { pkg: "import-in-the-middle", note: "ESM loader interception" },
  { pkg: "@opentelemetry/instrumentation", note: "Hook() interception" },
  { pkg: "dd-trace", note: "APM agent, opt-in .init()" },
  { pkg: "@sentry/node", note: "APM/error, opt-in .init()" },
  { pkg: "elastic-apm-node", note: "APM agent, opt-in .start()" },
  // core-module wrapping
  { pkg: "graceful-fs", note: "opt-in .gracefulify(fs)" },
  { pkg: "fs.realpath", note: "fs.realpath replacement" },
  { pkg: "minizlib", note: "Buffer.concat replacement" },
  { pkg: "bindings", note: "native binding loader" },
  // loaders
  { pkg: "jiti", note: "runtime TS/ESM loader" },
  { pkg: "interpret", note: "require.extensions registry" },
  { pkg: "handlebars", note: "require.extensions" },
  // globals
  { pkg: "undici", note: "globalThis.fetch/Headers/Request/Response" },
  { pkg: "node-fetch-native", note: "fetch polyfill" },
  { pkg: "bare-events", note: "global.Event/EventTarget" },
  { pkg: "hono", note: "globalThis.crypto" },
  // builtin prototype/static
  { pkg: "once", note: "Function.prototype.once, opt-in via once.proto()" },
  { pkg: "object-keys", note: "Object.keys shim" },
  { pkg: "sax", note: "Object.create/keys guarded shims" },
  { pkg: "secure-json-parse", note: "JSON handling" },
  { pkg: "es6-shim", note: "es-shims family, helper-routed" },
];

module.exports = { TARGETS };
