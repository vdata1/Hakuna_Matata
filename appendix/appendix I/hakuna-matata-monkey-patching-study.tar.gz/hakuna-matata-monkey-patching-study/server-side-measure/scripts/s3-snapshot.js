#!/usr/bin/env node
/**
 * S-3 snapshot preload. Loaded AFTER probe.js:
 *   node --require probe.js --require s3-snapshot.js <app entry>
 *
 * Dumps the identity diff once the application has finished initialising --
 * whichever comes first:
 *   - `beforeExit`, for apps that complete and fall through (CLI-ish entries)
 *   - a wall-clock deadline, for servers that reach `listen` and stay up
 *
 * Deliberately does NOT wrap `net.Server.prototype.listen` to detect readiness:
 * patching a builtin to measure builtin patching would corrupt the very
 * measurement being taken. A generous deadline is the honest instrument.
 *
 * Env: S3_OUT (required) output path, S3_DEADLINE_MS (default 25000).
 */
const fs = require("node:fs");

const OUT = process.env.S3_OUT;
const DEADLINE = Number(process.env.S3_DEADLINE_MS || 25000);

/**
 * Node sets `process.mainModule` when the main script starts, i.e. after every
 * --require preload has run, so it is bootstrap noise rather than anything the
 * application did. S-1 avoided this by re-baselining inside the main module; here
 * the application IS the main module, so the key is filtered instead.
 */
const IGNORE = new Set(["process|module|mainModule"]);

/**
 * EventEmitter bookkeeping is not builtin modification, and some of it is caused
 * by THIS instrument: registering `process.on('beforeExit')` increments
 * `process._eventsCount`, which showed up as a change on an empty test app.
 * Registering an event listener is ordinary application behaviour in any case.
 */
const IGNORE_PROP = /^(_events|_eventsCount|_maxListeners)$/;
const ignored = (key) => {
  if (IGNORE.has(key)) return true;
  const prop = key.slice(key.lastIndexOf("|") + 1);
  return IGNORE_PROP.test(prop);
};

let dumped = false;
function dump(reason) {
  if (dumped) return;
  dumped = true;
  let changes = [];
  try { changes = globalThis.__PROBE__.diff().filter((c) => !ignored(c.key)); }
  catch (e) { changes = [{ key: "__probe_error__", kind: String(e && e.message) }]; }

  const describe = (chg) => {
    const a = chg.after, b = chg.before;
    const nv = a ? (a.isAccessor ? (a.get || a.set) : a.value) : undefined;
    const ov = b ? (b.isAccessor ? (b.get || b.set) : b.value) : undefined;
    let src = null, marker = false, fnName = null;
    if (typeof nv === "function") {
      try { src = Function.prototype.toString.call(nv).slice(0, 600); } catch { /* proxy */ }
      try { fnName = nv.name || null; } catch { /* proxy */ }
      try { marker = Boolean(nv.__wrapped || nv.__original || nv.__unwrap); } catch { /* proxy */ }
    }
    return {
      key: chg.key, kind: chg.kind,
      newIsFunction: typeof nv === "function", oldIsFunction: typeof ov === "function",
      newIsAccessor: Boolean(a && a.isAccessor), oldIsAccessor: Boolean(b && b.isAccessor),
      shimmerMarker: marker, fnName, src,
    };
  };

  const payload = {
    reason,
    elapsedMs: Date.now() - START,
    entry: process.argv[1] || null,
    nodeVersion: process.version,
    baselineSlots: (globalThis.__PROBE__ || {}).baselineSize || null,
    changes: changes.map(describe),
  };
  try { fs.writeFileSync(OUT, JSON.stringify(payload)); } catch { /* nothing we can do */ }
}

const START = Date.now();

if (!OUT) {
  console.error("[s3-snapshot] S3_OUT not set; snapshot will not be written");
} else {
  process.on("beforeExit", () => { dump("beforeExit"); });
  process.on("exit", () => { dump("exit"); });
  // Servers stay up; take the snapshot at the deadline and stop the process.
  const t = setTimeout(() => { dump("deadline"); process.exit(0); }, DEADLINE);
  if (typeof t.unref === "function") t.unref();
  // unref'd timers do not hold the loop open, so keep one ref'd handle alive
  // only while the app itself is alive -- a second, ref'd timer would prevent
  // `beforeExit` from ever firing for short-lived entries.
  const guard = setInterval(() => {
    if (Date.now() - START >= DEADLINE) { dump("deadline"); process.exit(0); }
  }, 1000);
  if (typeof guard.unref === "function") guard.unref();
}
