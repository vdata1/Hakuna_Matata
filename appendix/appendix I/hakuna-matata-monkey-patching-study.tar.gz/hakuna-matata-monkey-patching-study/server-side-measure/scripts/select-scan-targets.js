#!/usr/bin/env node
/**
 * Choose which packages from the server closures to fetch and scan.
 *
 * Scanning all 12,549 distinct packages would cost ~11 GB. A pure frequency cut
 * is not an acceptable substitute on its own: Exp-1's central finding is that
 * POPULAR packages are libraries and libraries deliberately avoid patching, so
 * ranking by frequency biases the sample away from exactly the behaviour being
 * measured. The selection is therefore a union of two rules:
 *
 *   1. HEAD  -- every package reaching >= FREQ_THRESHOLD of server closures.
 *   2. NAMED -- every package matching a known builtin/require-hook modifier
 *      family, at ANY frequency, so the rare-but-relevant tail is not lost.
 *
 * Coverage of the unscanned remainder is reported per application so the final
 * prevalence figure can be stated as a bound rather than implied to be complete.
 *
 * Usage:  node scripts/select-scan-targets.js [--threshold 0.10]
 * Output: results/scan-targets.json
 */
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");

/** Families known to modify builtins, globals, core modules, or module loading. */
const MODIFIER_PATTERNS = [
  /^core-js/, /^@babel\/polyfill$/, /^babel-polyfill$/, /polyfill/i, /^es[3-9][-.]?shim$/,
  /^es\d{4}-shim$/, /shim$/i, /^regenerator/, /^zone\.js$/, /^@angular\/ssr$/,
  /^dd-trace$/, /^newrelic$/, /^elastic-apm/, /^@elastic\/apm/, /^@sentry\//,
  /^@opentelemetry\//, /^@datadog\//, /^appdynamics$/, /^@dynatrace\//,
  /^shimmer$/, /-in-the-middle$/, /^module-details-from-path$/, /^import-in-the-middle$/,
  /^graceful-fs$/, /^fs-extra$/, /^source-map-support$/, /^longjohn$/, /^trace$/,
  /^clarify$/, /^cls-hooked$/, /^continuation-local-storage$/, /^async-listener$/,
  /^stack-trace$/, /^stackframe$/, /^error-stack-parser$/, /^callsites$/,
  /^promise$/, /^bluebird$/, /^any-promise$/, /^setimmediate$/, /^timers-browserify$/,
  /^object-assign$/, /^object\.assign$/, /^array\.prototype\./, /^string\.prototype\./,
  /^object\.entries$/, /^object\.values$/, /^define-properties$/, /^es-abstract$/,
  /^iconv-lite$/, /^tslib$/, /^@swc\/helpers$/, /^once$/, /^axe-core$/,
];

const isNamed = (p) => MODIFIER_PATTERNS.some((re) => re.test(p));

function main() {
  const ti = process.argv.indexOf("--threshold");
  const THRESHOLD = ti !== -1 ? Number(process.argv[ti + 1]) : 0.10;

  const d = JSON.parse(fs.readFileSync(path.join(RESULTS, "server-closures.json"), "utf8"));
  const withSrv = d.applications.filter((a) => a.serverRoots > 0);
  const N = withSrv.length;

  const freq = new Map();
  for (const a of withSrv) for (const p of a.serverReach) freq.set(p, (freq.get(p) || 0) + 1);

  const head = [], named = [];
  for (const [p, c] of freq) {
    if (c >= THRESHOLD * N) head.push(p);
    else if (isNamed(p)) named.push(p);
  }
  const targets = [...new Set([...head, ...named])].sort();
  const targetSet = new Set(targets);

  // Per-application coverage: what share of each server closure will be scanned.
  const coverage = withSrv.map((a) => {
    const total = a.serverReach.length;
    const covered = a.serverReach.filter((p) => targetSet.has(p)).length;
    return { repo: a.repo, total, covered, pct: total ? +(100 * covered / total).toFixed(1) : 0 };
  });
  const pcts = coverage.map((c) => c.pct).sort((a, b) => a - b);

  const payload = {
    generated: new Date().toISOString().slice(0, 10),
    method: {
      threshold: THRESHOLD,
      head: "packages reaching >= threshold of server closures",
      named: "packages matching a known modifier family at any frequency, so the tail is not lost to popularity bias",
      caveat: "packages outside the selection are unscanned; prevalence computed from this set is a LOWER bound",
    },
    counts: {
      serverEntryApps: N,
      distinctPackages: freq.size,
      selected: targets.length,
      fromHead: head.length,
      fromNamedTail: named.length,
      medianClosureCoveragePct: pcts[Math.floor(pcts.length / 2)],
      minClosureCoveragePct: pcts[0],
    },
    targets,
    coverage,
  };
  fs.mkdirSync(RESULTS, { recursive: true });
  fs.writeFileSync(path.join(RESULTS, "scan-targets.json"), JSON.stringify(payload, null, 1));
  console.error(`[targets] ${targets.length} packages (${head.length} head + ${named.length} named tail)`);
  console.error(`[targets] median server-closure coverage ${payload.counts.medianClosureCoveragePct}% (min ${payload.counts.minClosureCoveragePct}%)`);
  console.error("[targets] wrote results/scan-targets.json");
}
main();
