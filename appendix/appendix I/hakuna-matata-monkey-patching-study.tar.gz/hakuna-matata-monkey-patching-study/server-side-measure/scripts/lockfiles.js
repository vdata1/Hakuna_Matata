#!/usr/bin/env node
// VENDORED from ../supply-chain-monkey-patch/scripts/lockfiles.js (Exp 1/2 tooling).
// Copied rather than imported so this study is reproducible standalone (handoff §6).
// Upstream is the original; changes here are additive, never silent divergence.
/**
 * Lockfile parsers that separate the PRODUCTION tree from the full install.
 *
 * Every parser returns `{ all: Set<name>, prod: Set<name> | null }`. `prod` is
 * null when the format cannot express the distinction with the information
 * available -- never guessed at, because a production figure derived from a
 * guess is worse than a smaller honest denominator.
 *
 * Union semantics across workspaces are deliberate throughout: in a monorepo a
 * package that is a devDependency of one workspace and a runtime dependency of
 * another genuinely ships, so it counts as production.
 *
 *   package-lock.json   v2/v3 flag dev-only packages directly (`dev: true`);
 *                       v1 has no flag -> prod = null
 *   pnpm-lock.yaml      `importers` gives per-workspace dev/prod roots,
 *                       `snapshots` (v9) or `packages` (v6) gives the edges
 *   yarn.lock berry     NOT self-contained: Yarn Berry merges dependencies and
 *                       devDependencies into one `dependencies` map on the
 *                       workspace entry (verified: 0 of 29 real berry lockfiles
 *                       contain a `devDependencies:` key), so roots must come
 *                       from the repository's package.json files
 *   yarn.lock classic   no dev marking and no root entry: roots must come from
 *                       the repository's package.json files
 */

const YAML = require("yaml");

// ---------------------------------------------------------------------------
// npm
// ---------------------------------------------------------------------------

function parsePackageLock(text) {
  const doc = JSON.parse(text);
  const all = new Set();
  if (doc.packages) {
    const prod = new Set();
    for (const [key, meta] of Object.entries(doc.packages)) {
      if (!key) continue;                       // "" is the root project
      const i = key.lastIndexOf("node_modules/");
      if (i === -1) continue;                   // workspace link, not a package
      const name = key.slice(i + "node_modules/".length);
      all.add(name);
      if (!meta || meta.dev !== true) prod.add(name);
    }
    return { all, prod };
  }
  const walk = (deps) => {                      // lockfileVersion 1
    for (const [n, v] of Object.entries(deps || {})) {
      all.add(n);
      if (v && v.dependencies) walk(v.dependencies);
    }
  };
  walk(doc.dependencies);
  return { all, prod: null };                   // v1 carries no dev marking
}

// ---------------------------------------------------------------------------
// pnpm
// ---------------------------------------------------------------------------

function pnpmKeyName(key) {
  let k = key.startsWith("/") ? key.slice(1) : key;
  const paren = k.indexOf("(");
  if (paren !== -1) k = k.slice(0, paren);
  const at = k.lastIndexOf("@");
  return at > 0 ? k.slice(0, at) : null;
}

function parsePnpmLock(text) {
  const doc = YAML.parse(text, { maxAliasCount: -1 });
  const all = new Set();
  if (!doc || typeof doc !== "object") return { all, prod: null };

  const edges = doc.snapshots || doc.packages || {};
  const index = new Map();
  for (const key of Object.keys(edges)) {
    const n = pnpmKeyName(key);
    if (n) all.add(n);
    const bare = (key.startsWith("/") ? key.slice(1) : key).split("(")[0];
    if (!index.has(bare)) index.set(bare, key);
  }
  if (!doc.importers) return { all, prod: null };

  /**
   * pnpm records aliases by putting the REAL package in the value:
   *   string-width-cjs: string-width@4.2.3   |   alias: npm:real@1.2.3
   * Peer suffixes must be stripped first, or the `@` inside `(react@18.2.0)`
   * is mistaken for an alias separator.
   */
  const resolve = (name, version) => {
    let v = String(version);
    if (v.startsWith("npm:")) v = v.slice(4);
    const paren = v.indexOf("(");
    const core = paren === -1 ? v : v.slice(0, paren);
    const at = core.lastIndexOf("@");
    let real = name, ver = core;
    if (at > 0) { real = core.slice(0, at); ver = core.slice(at + 1); }
    return { real, key: index.get(`${real}@${ver}`) || null };
  };

  const prod = new Set();
  const seen = new Set();
  const stack = [];
  const push = (name, version) => {
    const { real, key } = resolve(name, version);
    prod.add(real);
    if (key && !seen.has(key)) { seen.add(key); stack.push(key); }
  };
  for (const imp of Object.values(doc.importers || {})) {
    if (!imp) continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, spec] of Object.entries(imp[field] || {})) {
        const v = spec && typeof spec === "object" ? spec.version : spec;
        if (!v || /^(link|file):/.test(String(v))) continue;
        push(n, v);
      }
    }
  }
  while (stack.length) {
    const entry = edges[stack.pop()];
    if (!entry || typeof entry !== "object") continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, v] of Object.entries(entry[field] || {})) {
        if (!v || String(v).startsWith("link:")) continue;
        push(n, v);
      }
    }
  }
  return { all, prod };
}

// ---------------------------------------------------------------------------
// yarn berry (v2+)
// ---------------------------------------------------------------------------

const isBerry = (text) => /^__metadata:/m.test(text);

/** `lodash@npm:4.18.1` -> lodash ; alias form `foo@npm:lodash@4.1` -> lodash */
function berryResolvedName(resolution, fallback) {
  if (!resolution) return fallback;
  const i = resolution.indexOf("@npm:");
  if (i === -1) {
    const at = resolution.lastIndexOf("@");
    return at > 0 ? resolution.slice(0, at) : fallback;
  }
  const rest = resolution.slice(i + 5);
  const at = rest.lastIndexOf("@");
  // If what follows `npm:` still contains name@version, it is an alias.
  if (at > 0) return rest.slice(0, at);
  return resolution.slice(0, i);
}

function parseYarnBerry(text, manifests) {
  const doc = YAML.parse(text, { maxAliasCount: -1 });
  const all = new Set();
  if (!doc || typeof doc !== "object") return { all, prod: null };

  // One entry can be keyed by several comma-separated descriptors.
  const byDescriptor = new Map();
  const entries = [];
  for (const [key, val] of Object.entries(doc)) {
    if (key === "__metadata" || !val || typeof val !== "object") continue;
    entries.push(val);
    for (const d of key.split(",").map((x) => x.trim().replace(/^"|"$/g, ""))) {
      if (d) byDescriptor.set(d, val);
    }
  }
  const isWorkspace = (e) => /@workspace:/.test(e.resolution || "");
  for (const e of entries) {
    const n = berryResolvedName(e.resolution, null);
    if (n && !isWorkspace(e)) all.add(n);
  }

  if (!manifests || !manifests.length) return { all, prod: null };

  /**
   * package.json records a bare range (`^18.2.0`); berry descriptors carry an
   * explicit protocol (`react@npm:^18.2.0`). Ranges that already name a
   * protocol -- `workspace:^`, `patch:`, `github:` -- are used verbatim.
   */
  const descriptorFor = (name, range) =>
    /^[a-z]+:/.test(range) ? `${name}@${range}` : `${name}@npm:${range}`;

  const prod = new Set();
  const seen = new Set();
  const stack = [];
  const push = (name, range) => {
    const entry = byDescriptor.get(descriptorFor(name, range));
    if (!entry || seen.has(entry)) return;
    seen.add(entry);
    if (!isWorkspace(entry)) {
      const real = berryResolvedName(entry.resolution, name);
      if (real) prod.add(real);
    }
    stack.push(entry);
  };

  // A manifest may name a dependency that this lockfile does not contain (a
  // sibling workspace, or a dep belonging to a different lockfile in the repo).
  // Only names that actually resolve here are recorded as installed, otherwise
  // `prod` ends up with entries absent from `all`.
  for (const m of manifests) {
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, r] of Object.entries((m && m[field]) || {})) push(n, String(r));
    }
  }
  while (stack.length) {
    const e = stack.pop();
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, r] of Object.entries(e[field] || {})) push(n, String(r));
    }
  }
  return { all, prod };
}

// ---------------------------------------------------------------------------
// yarn classic (v1)
// ---------------------------------------------------------------------------

/**
 * v1 is a bespoke format, not YAML. Entries are keyed by comma-separated
 * specs at column 0; `version` and a `dependencies` block are indented under.
 * There is no dev marking and no root entry, so production roots have to come
 * from the repository's own package.json files (`manifests`).
 */
function parseYarnClassic(text, manifests) {
  const all = new Set();
  const byDescriptor = new Map();
  const entries = [];

  let current = null;
  let inDeps = false;
  for (const rawLine of text.split("\n")) {
    const line = rawLine.replace(/\r$/, "");
    if (!line.trim() || line.startsWith("#")) continue;
    if (!/^\s/.test(line)) {
      const key = line.replace(/:\s*$/, "");
      current = { deps: {}, name: null, descriptors: [] };
      entries.push(current);
      inDeps = false;
      for (const spec of key.split(",").map((x) => x.trim().replace(/^"|"$/g, ""))) {
        if (!spec) continue;
        const at = spec.lastIndexOf("@");
        if (at <= 0) continue;
        current.name = current.name || spec.slice(0, at);
        current.descriptors.push(spec);
        byDescriptor.set(spec, current);
      }
      if (current.name) all.add(current.name);
      continue;
    }
    if (!current) continue;
    const t = line.trim();
    if (/^dependencies:/.test(t)) { inDeps = true; continue; }
    if (/^optionalDependencies:/.test(t)) { inDeps = true; continue; }
    if (/^(version|resolved|integrity|dependenciesMeta|peerDependencies)/.test(t)) {
      if (!/^dependenciesMeta/.test(t)) inDeps = false;
      continue;
    }
    if (inDeps) {
      // `  "@scope/name" "^1.0.0"`  or  `  name "^1.0.0"`
      const m = /^"?([^"\s]+)"?\s+"?([^"]+)"?$/.exec(t);
      if (m) current.deps[m[1]] = m[2];
    }
  }

  if (!manifests || !manifests.length) return { all, prod: null };

  const prod = new Set();
  const seen = new Set();
  const stack = [];
  const push = (name, range) => {
    const entry = byDescriptor.get(`${name}@${range}`);
    if (!entry || seen.has(entry)) return;
    seen.add(entry);
    if (entry.name) prod.add(entry.name);
    stack.push(entry);
  };
  // Only names that resolve within this lockfile count as installed (see the
  // equivalent note in parseYarnBerry).
  for (const m of manifests) {
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, r] of Object.entries((m && m[field]) || {})) push(n, String(r));
    }
  }
  while (stack.length) {
    const e = stack.pop();
    for (const [n, r] of Object.entries(e.deps)) push(n, r);
  }
  return { all, prod };
}

// ---------------------------------------------------------------------------

function parseLock(file, text, manifests) {
  if (/package-lock\.json$|npm-shrinkwrap\.json$/.test(file)) return parsePackageLock(text);
  if (/pnpm-lock\.ya?ml$/.test(file)) return parsePnpmLock(text);
  if (/yarn\.lock$/.test(file)) {
    return isBerry(text) ? parseYarnBerry(text, manifests) : parseYarnClassic(text, manifests);
  }
  return { all: new Set(), prod: null };
}

module.exports = { parsePackageLock, parsePnpmLock, parseYarnBerry, parseYarnClassic,
                   parseLock, isBerry, pnpmKeyName, berryResolvedName };
