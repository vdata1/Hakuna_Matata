#!/usr/bin/env node
/**
 * S-2 final: prevalence x surface over server-runtime closures.
 *
 * Joins the two halves of the study:
 *   server-closures.json          -- which packages each SERVER process reaches
 *   server-surface-by-package.json -- which surface each package modifies
 *
 * and reports, per handoff §3, the fraction of server closures that reach a
 * package modifying each surface, SPLIT THREE WAYS AND NEVER MERGED (§4):
 *
 *   guard      -- String/Array/RegExp prototype methods. The paper's claim.
 *   broad      -- other builtins (Error/Promise/timers/statics). Weaker point.
 *   coremodule -- fs/http/module-loading. Explicitly NOT the guard surface.
 *
 * The client-build closure is reported as a separate contrast column so the
 * "core-js is somewhere in the tree" ambiguity Exp-1 could not resolve is
 * visibly resolved here.
 *
 * Usage:  node scripts/server-prevalence.js
 * Output: results/server-prevalence.json
 */
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
/** `globalDefine` is reported but is NOT a modification bucket -- see scan-server-corpus.js. */
const BUCKETS = ["guard", "broad", "coremodule", "global"];
const pct = (n, d) => (d ? +(100 * n / d).toFixed(1) : 0);

function main() {
  const closures = JSON.parse(fs.readFileSync(path.join(RESULTS, "server-closures.json"), "utf8"));
  const surface = JSON.parse(fs.readFileSync(path.join(RESULTS, "server-surface-by-package.json"), "utf8"));


  const byPackage = surface.byPackage;
  // Coverage is measured against packages ACTUALLY scanned, never the target list.
  const scanned = new Set(surface.scannedPackages || Object.keys(byPackage));
  /**
   * Two bounds, always reported together. `reachable` counts only packages whose
   * hits sit in files the Node entry can statically reach -- the primary figure,
   * which excludes browser bundles shipped inside server-reachable packages.
   * `allFiles` counts any hit anywhere in the package; it is the upper bound and
   * it matters because static reachability undercounts packages that load their
   * internals dynamically (Next.js being the clear case).
   */
  const modifiersFor = (bucket, field) =>
    new Set(Object.keys(byPackage).filter((p) => byPackage[p][field][bucket] > 0));
  const modSets = Object.fromEntries(BUCKETS.map((b) => [b, modifiersFor(b, "buckets")]));
  const modSetsAll = Object.fromEntries(BUCKETS.map((b) => [b, modifiersFor(b, "bucketsAllFiles")]));

  const serverApps = closures.applications.filter((a) => a.serverRoots > 0);
  const clientApps = closures.applications.filter((a) => a.clientRoots > 0);

  /** Per app: which buckets does its closure reach, and via which packages. */
  const evaluate = (apps, field) => apps.map((a) => {
    const reach = a[field];
    const hitsByBucket = {}, hitsByBucketAll = {};
    for (const b of BUCKETS) {
      hitsByBucket[b] = reach.filter((p) => modSets[b].has(p)).sort();
      hitsByBucketAll[b] = reach.filter((p) => modSetsAll[b].has(p)).sort();
    }
    const covered = reach.filter((p) => scanned.has(p)).length;
    return { repo: a.repo, closureSize: reach.length,
             scannedPct: pct(covered, reach.length), hitsByBucket, hitsByBucketAll };
  });

  const server = evaluate(serverApps, "serverReach");
  const client = evaluate(clientApps, "clientReach");

  const prevalence = {};
  for (const b of BUCKETS) {
    const s = server.filter((a) => a.hitsByBucket[b].length).length;
    const c = client.filter((a) => a.hitsByBucket[b].length).length;
    const sAll = server.filter((a) => a.hitsByBucketAll[b].length).length;
    const cAll = client.filter((a) => a.hitsByBucketAll[b].length).length;
    prevalence[b] = {
      serverApps: s, serverPct: pct(s, server.length),
      clientApps: c, clientPct: pct(c, client.length),
      serverPctUpperBound: pct(sAll, server.length),
      clientPctUpperBound: pct(cAll, client.length),
    };
  }

  /** Which packages actually drive each bucket, ranked by how many servers reach them. */
  const drivers = {};
  for (const b of BUCKETS) {
    const freq = new Map();
    for (const a of server) for (const p of a.hitsByBucket[b]) freq.set(p, (freq.get(p) || 0) + 1);
    drivers[b] = [...freq.entries()].sort((x, y) => y[1] - x[1]).slice(0, 15)
      .map(([pkg, n]) => ({ pkg, servers: n, pctOfServers: pct(n, server.length),
                            methods: (byPackage[pkg].methods[b] || []).slice(0, 12) }));
  }

  const payload = {
    generated: new Date().toISOString().slice(0, 10),
    question: "In deployed Node server processes, are builtins modified along the guard-dispatch surface, and by what fraction of dependency trees?",
    method: {
      population: `${server.length} awesome-selfhosted Node applications with a resolvable server entry (of ${closures.applications.length} analysed)`,
      closure: "lockfile graph rooted at server-classified workspaces, workspace links followed, runtime deps only",
      surface: "Exp-1 scanSource for builtin prototype/static shapes + detect-server-patch.js for wrap/require-hook/core-module/global shapes",
      buckets: "guard = String/Array/RegExp prototype methods a guard dispatches through; broad = other builtins; coremodule = fs/http/module-loading; NEVER merged into one percent (handoff §4)",
      bound: "LOWER bound: only selected packages were scanned (see scannedPct per app), and static detection misses computed/dynamic patching",
      versions: "package bodies scanned at `latest`; closures are name-granular",
    },
    counts: {
      serverEntryApps: server.length,
      clientEntryApps: client.length,
      packagesScanned: surface.counts.packagesScanned,
      distinctModifiersFound: Object.keys(byPackage).length,
      parseFailureRate: surface.counts.parseFailureRate,
      medianScannedPctOfServerClosure:
        server.map((a) => a.scannedPct).sort((x, y) => x - y)[Math.floor(server.length / 2)] || 0,
    },
    prevalence,
    drivers,
    applications: server,
  };

  fs.writeFileSync(path.join(RESULTS, "server-prevalence.json"), JSON.stringify(payload, null, 1));

  console.log("\nPrevalence over server-runtime closures (n=%d) vs client-build (n=%d)\n",
              server.length, client.length);
  console.log("bucket".padEnd(12), "server (entry-reachable)".padStart(26),
              "server (upper)".padStart(16), "client".padStart(12));
  console.log("-".repeat(68));
  for (const b of BUCKETS) {
    const p = prevalence[b];
    console.log(b.padEnd(12),
      `${p.serverPct}% (${p.serverApps}/${server.length})`.padStart(26),
      `${p.serverPctUpperBound}%`.padStart(16),
      `${p.clientPct}%`.padStart(12));
  }
  console.log("\ntop guard-surface drivers:",
    drivers.guard.length ? drivers.guard.map((d) => `${d.pkg} (${d.pctOfServers}%)`).join(", ") : "NONE");
  console.error("\n[prevalence] wrote results/server-prevalence.json");
}
main();
