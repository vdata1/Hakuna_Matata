/**
 * S-1 cross-runtime probe: the portable form of `scripts/probe.js`.
 *
 * Same measurement, same slot keys, same identity-diff semantics -- the only
 * changes are the ones needed to run the arm on Deno and Bun as well as Node
 * (cross-runtime handoff s3, "port surface"):
 *
 *   - ESM, not CJS, so one file serves all three preload flags:
 *       node --import ./probe-x.mjs      (Node)
 *       bun  --preload ./probe-x.mjs     (Bun; --require/--import alias it)
 *       deno run --preload ./probe-x.mjs (Deno)
 *   - core modules are reached through `createRequire` with `node:`-prefixed
 *     specifiers, which is the only spelling all three resolve. Snapshot KEYS
 *     keep the bare name ("fs", not "node:fs") so rows line up with the Node
 *     arm's existing results/server-surface.csv.
 *   - a native `Function.prototype.toString` is captured HERE, before any target
 *     loads. core-js replaces that method at import time on Node, so reading
 *     function sources through the live method after loading a target means
 *     reading them through the target's own replacement. The Node arm got away
 *     with it; with different esnext gates firing per runtime it is not worth
 *     the risk.
 *   - capability probing: a slot that does not exist, or a hook point that is
 *     not the runtime's real dispatch path, must not be reported as "nothing
 *     patched it". See `capabilities` below.
 */
import { createRequire } from "node:module";

/** Captured before any target code runs. Everything reads sources through this. */
const nativeToString = Function.prototype.toString;
const nativeCall = Function.prototype.call;
const srcOf = (fn) => nativeCall.call(nativeToString, fn);

const require = createRequire(import.meta.url);

const RUNTIME =
  typeof globalThis.Deno !== "undefined" ? "deno"
  : typeof globalThis.Bun !== "undefined" ? "bun"
  : "node";

function runtimeVersion() {
  try {
    if (RUNTIME === "deno") return globalThis.Deno.version.deno;
    if (RUNTIME === "bun") return globalThis.Bun.version;
    return process.versions.node;
  } catch { return "unknown"; }
}

const NAMESPACES = [
  "Object", "Array", "String", "RegExp", "Function", "Promise", "Map", "Set",
  "Number", "Boolean", "Date", "JSON", "Reflect", "Error", "Symbol", "Math",
  "WeakMap", "WeakSet", "BigInt", "TypeError", "RangeError", "SyntaxError",
];

const GLOBALS = [
  "setTimeout", "setInterval", "setImmediate", "clearTimeout", "clearInterval",
  "clearImmediate", "queueMicrotask", "structuredClone", "fetch", "URL",
  "URLSearchParams", "AbortController", "AbortSignal", "TextEncoder", "TextDecoder",
  "Buffer", "crypto", "performance", "atob", "btoa", "Headers", "Request",
  "Response", "FormData", "Blob", "ReadableStream", "WritableStream",
  "TransformStream", "Event", "EventTarget", "MessageChannel",
];

const CORE_MODULES = [
  "fs", "fs/promises", "http", "https", "net", "dns", "child_process", "module",
  "path", "os", "crypto", "stream", "zlib", "events", "util", "timers", "url",
  "querystring", "vm", "worker_threads", "async_hooks", "readline", "buffer",
  "tls", "dgram", "perf_hooks", "string_decoder", "assert", "process",
];

/**
 * Which core modules this runtime actually gave us, and whether the module-system
 * hook points exist AND intercept. Recorded once, at preload, and carried into
 * every emitted row.
 *
 * The distinction this exists to preserve: on a runtime where `require.extensions`
 * is absent, or where patching `Module.prototype.require` does not intercept a
 * subsequent require, a zero in the coremodule bucket means "not observable
 * here", NOT "no package modified it". Reporting rule s5 keeps the buckets
 * separate per runtime; conflating unmeasurable with null would quietly turn
 * "Bun does not route requires through this slot" into the much stronger and
 * false "require hooks patch nothing on Bun".
 */
function probeCapabilities() {
  const caps = {
    runtime: RUNTIME,
    runtimeVersion: runtimeVersion(),
    coreModulesLoaded: [],
    coreModulesMissing: {},
    moduleSlots: {},
    protoRequireIntercepts: null,
    requireExtensions: null,
  };

  /**
   * Per-module surface size, not just "did it load". An agent that patches zero
   * methods of `node:zlib` on one runtime has done one of two very different
   * things: found nothing to patch, or declined to patch a surface that was fully
   * present. Only the method counts can tell those apart, so they are recorded
   * here and carried into the report.
   */
  caps.coreModuleSurface = {};
  for (const m of CORE_MODULES) {
    let mod;
    try { mod = require("node:" + m); caps.coreModulesLoaded.push(m); }
    catch (e) { caps.coreModulesMissing[m] = String((e && e.message) || e).slice(0, 160); continue; }
    // Counted over the SAME key space the snapshot walks -- module own props plus
    // the sub-namespaces below -- otherwise a "patched / available" ratio compares
    // slots against a denominator that never included fs.promises and reads as
    // more methods patched than exist.
    try {
      // Descriptors only -- never read a property VALUE. Reading one invokes any
      // getter behind it, and `crypto.constants.defaultCipherList` is a Node
      // deprecation accessor that materialises into a plain value once read. Doing
      // that here would silently consume the change before the baseline is taken
      // and the arm would stop reproducing the parent Node run.
      let props = 0, fns = 0;
      const walk = (obj) => {
        for (const p of Object.getOwnPropertyNames(obj)) {
          props++;
          let d;
          try { d = Object.getOwnPropertyDescriptor(obj, p); } catch { continue; }
          if (d && typeof d.value === "function") fns++;
        }
      };
      walk(mod);
      for (const sub of ["promises", "constants", "Server", "Agent"]) {
        try { if (mod[sub] && typeof mod[sub] === "object") walk(mod[sub]); } catch { /* ignore */ }
      }
      caps.coreModuleSurface[m] = { props, fns };
    } catch { caps.coreModuleSurface[m] = null; }
  }

  let Module = null;
  try { Module = require("node:module"); } catch { /* no module system exposed */ }
  if (Module) {
    for (const p of ["_load", "_resolveFilename", "_compile", "_extensions", "wrap", "runMain"]) {
      caps.moduleSlots[p] = typeof Module[p] !== "undefined";
    }
    for (const p of ["require", "load", "_compile"]) {
      caps.moduleSlots["prototype." + p] =
        Boolean(Module.prototype && typeof Module.prototype[p] !== "undefined");
    }

    // Is Module.prototype.require the runtime's real dispatch path? Patch it,
    // require something, see whether the patch was consulted, then restore.
    try {
      const orig = Module.prototype.require;
      let hit = false;
      Module.prototype.require = function (id) { hit = true; return nativeCall.call(orig, this, id); };
      try { require("node:path"); } catch { /* ignore */ }
      Module.prototype.require = orig;
      caps.protoRequireIntercepts = hit;
    } catch (e) {
      caps.protoRequireIntercepts = null;
      caps.protoRequireError = String((e && e.message) || e).slice(0, 160);
    }
  }

  try {
    caps.requireExtensions = Boolean(require.extensions) &&
      Object.getOwnPropertyNames(require.extensions).length > 0;
  } catch { caps.requireExtensions = false; }

  return caps;
}

/** key -> { value, get, set, isAccessor } -- identical shape to the Node probe. */
function snapshot() {
  const map = new Map();
  const record = (ns, target, prop, obj) => {
    let d;
    try { d = Object.getOwnPropertyDescriptor(obj, prop); } catch { return; }
    if (!d) return;
    map.set(`${ns}|${target}|${prop}`, {
      value: d.value, get: d.get, set: d.set, isAccessor: Boolean(d.get || d.set),
    });
  };

  for (const ns of NAMESPACES) {
    const ctor = globalThis[ns];
    if (!ctor) continue;
    try {
      for (const p of Object.getOwnPropertyNames(ctor)) record(ns, "static", p, ctor);
      if (ctor.prototype) {
        for (const p of Object.getOwnPropertyNames(ctor.prototype)) record(ns, "prototype", p, ctor.prototype);
      }
    } catch { /* exotic namespace, skip */ }
  }

  for (const g of GLOBALS) record("globalThis", "global", g, globalThis);

  for (const m of CORE_MODULES) {
    let mod;
    try { mod = require("node:" + m); } catch { continue; }
    if (!mod || (typeof mod !== "object" && typeof mod !== "function")) continue;
    try {
      for (const p of Object.getOwnPropertyNames(mod)) record(m, "module", p, mod);
    } catch { /* getters that throw */ }
    for (const sub of ["promises", "constants", "Server", "Agent"]) {
      try {
        if (mod[sub] && typeof mod[sub] === "object") {
          for (const p of Object.getOwnPropertyNames(mod[sub])) record(m, sub, p, mod[sub]);
        }
      } catch { /* ignore */ }
    }
  }

  // The module system itself: the dominant server interception point on Node.
  try {
    const Module = require("node:module");
    for (const p of ["_load", "_resolveFilename", "_compile", "_extensions", "wrap", "runMain"]) {
      record("module", "Module", p, Module);
    }
    if (Module.prototype) {
      for (const p of ["require", "load", "_compile"]) record("module", "Module.prototype", p, Module.prototype);
    }
    if (require.extensions) {
      for (const p of Object.getOwnPropertyNames(require.extensions)) {
        record("module", "require.extensions", p, require.extensions);
      }
    }
  } catch { /* ignore */ }

  return map;
}

const same = (a, b) => a === b || (Number.isNaN(a) && Number.isNaN(b));

function diff(baseline) {
  const now = snapshot();
  const changes = [];
  for (const [key, before] of baseline) {
    const after = now.get(key);
    if (!after) { changes.push({ key, kind: "deleted", before, after: null }); continue; }
    if (before.isAccessor || after.isAccessor) {
      if (!same(before.get, after.get) || !same(before.set, after.set) || before.isAccessor !== after.isAccessor) {
        changes.push({ key, kind: "accessor", before, after });
      }
      continue;
    }
    if (!same(before.value, after.value)) changes.push({ key, kind: "value", before, after });
  }
  for (const [key, after] of now) {
    if (!baseline.has(key)) changes.push({ key, kind: "added", before: null, after });
  }
  return changes;
}

const capabilities = probeCapabilities();
let baseline = snapshot();

globalThis.__PROBE__ = {
  runtime: RUNTIME,
  capabilities,
  snapshot,
  srcOf,
  diff: () => diff(baseline),
  /** Re-taken by the loader so bootstrap-time slots are not blamed on the target. */
  rebaseline: () => { baseline = snapshot(); return baseline.size; },
  get baselineSize() { return baseline.size; },
};
