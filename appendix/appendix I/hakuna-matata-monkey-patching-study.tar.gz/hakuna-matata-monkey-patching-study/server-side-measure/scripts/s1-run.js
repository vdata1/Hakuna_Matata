#!/usr/bin/env node
/**
 * Arm S-1: what does each known server-side modifier actually change, when loaded
 * alone in an instrumented process?
 *
 * Targets are curated from what S-2 ACTUALLY FOUND in server closures (handoff
 * §3: "curate from what S-2 finds present, not a guessed list") -- every entry
 * below appears in the drivers table of results/server-prevalence.json, plus the
 * named APM/hook families S-2 confirmed present.
 *
 * SAFETY (handoff §9). This arm executes third-party code, so:
 *   - curated, named packages only; never a whole closure
 *   - `npm install --ignore-scripts` -- no lifecycle scripts ever run
 *   - each target installed into its own throwaway directory under cache/
 *   - execution wrapped in `sandbox-exec` with `(deny network*)`, verified to
 *     block egress before the run starts
 *   - one target per process, hard timeout, output captured as JSON
 *
 * Usage:  node scripts/s1-run.js [--only <pkg>] [--skip-install]
 * Output: results/server-surface.csv, results/s1-raw.json
 */
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync, spawnSync } = require("node:child_process");
const { parse, classifyRHS } = require("./scan-monkeypatch.js");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const SANDBOX = path.join(ROOT, "cache", "s1-sandbox");
const PROFILE = path.join(SANDBOX, "nonet.sb");
const TIMEOUT_MS = 60000;
const log = (...a) => console.error("[s1]", ...a);

/** Curated from the S-2 drivers table; shared with the cross-runtime arm. */
const { TARGETS } = require("./s1-targets.js");

function ensureProfile() {
  fs.mkdirSync(SANDBOX, { recursive: true });
  fs.writeFileSync(PROFILE, "(version 1)\n(allow default)\n(deny network*)\n");
  // Verify the sandbox actually blocks egress before running any target code.
  const check = spawnSync("sandbox-exec", ["-f", PROFILE, process.execPath, "-e",
    "fetch('https://registry.npmjs.org/').then(()=>{console.log('ALLOWED')}).catch(()=>{console.log('BLOCKED')})"],
    { encoding: "utf8", timeout: 30000 });
  const ok = /BLOCKED/.test(check.stdout || "");
  if (!ok) throw new Error("sandbox did not block network egress; refusing to execute targets");
  log("sandbox verified: network egress blocked");
}

function install(pkg, dir) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ name: "s1-host", private: true }, null, 1));
  execFileSync("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund",
                       "--no-package-lock", "--loglevel=error", pkg],
    { cwd: dir, encoding: "utf8", timeout: 300000, stdio: ["ignore", "pipe", "pipe"] });
}

function runTarget(pkg, dir) {
  const outFile = path.join(dir, "__probe-out.json");
  try { fs.rmSync(outFile, { force: true }); } catch { /* ignore */ }
  const res = spawnSync("sandbox-exec", ["-f", PROFILE, process.execPath,
      "--require", path.join(ROOT, "scripts", "probe.js"),
      path.join(ROOT, "scripts", "s1-load.js"), pkg, outFile],
    { cwd: dir, encoding: "utf8", timeout: TIMEOUT_MS, maxBuffer: 64 * 1024 * 1024 });
  if (!fs.existsSync(outFile)) {
    const why = res.error ? String(res.error.message) : (res.stderr || "no probe output").slice(0, 400);
    return { error: why };
  }
  try { return JSON.parse(fs.readFileSync(outFile, "utf8")); }
  catch (e) { return { error: "unparseable probe output: " + String(e.message).slice(0, 200) }; }
}

const NAMESPACES = new Set(["Object", "Array", "String", "RegExp", "Function", "Promise",
  "Map", "Set", "Number", "Boolean", "Date", "JSON", "Reflect", "Error", "Symbol",
  "Math", "WeakMap", "WeakSet", "BigInt", "TypeError", "RangeError", "SyntaxError"]);

function kindOf(ns, target) {
  if (NAMESPACES.has(ns)) return target === "prototype" ? "proto" : "static";
  if (ns === "globalThis") return "global";
  return "coremodule";
}

/** Reuse the Exp-2 RHS classifier by parsing the live function's source. */
function rhsFormOf(src) {
  if (!src) return "other";
  for (const wrap of [`(${src})`, `(function ${src})`]) {
    try {
      const ast = parse(wrap);
      const expr = ast.body[0] && ast.body[0].expression;
      if (expr) return classifyRHS(expr);
    } catch { /* try next shape */ }
  }
  return "unparseable";
}

function mechanismOf(c, rhsForm) {
  if (c.newIsAccessor && !c.oldIsAccessor) return "accessor";
  if (c.shimmerMarker) return "wrap";
  if (rhsForm === "wraps-original") return "wrap";
  if (rhsForm === "constant-return") return "replace-constant";
  if (!c.newIsFunction && c.oldIsFunction) return "replaced-with-nonfunction";
  return "replace";
}

function main() {
  const onlyIdx = process.argv.indexOf("--only");
  const only = onlyIdx !== -1 ? process.argv[onlyIdx + 1] : null;
  const skipInstall = process.argv.includes("--skip-install");
  const targets = only ? TARGETS.filter((t) => t.pkg === only) : TARGETS;

  ensureProfile();
  const raw = [], rows = [];

  for (const t of targets) {
    const dir = path.join(SANDBOX, t.pkg.replace(/[^a-z0-9.-]/gi, "_"));
    if (!skipInstall) {
      try { install(t.pkg, dir); }
      catch (e) {
        log(`${t.pkg}: install FAILED (${String(e.message).split("\n")[0].slice(0, 120)})`);
        raw.push({ target: t.pkg, note: t.note, installError: String(e.message).slice(0, 400) });
        continue;
      }
    }
    const out = runTarget(t.pkg, dir);
    out.note = t.note;
    raw.push(out);
    if (out.error) { log(`${t.pkg}: run error -- ${out.error.split("\n")[0].slice(0, 120)}`); continue; }

    const importKeys = new Set((out.phases.importTime || []).map((c) => c.key));
    const emit = (c, timing) => {
      const [ns, target, method] = c.key.split("|");
      const rhsForm = rhsFormOf(c.src);
      rows.push([t.pkg, ns, target, method, kindOf(ns, target),
                 mechanismOf(c, rhsForm), rhsForm, timing, c.kind,
                 c.shimmerMarker ? "shimmer-marker" : ""].join(","));
    };
    for (const c of out.phases.importTime || []) emit(c, "importTime");
    for (const c of out.phases.optIn || []) if (!importKeys.has(c.key)) emit(c, "optIn");

    const nImport = (out.phases.importTime || []).length;
    const nOptIn = (out.phases.optIn || []).filter((c) => !importKeys.has(c.key)).length;
    // A load failure must never be reported as "modifies nothing".
    const loadFailed = (out.errors || []).some((e) => e.phase === "importTime");
    const flag = loadFailed ? "  LOAD FAILED: " + (out.errors.find((e) => e.phase === "importTime").error.split("\n")[0].slice(0, 80)) : "";
    log(`${t.pkg.padEnd(32)} importTime=${String(nImport).padStart(3)} optIn=${String(nOptIn).padStart(3)}${flag}`);
  }

  fs.mkdirSync(RESULTS, { recursive: true });
  fs.writeFileSync(path.join(RESULTS, "server-surface.csv"),
    ["agent,namespace,target,method,kind,mechanism,rhsForm,timing,changeKind,evidence", ...rows].join("\n"));
  fs.writeFileSync(path.join(RESULTS, "s1-raw.json"), JSON.stringify(raw, null, 1));
  log(`wrote results/server-surface.csv (${rows.length} rows) and results/s1-raw.json`);
}
main();
