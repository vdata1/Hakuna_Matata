#!/usr/bin/env node
/**
 * Arm S-1, cross-runtime re-run: the same 30 curated modifiers, loaded alone in
 * an instrumented Node, Deno AND Bun process.
 *
 * Answers the three questions in the cross-runtime handoff §2:
 *   1. guard-dispatch surface per runtime (expected: 0 replacements on all three)
 *   2. which agents fail to load under Deno/Bun Node-compat layers
 *   3. whether core-js opens different feature-detection gates per runtime
 * plus the secondary claim: is Function.prototype.toString replaced on each?
 *
 * SAFETY (handoff §6, identical discipline to the Node arm):
 *   - curated, named packages only; never a whole closure
 *   - installs come from `npm install --ignore-scripts` (no lifecycle scripts)
 *   - each target in its own throwaway dir under cache/s1-sandbox, temp CWD
 *   - every runtime binary wrapped in `sandbox-exec` with `(deny network*)`,
 *     and the egress block is re-verified PER BINARY before that runtime runs.
 *     The Node arm verified with `process.execPath` only; "identical discipline"
 *     across three binaries means proving it three times.
 *   - one target per process, hard timeout, output captured as JSON to a file
 *
 * Deno runs with `-A`. That is deliberate: the OS sandbox is the single
 * enforcement layer for all three runtimes, so the permission surface stays
 * comparable. Using Deno's own `--deny-net` instead would make targets fail with
 * permission errors where Node/Bun merely fail to connect, confounding question 2.
 *
 * Usage:  node scripts/s1-crossruntime.js [--only <pkg>] [--runtime <id>] [--install]
 */
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync, spawnSync } = require("node:child_process");
const { parse, classifyRHS } = require("./scan-monkeypatch.js");
const { TARGETS } = require("./s1-targets.js");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const SANDBOX = path.join(ROOT, "cache", "s1-sandbox");
const PROFILE = path.join(SANDBOX, "nonet.sb");
const PROBE = path.join(ROOT, "scripts", "probe-x.mjs");
const LOADER = path.join(ROOT, "scripts", "s1-load-x.mjs");
const TIMEOUT_MS = 90000;
const log = (...a) => console.error("[s1x]", ...a);

/**
 * Per-runtime invocation. `preload` builds the argv that runs LOADER with PROBE
 * preloaded; `evalArgs` builds a one-liner used only for the egress check.
 */
const RUNTIMES = [
  {
    id: "node",
    bin: process.execPath,
    preload: (pkg, out) => ["--import", PROBE, LOADER, pkg, out],
    evalArgs: (code) => ["-e", code],
    versionArgs: ["--version"],
  },
  {
    id: "deno",
    bin: "deno",
    preload: (pkg, out) => ["run", "-A", "--preload", PROBE, LOADER, pkg, out],
    evalArgs: (code) => ["eval", code], // `deno eval` has implicit all-permissions; -A is rejected
    versionArgs: ["--version"],
  },
  {
    id: "bun",
    bin: "bun",
    preload: (pkg, out) => ["--preload", PROBE, LOADER, pkg, out],
    evalArgs: (code) => ["-e", code],
    versionArgs: ["--version"],
  },
];

const EGRESS_CHECK =
  "fetch('https://registry.npmjs.org/').then(()=>console.log('ALLOWED')).catch(()=>console.log('BLOCKED'))";

function writeProfile() {
  fs.mkdirSync(SANDBOX, { recursive: true });
  fs.writeFileSync(PROFILE, "(version 1)\n(allow default)\n(deny network*)\n");
}

/** Resolve the binary and prove the sandbox blocks ITS egress. */
function verifyRuntime(rt) {
  const probeVersion = spawnSync(rt.bin, rt.versionArgs, { encoding: "utf8", timeout: 30000 });
  if (probeVersion.error || probeVersion.status !== 0) {
    return { ok: false, reason: `binary not runnable: ${String(probeVersion.error || probeVersion.stderr).slice(0, 160)}` };
  }
  const version = (probeVersion.stdout || "").trim().split("\n")[0];

  const check = spawnSync("sandbox-exec", ["-f", PROFILE, rt.bin, ...rt.evalArgs(EGRESS_CHECK)],
    { encoding: "utf8", timeout: 45000 });
  const stdout = check.stdout || "";
  if (/ALLOWED/.test(stdout)) return { ok: false, version, reason: "sandbox did NOT block egress for this binary" };
  if (!/BLOCKED/.test(stdout)) {
    return { ok: false, version, reason: `egress check inconclusive: ${(stdout + check.stderr).slice(0, 160)}` };
  }
  return { ok: true, version };
}

function install(pkg, dir) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "package.json"), JSON.stringify({ name: "s1-host", private: true }, null, 1));
  execFileSync("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund",
                       "--no-package-lock", "--loglevel=error", pkg],
    { cwd: dir, encoding: "utf8", timeout: 300000, stdio: ["ignore", "pipe", "pipe"] });
}

const dirFor = (pkg) => path.join(SANDBOX, pkg.replace(/[^a-z0-9.-]/gi, "_"));

/** The installed version, so the three runtimes are provably loading the same code. */
function installedVersion(pkg, dir) {
  try {
    const p = path.join(dir, "node_modules", pkg, "package.json");
    return JSON.parse(fs.readFileSync(p, "utf8")).version || null;
  } catch { return null; }
}

function runTarget(rt, pkg, dir) {
  const outFile = path.join(dir, `__probe-${rt.id}.json`);
  try { fs.rmSync(outFile, { force: true }); } catch { /* ignore */ }
  const res = spawnSync("sandbox-exec", ["-f", PROFILE, rt.bin, ...rt.preload(pkg, outFile)],
    { cwd: dir, encoding: "utf8", timeout: TIMEOUT_MS, maxBuffer: 64 * 1024 * 1024 });
  if (!fs.existsSync(outFile)) {
    const why = res.error ? String(res.error.message)
      : (res.stderr || res.stdout || "no probe output").slice(0, 600);
    return { error: why, exitCode: res.status, timedOut: Boolean(res.error && /ETIMEDOUT|timeout/i.test(String(res.error.message))) };
  }
  try { return JSON.parse(fs.readFileSync(outFile, "utf8")); }
  catch (e) { return { error: "unparseable probe output: " + String(e.message).slice(0, 200) }; }
}

// --- classification (identical semantics to the Node arm + s3-run.js) ---------
const NAMESPACES = new Set(["Object", "Array", "String", "RegExp", "Function", "Promise",
  "Map", "Set", "Number", "Boolean", "Date", "JSON", "Reflect", "Error", "Symbol",
  "Math", "WeakMap", "WeakSet", "BigInt", "TypeError", "RangeError", "SyntaxError"]);
const GUARD_NS = new Set(["String", "Array", "RegExp"]);
const BARRIER = new Set(["includes", "startsWith", "endsWith", "indexOf", "lastIndexOf",
  "test", "exec", "match", "search", "replace", "replaceAll", "split", "trim",
  "toLowerCase", "toUpperCase", "slice", "substring", "some", "every", "filter",
  "find", "findIndex", "keys", "values", "entries", "concat", "join", "flat", "flatMap"]);

function kindOf(ns, target) {
  if (NAMESPACES.has(ns)) return target === "prototype" ? "proto" : "static";
  if (ns === "globalThis") return "global";
  return "coremodule";
}

/** guard / broad / global / coremodule -- the four buckets reporting rule §5 keeps apart. */
function bucketOf(ns, target, method) {
  if (NAMESPACES.has(ns)) {
    if (GUARD_NS.has(ns) && target === "prototype" && BARRIER.has(method)) return "guard";
    return "broad";
  }
  if (ns === "globalThis") return "global";
  return "coremodule";
}

function rhsFormOf(src) {
  if (!src) return "other";
  for (const wrap of [`(${src})`, `(function ${src})`]) {
    try {
      const ast = parse(wrap);
      const expr = ast.body[0] && ast.body[0].expression;
      if (expr) return classifyRHS(expr);
    } catch { /* try next shape */ }
  }
  return "unparseable";
}

function mechanismOf(c, rhsForm) {
  if (c.newIsAccessor && !c.oldIsAccessor) return "accessor";
  if (c.shimmerMarker) return "wrap";
  if (rhsForm === "wraps-original") return "wrap";
  if (rhsForm === "constant-return") return "replace-constant";
  if (!c.newIsFunction && c.oldIsFunction) return "replaced-with-nonfunction";
  return "replace";
}

/**
 * Slots that change as a SIDE EFFECT of ordinary API use rather than as a patch.
 * `process._eventsCount` is the live case: calling `process.on(...)` bumps
 * EventEmitter's listener counter, so every APM agent that registers an
 * uncaughtException handler shows up as having "changed a core-module slot".
 * It is a real identity change and stays in the data, but it is not a built-in
 * modification and must not be counted as one.
 */
const BOOKKEEPING = new Set(["_eventsCount", "_events", "_maxListeners"]);

/** A pre-existing slot whose identity changed -- as opposed to a newly ADDED method. */
const isReplacement = (changeKind) => changeKind === "value" || changeKind === "accessor";

function main() {
  const argOf = (flag) => {
    const i = process.argv.indexOf(flag);
    return i !== -1 ? process.argv[i + 1] : null;
  };
  const only = argOf("--only");
  const onlyRuntime = argOf("--runtime");
  const doInstall = process.argv.includes("--install");

  const targets = only ? TARGETS.filter((t) => t.pkg === only) : TARGETS;
  const runtimes = onlyRuntime ? RUNTIMES.filter((r) => r.id === onlyRuntime) : RUNTIMES;
  if (!targets.length) throw new Error(`no target matches --only ${only}`);
  if (!runtimes.length) throw new Error(`no runtime matches --runtime ${onlyRuntime}`);

  writeProfile();

  // --- verify every runtime binary before any target code runs ----------------
  const runtimeInfo = {};
  const usable = [];
  for (const rt of runtimes) {
    const v = verifyRuntime(rt);
    runtimeInfo[rt.id] = { version: v.version || null, usable: v.ok, reason: v.reason || null };
    if (v.ok) { log(`${rt.id.padEnd(5)} ${v.version} -- sandbox verified: egress blocked`); usable.push(rt); }
    else log(`${rt.id.padEnd(5)} UNUSABLE: ${v.reason}`);
  }
  if (!usable.length) throw new Error("no runtime passed verification; refusing to execute targets");

  // --- install (reuse the Node arm's tree by default) -------------------------
  // All three runtimes load the SAME node_modules. Letting `bun install` or
  // `deno add` resolve independently could pin different versions and turn a
  // version difference into a phantom cross-runtime finding.
  const missing = [];
  for (const t of targets) {
    const dir = dirFor(t.pkg);
    if (!fs.existsSync(path.join(dir, "node_modules", t.pkg, "package.json"))) missing.push(t);
  }
  if (missing.length) {
    if (!doInstall) {
      log(`${missing.length} target(s) not installed: ${missing.map((t) => t.pkg).join(", ")}`);
      throw new Error("re-run with --install, or run scripts/s1-run.js first");
    }
    for (const t of missing) {
      try { log(`installing ${t.pkg}`); install(t.pkg, dirFor(t.pkg)); }
      catch (e) { log(`${t.pkg}: install FAILED (${String(e.message).split("\n")[0].slice(0, 120)})`); }
    }
  }

  // --- run --------------------------------------------------------------------
  const raw = [];
  const rows = [];
  const loadErrors = [];
  const pkgVersions = {};

  for (const t of targets) {
    const dir = dirFor(t.pkg);
    pkgVersions[t.pkg] = installedVersion(t.pkg, dir);

    for (const rt of usable) {
      const out = runTarget(rt, t.pkg, dir);
      out.target = t.pkg;
      out.note = t.note;
      out.runtime = rt.id;
      out.installedVersion = pkgVersions[t.pkg];
      raw.push(out);

      // Question 2: every load error / partial load, per (target, runtime).
      const importErr = (out.errors || []).find((e) => e.phase === "importTime" || e.phase === "importTime:esm");
      const record = {
        target: t.pkg, runtime: rt.id, installedVersion: pkgVersions[t.pkg],
        loaded: !out.error && !importErr,
        loadedVia: out.loadedVia || null,
        processError: out.error || null,
        exitCode: out.exitCode === undefined ? null : out.exitCode,
        importError: importErr ? importErr.error : null,
        optInAttempted: out.optInAttempted === undefined ? null : out.optInAttempted,
        exportShape: out.exportShape || null,
        optInErrors: (out.errors || []).filter((e) => e.phase === "optIn:call").map((e) => e.error),
        slotsChangedImport: (out.phases && out.phases.importTime || []).length,
        slotsChangedOptIn: null,
        probeMissing: Boolean(out.probeMissing),
      };

      if (out.error) {
        loadErrors.push(record);
        log(`${t.pkg.padEnd(32)} ${rt.id.padEnd(5)} PROCESS ERROR: ${String(out.error).split("\n")[0].slice(0, 90)}`);
        continue;
      }

      const importKeys = new Set((out.phases.importTime || []).map((c) => c.key));
      const optInNew = (out.phases.optIn || []).filter((c) => !importKeys.has(c.key));
      record.slotsChangedOptIn = optInNew.length;
      loadErrors.push(record);

      const emit = (c, timing) => {
        const [ns, tgt, method] = c.key.split("|");
        const rhsForm = rhsFormOf(c.src);
        rows.push([t.pkg, rt.id, ns, tgt, method, bucketOf(ns, tgt, method), kindOf(ns, tgt),
                   mechanismOf(c, rhsForm), rhsForm, timing, c.kind,
                   c.shimmerMarker ? "shimmer-marker" : "",
                   BOOKKEEPING.has(method) ? "bookkeeping" : "observed"].join(","));
      };
      for (const c of out.phases.importTime || []) emit(c, "importTime");
      for (const c of optInNew) emit(c, "optIn");

      const flag = importErr ? `  LOAD FAILED: ${importErr.error.split("\n")[0].slice(0, 70)}` : "";
      log(`${t.pkg.padEnd(32)} ${rt.id.padEnd(5)} importTime=${String(record.slotsChangedImport).padStart(3)} optIn=${String(optInNew.length).padStart(3)}${flag}`);
    }
  }

  // --- observability sentinels -------------------------------------------------
  // A bucket that could not be measured on a runtime must not read as a null.
  // These rows exist so anyone aggregating the CSV alone cannot mistake an absent
  // slot for "no package modified it".
  const capsByRuntime = {};
  for (const r of raw) if (r.capabilities && !capsByRuntime[r.runtime]) capsByRuntime[r.runtime] = r.capabilities;

  const observability = {};
  for (const rt of usable) {
    const caps = capsByRuntime[rt.id];
    if (!caps) { observability[rt.id] = { note: "no successful run; capabilities unknown" }; continue; }
    const missingCore = Object.keys(caps.coreModulesMissing || {});
    const absentModuleSlots = Object.entries(caps.moduleSlots || {})
      .filter(([, present]) => !present).map(([k]) => k);
    observability[rt.id] = {
      runtimeVersion: caps.runtimeVersion,
      coreModulesMissing: caps.coreModulesMissing,
      moduleSlotsAbsent: absentModuleSlots,
      protoRequireIntercepts: caps.protoRequireIntercepts,
      requireExtensionsPresent: caps.requireExtensions,
      coreModuleSurface: caps.coreModuleSurface || {},
    };
    for (const m of missingCore) {
      rows.push(["(unmeasurable)", rt.id, m, "module", "(all)", "coremodule", "coremodule",
                 "", "", "", "notObservable", `core module did not load: ${String(caps.coreModulesMissing[m]).replace(/[,\n]/g, " ").slice(0, 80)}`,
                 "notObservable"].join(","));
    }
    for (const slot of absentModuleSlots) {
      rows.push(["(unmeasurable)", rt.id, "module", "Module", slot, "coremodule", "coremodule",
                 "", "", "", "notObservable", "module-system slot absent on this runtime",
                 "notObservable"].join(","));
    }
    if (caps.protoRequireIntercepts === false) {
      rows.push(["(unmeasurable)", rt.id, "module", "Module.prototype", "require", "coremodule", "coremodule",
                 "", "", "", "notObservable",
                 "slot exists but patching it does NOT intercept requires on this runtime",
                 "notObservable"].join(","));
    }
  }

  // --- deliverables -------------------------------------------------------------
  fs.mkdirSync(RESULTS, { recursive: true });

  const header = "agent,runtime,namespace,target,method,bucket,kind,mechanism,rhsForm,timing,changeKind,evidence,observability";
  fs.writeFileSync(path.join(RESULTS, "server-surface-crossruntime.csv"), [header, ...rows].join("\n"));

  fs.writeFileSync(path.join(RESULTS, "s1-load-errors.json"), JSON.stringify({
    generated: "see git/file mtime",
    runtimes: runtimeInfo,
    packageVersions: pkgVersions,
    observability,
    perTargetRuntime: loadErrors,
  }, null, 1));

  fs.writeFileSync(path.join(RESULTS, "s1-crossruntime-raw.json"), JSON.stringify(raw, null, 1));

  log(`wrote results/server-surface-crossruntime.csv (${rows.length} rows), s1-load-errors.json, s1-crossruntime-raw.json`);
  log("now run: node scripts/s1-crossruntime-report.js");
}
main();
