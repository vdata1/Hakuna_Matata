#!/usr/bin/env node
/**
 * Repair a coverage gap inherited from the Exp-1 fetch.
 *
 * `scan-applications.js` capped manifest fetching at MAX_MANIFESTS = 60 per
 * repository and took `.slice(0, 60)` of a PATH-SORTED list. For the 11 largest
 * monorepos that silently dropped arbitrary workspaces -- including, in n8n's
 * case, `packages/cli`, which is the actual server. Rooting a server closure at
 * workspaces we never fetched would undercount precisely the applications with
 * the cleanest server/client separation.
 *
 * This fetches only the MISSING package.json files (public raw.githubusercontent
 * reads, no auth, nothing executed) into cache/repo-files-extra/, leaving the
 * prior experiment's cache untouched.
 *
 * Usage: node scripts/fetch-missing-manifests.js [--dry]
 */
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const PRIOR = path.join(ROOT, "..", "supply-chain-monkey-patch");
const TREES = path.join(PRIOR, "cache", "trees");
const EXTRA = path.join(ROOT, "cache", "repo-files-extra");
const BRANCHES = path.join(ROOT, "cache", "branches.json");

/** Identical to scan-applications.js EXCLUDED, so coverage is defined the same way. */
const EXCLUDED = /(^|\/)(node_modules|\.git|\.yarn|fixtures?|__fixtures__|__tests__|__mocks__|tests?|e2e|cypress|examples?|demos?|docs|website|benchmarks?|sandbox|playground)(\/|$)/i;

const { population, listRepoPaths, keyFor } = require("./repo-cache.js");
const log = (...a) => console.error("[fetch]", ...a);

const branches = fs.existsSync(BRANCHES) ? JSON.parse(fs.readFileSync(BRANCHES, "utf8")) : {};
function defaultBranch(repo) {
  if (branches[repo]) return branches[repo];
  const b = execFileSync("gh", ["api", `repos/${repo}`, "--jq", ".default_branch"], { encoding: "utf8" }).trim();
  branches[repo] = b;
  fs.writeFileSync(BRANCHES, JSON.stringify(branches, null, 1));
  return b;
}

function missingFor(app) {
  const slug = app.repo.replace("/", "+");
  const tf = path.join(TREES, `${slug}.json`);
  if (!fs.existsSync(tf)) return [];
  const paths = JSON.parse(fs.readFileSync(tf, "utf8")).paths.filter((p) => !EXCLUDED.test(p));
  const mans = paths.filter((p) => /(^|\/)package\.json$/.test(p));
  const have = new Set(listRepoPaths(app.repo));
  return mans.filter((p) => !have.has(p));
}

async function main() {
  const dry = process.argv.includes("--dry");
  fs.mkdirSync(EXTRA, { recursive: true });
  const apps = population();
  const work = [];
  for (const a of apps) {
    for (const p of missingFor(a)) work.push({ repo: a.repo, p });
  }
  log(`${work.length} missing manifests across ${new Set(work.map((w) => w.repo)).size} repositories`);
  if (dry) { for (const w of work.slice(0, 10)) log("  would fetch", w.repo, w.p); return; }

  let ok = 0, miss = 0, i = 0;
  const CONCURRENCY = 8;
  async function worker() {
    for (;;) {
      const w = work[i++];
      if (!w) return;
      const dest = path.join(EXTRA, keyFor(w.repo, w.p));
      if (fs.existsSync(dest)) { ok++; continue; }
      let branch;
      try { branch = defaultBranch(w.repo); } catch { miss++; continue; }
      const url = `https://raw.githubusercontent.com/${w.repo}/${branch}/${w.p}`;
      try {
        const res = await fetch(url);
        if (!res.ok) { miss++; continue; }
        fs.writeFileSync(dest, await res.text());
        ok++;
      } catch { miss++; }
      if ((ok + miss) % 100 === 0) log(`  ${ok + miss}/${work.length}`);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  log(`fetched/present: ${ok}  unavailable: ${miss}`);
}
main();
