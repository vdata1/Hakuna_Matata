#!/usr/bin/env node
/**
 * S-2 step 2: what surface does each package in the server closures modify?
 *
 * Runs BOTH detectors over every extracted package and files each hit into one
 * of the handoff §4 buckets, which are never merged:
 *
 *   guard      -- String/Array/RegExp prototype methods: the surface security
 *                 guards actually dispatch through. This is the paper's claim.
 *   broad      -- other ECMAScript builtins: Error (esp. prepareStackTrace),
 *                 Promise, timers, statics. Supports only the weaker point.
 *   coremodule -- fs/http/... reached through a required core module, plus
 *                 module-loading interception. Explicitly NOT the guard surface.
 *   global     -- writes to global/globalThis.
 *
 * Builtin prototype/static hits come from the unmodified Exp-1 `scanSource`;
 * server-mechanism hits come from `detect-server-patch.js`. Nothing is executed.
 *
 * Usage:  node scripts/scan-server-corpus.js [--corpus <dir>] [--limit N]
 * Output: results/server-surface-by-package.json, results/server_hits.csv
 */
const fs = require("node:fs");
const path = require("node:path");
const { parse, scanSource, tierOf, BARRIER_METHODS,
        detectCoreJsExports, detectHelperProtoDefine } = require("./scan-monkeypatch.js");
const { scanServerSource, detectDefineAccessor } = require("./detect-server-patch.js");
const { reachableFiles } = require("./package-entry.js");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const log = (...a) => console.error("[scan]", ...a);

/** The guard-dispatch surface: what `if (key.startsWith('__proto__'))` runs on. */
const GUARD_BUILTINS = new Set(["String", "Array", "RegExp"]);

/**
 * Bucket a builtin prototype/static hit. A hit is `guard` only when it is BOTH
 * on a guard builtin AND a method a guard would dispatch through -- overriding
 * `String.raw` is not overriding `String.prototype.startsWith`.
 */
function bucketOfBuiltinHit(h) {
  if (GUARD_BUILTINS.has(h.builtin) && h.target === "prototype" && BARRIER_METHODS.has(h.method)) {
    return "guard";
  }
  return "broad";
}

function walkJs(dir, out = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (e.name !== "node_modules") walkJs(p, out); }
    else if (/\.(js|cjs|mjs)$/.test(e.name)) out.push(p);
  }
  return out;
}

/** corpus dir name -> package name (`@scope/name@1.2.3` lives at `@scope/name@1.2.3`). */
function packagesIn(corpusDir) {
  const out = [];
  for (const e of fs.readdirSync(corpusDir, { withFileTypes: true })) {
    if (!e.isDirectory()) continue;
    if (e.name.startsWith("@")) {
      for (const s of fs.readdirSync(path.join(corpusDir, e.name), { withFileTypes: true })) {
        if (!s.isDirectory()) continue;
        out.push({ dir: path.join(corpusDir, e.name, s.name), name: `${e.name}/${s.name.replace(/@[^@]*$/, "")}` });
      }
    } else {
      out.push({ dir: path.join(corpusDir, e.name), name: e.name.replace(/@[^@]*$/, "") });
    }
  }
  return out;
}

function main() {
  const ci = process.argv.indexOf("--corpus");
  const corpusDir = ci !== -1 ? path.resolve(process.argv[ci + 1]) : path.join(ROOT, "cache", "corpus");
  const li = process.argv.indexOf("--limit");

  let pkgs = packagesIn(corpusDir);
  if (li !== -1) pkgs = pkgs.slice(0, Number(process.argv[li + 1]));
  log(`${pkgs.length} packages in ${corpusDir}`);

  const rows = [];
  const byPackage = {};
  let files = 0, parseFailures = 0, scanned = 0;

  const parseCache = new Map();
  const parseFile = (f) => {
    if (parseCache.has(f)) return parseCache.get(f);
    let ast = null;
    try { ast = parse(fs.readFileSync(f, "utf8")); } catch { ast = null; }
    parseCache.set(f, ast);
    return ast;
  };

  for (const pkg of pkgs) {
    const buckets = { guard: 0, broad: 0, coremodule: 0, global: 0, globalDefine: 0 };
    const bucketsAllFiles = { guard: 0, broad: 0, coremodule: 0, global: 0, globalDefine: 0 };
    const methods = { guard: new Set(), broad: new Set(), coremodule: new Set(),
                      global: new Set(), globalDefine: new Set() };
    const mechanisms = new Set();
    parseCache.clear();

    /**
     * Only files the Node entry can actually reach count toward the primary
     * figure; every .js file is also tallied as an upper bound. Without this,
     * `bowser`'s browser UMD bundle credited it with patching the guard surface
     * on 41.5% of server closures from a file no server ever requires.
     */
    let reachable;
    try { reachable = reachableFiles(pkg.dir, parseFile).reachable; }
    catch { reachable = null; }
    const isReachable = (f) => !reachable || reachable.has(path.resolve(f));

    for (const f of walkJs(pkg.dir)) {
      files++;
      let src, ast;
      try { src = fs.readFileSync(f, "utf8"); } catch { continue; }
      try { ast = parse(src); } catch { parseFailures++; continue; }
      const rel = path.relative(pkg.dir, f);

      let bHits = [];
      try { bHits = scanSource(src, ast); } catch { /* detector-internal, counted as parse-clean */ }
      const inEntry = isReachable(f);
      for (const h of bHits) {
        if (h.shadowed) continue;                       // a local `String`, not the builtin
        const bucket = bucketOfBuiltinHit(h);
        bucketsAllFiles[bucket]++;
        if (!inEntry) continue;
        buckets[bucket]++;
        methods[bucket].add(`${h.builtin}.${h.target === "prototype" ? "prototype." : ""}${h.method}`);
        mechanisms.add(h.rhsClass === "wraps-original" ? "wrap" : "replace");
        rows.push([pkg.name, bucket, h.builtin, h.target, h.method, h.kind || "assignment",
                   h.rhsClass, h.guarded ? "guarded" : "unconditional", h.importTime ? "import-time" : "opt-in",
                   h.tier || "", rel, h.line].join("\t"));
      }

      /**
       * core-js and the es-shims family never write `X.prototype.m = ...`; they
       * route every patch through an internal helper, so `scanSource` reads the
       * ecosystem's most prolific guard-surface patcher as ZERO. Handoff §2 calls
       * this out by name as the blind spot that bit Exp 2. Both helper-shaped
       * detectors are therefore applied here alongside the syntactic one.
       */
      let helperHits = [];
      try {
        for (const e of detectCoreJsExports(ast)) {
          for (const m of e.methods) {
            helperHits.push({ builtin: e.builtin, target: e.target, method: m,
                              kind: "core-js-export", rhsClass: "semantics-preserving" });
          }
        }
        for (const h of detectHelperProtoDefine(ast)) {
          helperHits.push({ builtin: h.builtin, target: h.target, method: h.method,
                            kind: "helper-define", rhsClass: h.rhsClass });
        }
        // `__defineGetter__` on a builtin prototype -- the shape S-3 caught us missing.
        for (const h of detectDefineAccessor(ast)) {
          helperHits.push({ builtin: h.builtin, target: h.target, method: h.method,
                            kind: h.kind, rhsClass: h.rhsClass });
        }
      } catch { /* helper detectors are advisory; syntactic hits still stand */ }
      for (const h of helperHits) {
        const bucket = bucketOfBuiltinHit(h);
        bucketsAllFiles[bucket]++;
        if (!inEntry) continue;
        buckets[bucket]++;
        methods[bucket].add(`${h.builtin}.${h.target === "prototype" ? "prototype." : ""}${h.method}`);
        mechanisms.add("helper");
        rows.push([pkg.name, bucket, h.builtin, h.target, h.method, h.kind,
                   h.rhsClass, "", "", "helper-routed", rel, ""].join("\t"));
      }

      let sHits = [];
      try { sHits = scanServerSource(src, ast); } catch { /* ditto */ }
      for (const h of sHits) {
        /**
         * `global-define` is kept out of every modification count: writing
         * `global.acorn = {}` is a UMD packaging convention, not modification of
         * a builtin. It is tallied only so the writeup can say how common it is.
         */
        const bucket = h.bucket === "global" ? "global"
          : h.bucket === "global-define" ? "globalDefine" : "coremodule";
        bucketsAllFiles[bucket]++;
        if (!inEntry) continue;
        buckets[bucket]++;
        methods[bucket].add(h.target && h.target !== "module" && h.target !== "global"
          ? `${h.namespace}.${h.target}.${h.method}` : `${h.namespace}.${h.method}`);
        mechanisms.add(h.mechanism);
        rows.push([pkg.name, bucket, h.namespace, h.target, h.method, h.shape,
                   h.rhsClass, "", "", h.bucket, rel, h.line].join("\t"));
      }
    }
    scanned++;
    const total = buckets.guard + buckets.broad + buckets.coremodule + buckets.global;
    const totalAll = Object.values(bucketsAllFiles).reduce((a, b) => a + b, 0);
    if (total || totalAll) {
      byPackage[pkg.name] = {
        buckets, bucketsAllFiles,
        methods: Object.fromEntries(Object.entries(methods).map(([k, v]) => [k, [...v].sort().slice(0, 40)])),
        mechanisms: [...mechanisms].sort(),
      };
    }
    if (scanned % 250 === 0) log(`${scanned}/${pkgs.length} packages`);
  }

  const modifiers = Object.keys(byPackage);
  const counts = {
    packagesScanned: pkgs.length, filesParsed: files, parseFailures,
    parseFailureRate: files ? +(100 * parseFailures / files).toFixed(3) : 0,
    packagesModifyingAnything: modifiers.filter((p) =>
      Object.values(byPackage[p].buckets).some((n) => n > 0)).length,
    guard: modifiers.filter((p) => byPackage[p].buckets.guard > 0).length,
    broad: modifiers.filter((p) => byPackage[p].buckets.broad > 0).length,
    coremodule: modifiers.filter((p) => byPackage[p].buckets.coremodule > 0).length,
    global: modifiers.filter((p) => byPackage[p].buckets.global > 0).length,
    globalDefineOnly: modifiers.filter((p) => byPackage[p].buckets.globalDefine > 0 &&
      byPackage[p].buckets.guard + byPackage[p].buckets.broad +
      byPackage[p].buckets.coremodule + byPackage[p].buckets.global === 0).length,
    guardAllFiles: modifiers.filter((p) => byPackage[p].bucketsAllFiles.guard > 0).length,
    broadAllFiles: modifiers.filter((p) => byPackage[p].bucketsAllFiles.broad > 0).length,
  };

  fs.mkdirSync(RESULTS, { recursive: true });
  fs.writeFileSync(path.join(RESULTS, "server-surface-by-package.json"),
    JSON.stringify({ generated: new Date().toISOString().slice(0, 10), counts,
      // The names actually scanned -- coverage must be computed from this, not
      // from the target list, or an incomplete fetch silently inflates coverage.
      scannedPackages: pkgs.map((p) => p.name).sort(),
      byPackage }, null, 1));
  fs.writeFileSync(path.join(RESULTS, "server_hits.csv"),
    ["package\tbucket\tnamespace\ttarget\tmethod\tshape\trhsClass\tguarded\ttiming\tdetail\tfile\tline",
     ...rows].join("\n"));
  log(JSON.stringify(counts, null, 1));
  log("wrote results/server-surface-by-package.json, results/server_hits.csv");
}
main();
