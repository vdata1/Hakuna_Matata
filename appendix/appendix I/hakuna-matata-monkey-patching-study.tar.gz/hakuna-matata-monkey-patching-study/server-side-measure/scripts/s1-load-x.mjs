/**
 * S-1 cross-runtime target loader: the portable form of `scripts/s1-load.js`.
 *
 *   node --import ../probe-x.mjs      s1-load-x.mjs <pkg> <outfile>
 *   bun  --preload ../probe-x.mjs     s1-load-x.mjs <pkg> <outfile>
 *   deno run -A --preload ../probe-x.mjs s1-load-x.mjs <pkg> <outfile>
 *
 * Loads exactly ONE target, diffs, then attempts the opt-in entry point and diffs
 * again -- the import-time vs opt-in split the parent arm exists to measure.
 * No classification here; the driver does that with the Exp-2 RHS classifier.
 */
import { createRequire } from "node:module";
import { join } from "node:path";

const argv = process.argv.slice(2);
const target = argv[0];
const outPath = argv[1];

/**
 * Resolve the target from the SANDBOX cwd, not from scripts/. Same trap the Node
 * loader documents: a plain require would MODULE_NOT_FOUND and the run would look
 * like "modifies nothing".
 */
const targetRequire = createRequire(join(process.cwd(), "package.json"));
const selfRequire = createRequire(import.meta.url);

const P = globalThis.__PROBE__;
const out = {
  target,
  runtime: P ? P.runtime : "unknown",
  capabilities: P ? P.capabilities : null,
  phases: {},
  errors: [],
};

if (!P) {
  // The preload did not run: report it loudly rather than emitting an empty diff.
  out.errors.push({ phase: "preload", error: "__PROBE__ missing; preload flag did not take effect" });
  out.probeMissing = true;
} else {
  out.baselineSlots = P.rebaseline();
}

const describe = (chg) => {
  const a = chg.after, b = chg.before;
  const nv = a ? (a.isAccessor ? (a.get || a.set) : a.value) : undefined;
  const ov = b ? (b.isAccessor ? (b.get || b.set) : b.value) : undefined;
  let src = null, marker = false, fnName = null, arity = null;
  if (typeof nv === "function") {
    // Native toString captured at preload -- never the target's replacement.
    try { src = P.srcOf(nv).slice(0, 600); } catch { src = null; }
    try { fnName = nv.name || null; arity = nv.length; } catch { /* proxy */ }
    try { marker = Boolean(nv.__wrapped || nv.__original || nv.__unwrap); } catch { /* ignore */ }
  }
  return {
    key: chg.key, kind: chg.kind,
    newIsFunction: typeof nv === "function", oldIsFunction: typeof ov === "function",
    newIsAccessor: Boolean(a && a.isAccessor), oldIsAccessor: Boolean(b && b.isAccessor),
    shimmerMarker: marker, fnName, arity, src,
  };
};

function phase(name, fn) {
  try { fn(); } catch (e) { out.errors.push({ phase: name, error: String((e && e.message) || e).slice(0, 300) }); }
  try { out.phases[name] = P ? P.diff().map(describe) : []; }
  catch (e) { out.errors.push({ phase: name + ":diff", error: String(e).slice(0, 200) }); }
}

// --- phase 1: import time -----------------------------------------------------
let mod = null;
phase("importTime", () => { mod = targetRequire(target); });

/**
 * A CJS require can fail on a package that only ships ESM -- more likely on Deno
 * and Bun than on Node. Fall back to dynamic import so an ESM-only package is
 * recorded as "loaded via import", not as a load failure.
 */
if (!mod) {
  const cjsError = out.errors.find((e) => e.phase === "importTime");
  try {
    mod = await import(target);
    out.loadedVia = "esm-import";
    if (cjsError) { cjsError.recovered = true; out.errors = out.errors.filter((e) => e !== cjsError); }
    try { out.phases.importTime = P ? P.diff().map(describe) : []; } catch { /* ignore */ }
  } catch (e) {
    out.errors.push({ phase: "importTime:esm", error: String((e && e.message) || e).slice(0, 300) });
  }
} else {
  out.loadedVia = "cjs-require";
}

// --- phase 2: explicit opt-in -------------------------------------------------
const OPT_IN = ["init", "start", "instrument", "register", "enable", "setup",
                "install", "patch", "activate", "configure", "proto"];
phase("optIn", () => {
  if (!mod) return;
  const candidates = [];
  const root = typeof mod === "function" ? mod : null;
  const obj = (mod && typeof mod === "object") ? mod : (root || {});
  if (typeof obj.gracefulify === "function") {
    candidates.push(() => obj.gracefulify(selfRequire("node:fs")));
  }
  for (const name of OPT_IN) {
    if (obj && typeof obj[name] === "function") candidates.push(() => obj[name]());
    if (obj && obj.default && typeof obj.default[name] === "function") candidates.push(() => obj.default[name]());
  }
  out.optInAttempted = candidates.length;
  /**
   * Which opt-in entry points were actually REACHABLE on this runtime. Bun's
   * CJS/ESM interop can drop a named export that Node and Deno expose (undici's
   * `install` is the live example), so a target can register zero changes here
   * simply because the probe never found an entry point to call. That is a
   * different -- and separately interesting -- fact from an entry point that ran
   * and did nothing, and the report must not merge them.
   */
  out.exportShape = {
    type: typeof mod,
    hasDefault: Boolean(mod && mod.default),
    optInFound: OPT_IN.filter((n) => obj && typeof obj[n] === "function"),
    optInFoundOnDefault: OPT_IN.filter((n) => obj && obj.default && typeof obj.default[n] === "function"),
    gracefulify: typeof (obj && obj.gracefulify) === "function",
  };
  for (const c of candidates) {
    try { c(); } catch (e) { out.errors.push({ phase: "optIn:call", error: String((e && e.message) || e).slice(0, 200) }); }
  }
});

/** To a FILE, never stdout: elastic-apm-node writes JSON log lines to stdout. */
if (outPath) selfRequire("node:fs").writeFileSync(outPath, JSON.stringify(out));
else process.stdout.write(JSON.stringify(out));
