#!/usr/bin/env node
/**
 * S-2 step 1: resolve the SERVER-RUNTIME dependency closure of every application.
 *
 * Handoff §3: "a package counts as server-runtime only if reachable from that
 * entry. Exclude anything reachable only from a client entry. Report client-build
 * reach as a separate contrast column, never merged in."
 *
 * Method, stated precisely enough to reproduce (handoff §9):
 *   1. Population: the 173 analysable awesome-selfhosted Node applications from
 *      the Exp-1 scan (results/app-scan.json, status=ok). Third-party catalogue,
 *      so the denominator is not self-selected.
 *   2. Every lockfile in a repository is handled separately and scoped to its own
 *      subtree, so a `client/pnpm-lock.yaml` cannot contribute server reach.
 *   3. Within a lockfile, each workspace manifest is classified server/client/
 *      dual/tooling (workspaces.js) from declared evidence.
 *   4. The lockfile graph is traversed rooted at the server workspaces only,
 *      following workspace links, over `dependencies` + `optionalDependencies`.
 *      The client closure is computed the same way, separately.
 *
 * This is a static over-approximation of the require graph -- a declared runtime
 * dependency need not actually be require()d -- and therefore an UPPER bound on
 * server reach. Nothing is executed.
 *
 * Usage:  node scripts/server-closure.js [--limit N]
 * Output: results/server-closures.json
 */
const fs = require("node:fs");
const path = require("node:path");
const { population, manifests, readRepoFile } = require("./repo-cache.js");
const { classifyManifest } = require("./workspaces.js");
const { closureFor } = require("./rooted-closure.js");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const log = (...a) => console.error("[closure]", ...a);

const dirOf = (p) => { const i = p.lastIndexOf("/"); return i === -1 ? "" : p.slice(0, i); };
const SERVER_KINDS = new Set(["server", "dual"]);

function analyseApp(app) {
  const { manifests: ms, unparseable } = manifests(app.repo);
  const declared = (app.lockfiles || []).map((l) => l.path);
  const out = {
    repo: app.repo, stars: app.stars, lockfiles: [],
    serverReach: new Set(), clientReach: new Set(), anyReach: new Set(),
    serverRoots: 0, clientRoots: 0, ssrRoots: 0,
    unparseableManifests: unparseable.length, notes: [],
  };

  for (const lockPath of declared) {
    const text = readRepoFile(app.repo, lockPath);
    if (text === null) { out.lockfiles.push({ path: lockPath, error: "not-cached" }); continue; }
    const base = dirOf(lockPath);

    // Manifests inside this lockfile's own subtree, keyed relative to the lockfile.
    const scoped = new Map();
    const scopedManifests = [];   // yarn classic has no workspace entries; it needs these
    for (const m of ms) {
      const d = m.dir.replace(/\/$/, "");
      if (base && !(d === base || d.startsWith(base + "/"))) continue;
      const rel = base ? d.slice(base.length).replace(/^\//, "") : d;
      scoped.set(rel, classifyManifest(m.pkg, m.dir));
      scopedManifests.push({ dir: rel, pkg: m.pkg });
    }
    const kindOf = (d) => { const c = scoped.get(d.replace(/^\.$/, "")); return c ? c.kind : "unknown"; };

    const srv = closureFor(lockPath, text, (d) => SERVER_KINDS.has(kindOf(d)), scopedManifests);
    const cli = closureFor(lockPath, text, (d) => kindOf(d) === "client", scopedManifests);
    const any = closureFor(lockPath, text, () => true, scopedManifests);

    const ssr = [...scoped.values()].filter((c) => c.ssr && c.ssr.length).length;
    out.serverRoots += srv.roots.length; out.clientRoots += cli.roots.length; out.ssrRoots += ssr;
    for (const p of srv.reached) out.serverReach.add(p);
    for (const p of cli.reached) out.clientReach.add(p);
    for (const p of any.reached) out.anyReach.add(p);

    out.lockfiles.push({
      path: lockPath, error: srv.error || null,
      manifestsInScope: scoped.size,
      serverRoots: srv.roots.length, clientRoots: cli.roots.length,
      serverReached: srv.reached.size, clientReached: cli.reached.size, anyReached: any.reached.size,
      unresolved: srv.unresolved,
    });
  }

  const supported = out.lockfiles.filter((l) => !l.error);
  const unsupported = out.lockfiles.filter((l) => l.error === "unsupported-format");
  out.coverage = !out.lockfiles.length ? "no-lockfile"
    : supported.length === 0 ? "unsupported-format-only"
    : unsupported.length ? "partial" : "full";
  if (out.coverage !== "full") out.notes.push(`${unsupported.length}/${out.lockfiles.length} lockfiles unsupported or unreadable`);
  if (out.coverage !== "no-lockfile" && out.serverRoots === 0) out.notes.push("no workspace classified as a server entry");
  return out;
}

function main() {
  const limitArg = process.argv.indexOf("--limit");
  let apps = population();
  if (limitArg !== -1) apps = apps.slice(0, Number(process.argv[limitArg + 1]));

  const results = [];
  for (const a of apps) {
    try { results.push(analyseApp(a)); }
    catch (e) { results.push({ repo: a.repo, coverage: "error", error: e.message, serverReach: new Set(), clientReach: new Set(), anyReach: new Set() }); }
  }

  const byCoverage = {};
  for (const r of results) byCoverage[r.coverage] = (byCoverage[r.coverage] || 0) + 1;
  const usable = results.filter((r) => r.coverage === "full" || r.coverage === "partial");
  const withServer = usable.filter((r) => r.serverRoots > 0);

  const payload = {
    generated: new Date().toISOString().slice(0, 10),
    question: "Which packages can the SERVER process of each deployed Node application reach?",
    method: {
      population: "awesome-selfhosted Node applications, status=ok in the Exp-1 scan (app-scan.json)",
      rooting: "lockfile graph traversed rooted at server-classified workspaces only, following workspace links, over dependencies + optionalDependencies",
      clientContrast: "computed identically but rooted at client-classified workspaces; never merged",
      bound: "static over-approximation of the require graph: an UPPER bound on server reach within the declared production closure",
      manifestRepair: "726 manifests the Exp-1 fetch truncated (MAX_MANIFESTS=60) were re-fetched; without them n8n's server workspace packages/cli was invisible",
      formats: "npm v2/v3, pnpm, yarn berry, and yarn classic are all traversed rooted; npm lockfileVersion 1 carries no workspace paths and is reported as unsupported, never silently counted as empty",
    },
    counts: {
      applications: results.length,
      byCoverage,
      usable: usable.length,
      withServerEntry: withServer.length,
      medianServerClosure: median(withServer.map((r) => r.serverReach.size)),
      medianClientClosure: median(usable.filter((r) => r.clientRoots).map((r) => r.clientReach.size)),
    },
    applications: results.map((r) => ({
      ...r,
      serverReach: [...r.serverReach].sort(),
      clientReach: [...r.clientReach].sort(),
      anyReach: [...r.anyReach].sort(),
    })),
  };
  fs.mkdirSync(RESULTS, { recursive: true });
  fs.writeFileSync(path.join(RESULTS, "server-closures.json"), JSON.stringify(payload, null, 1));
  log("coverage:", JSON.stringify(byCoverage));
  log(`usable ${usable.length} | with a server entry ${withServer.length} | median server closure ${payload.counts.medianServerClosure}`);
  log("wrote results/server-closures.json");
}

function median(xs) {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

main();
