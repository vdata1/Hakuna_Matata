#!/usr/bin/env node
/**
 * Fixtures for the server-mechanism detector.
 *
 * Handoff §8 asks for both directions: a real shimmer wrap must hit, a lookalike
 * must not. The negative cases matter more than the positive ones here -- this
 * detector keys off ordinary identifiers like `fs` and `wrap`, which appear all
 * over normal code, so binding-awareness is the whole correctness story.
 *
 * Usage: node scripts/test-server-detect.js
 */
const { parse } = require("./scan-monkeypatch.js");
const { scanServerSource } = require("./detect-server-patch.js");

const scan = (src) => scanServerSource(src, parse(src));
let pass = 0, fail = 0;
function check(label, src, assertion) {
  let hits;
  try { hits = scan(src); }
  catch (e) { console.log("ERROR".padEnd(6), label, "--", e.message); fail++; return; }
  const ok = assertion(hits);
  console.log((ok ? "PASS" : "FAIL").padEnd(6), label);
  if (!ok) console.log("       got:", JSON.stringify(hits));
  ok ? pass++ : fail++;
}
const none = (h) => h.length === 0;
const one = (pred) => (h) => h.length === 1 && pred(h[0]);
const some = (pred) => (h) => h.some(pred);

// --- wrap helpers (must hit) ------------------------------------------------
check("shimmer.wrap on a core module",
  `const shimmer = require('shimmer'); const http = require('http');
   shimmer.wrap(http, 'request', (orig) => function () { return orig.apply(this, arguments); });`,
  some((h) => h.bucket === "wrap-helper" && h.method === "request" && h.mechanism === "wrap"));

check("destructured wrap from shimmer",
  `const { wrap } = require('shimmer');
   wrap(target, 'handle', (o) => function () { return o.apply(this, arguments); });`,
  one((h) => h.bucket === "wrap-helper" && h.method === "handle"));

check("massWrap records every named method",
  `const shimmer = require('shimmer');
   shimmer.massWrap([fs], ['readFile', 'writeFile'], (o) => o);`,
  one((h) => h.bucket === "wrap-helper" && h.method === "readFile+writeFile" && h.mechanism === "wrap-many"));

check("ESM import of shimmer",
  `import shimmer from 'shimmer';
   shimmer.wrap(obj, 'send', (o) => o);`,
  one((h) => h.bucket === "wrap-helper" && h.method === "send"));

// --- require hooks (must hit) -----------------------------------------------
check("new Hook() from require-in-the-middle",
  `const Hook = require('require-in-the-middle');
   new Hook(['express'], function (exports) { return exports; });`,
  one((h) => h.bucket === "require-hook" && h.method === "express"));

check("Module._load interception",
  `const Module = require('module');
   Module._load = function () { return orig.apply(this, arguments); };`,
  one((h) => h.bucket === "require-hook" && h.method === "_load"));

check("require.extensions write",
  `require.extensions['.ts'] = function (m, f) { return compile(m, f); };`,
  one((h) => h.bucket === "require-hook" && h.target === "require.extensions"));

// --- core modules and globals (must hit) ------------------------------------
check("core module method replaced",
  `const fs = require('fs');
   const orig = fs.readFile;
   fs.readFile = function () { return orig.apply(this, arguments); };`,
  some((h) => h.bucket === "coremodule" && h.namespace === "fs" && h.method === "readFile"));

check("node: prefix is normalised",
  `const fs = require('node:fs'); fs.open = function () {};`,
  one((h) => h.bucket === "coremodule" && h.namespace === "fs"));

check("nested core module namespace",
  `const fs = require('fs'); fs.promises.readFile = function () {};`,
  one((h) => h.bucket === "coremodule" && h.target === "promises" && h.method === "readFile"));

check("global timer replaced",
  `global.setTimeout = function () {};`,
  one((h) => h.bucket === "global" && h.method === "setTimeout"));

check("globalThis write",
  `globalThis.fetch = function () {};`,
  one((h) => h.bucket === "global" && h.method === "fetch"));

// --- lookalikes (must NOT hit) ----------------------------------------------
check("comment mentioning shimmer.wrap",
  `// we used to call shimmer.wrap(http, 'request', fn) here
   const x = 1;`, none);

check("string containing a wrap call",
  `const doc = "shimmer.wrap(http, 'request', fn)"; log(doc);`, none);

check("local object coincidentally named fs",
  `const fs = { readFile() {} }; fs.readFile = function () {};`, none);

check("wrap() that is a local function, not shimmer's",
  `function wrap(o, m, f) { return f; }
   wrap(obj, 'method', fn);`, none);

check("property READ of a core module is not a modification",
  `const fs = require('fs'); const r = fs.readFile; r();`, none);

check("Module-like user object is not the module system",
  `const myModule = { _load: null }; myModule._load = function () {};`, none);

check("calling a core module method is not patching it",
  `const fs = require('fs'); fs.readFile('a', cb);`, none);

check("unrelated package named wrap-ish",
  `const wrapper = require('lodash'); wrapper.wrap(fn, other);`, none);

// --- scope shadowing (REGRESSION) --------------------------------------------
// `parseurl` binds `url` to the core module at module scope and also uses a local
// `url` inside its functions. Without scope resolution every `url.pathname = ...`
// on a parsed-URL object read as patching the `url` core module, which put
// parseurl top of the core-module table at 73% of servers.
check("REGRESSION: parameter shadowing the core module binding is not a patch",
  `const url = require('url');
   function parse(url) { url.pathname = '/x'; return url; }`, none);

check("REGRESSION: local redeclaration shadows the module binding",
  `const fs = require('fs');
   function f() { const fs = {}; fs.readFile = function () {}; }`, none);

check("the real module binding still hits when not shadowed",
  `const fs = require('fs');
   function f() { fs.readFile = function () {}; }`,
  one((h) => h.bucket === "coremodule" && h.namespace === "fs"));

// --- defining vs modifying a global (REGRESSION) -----------------------------
// Every UMD wrapper writes `global.<libname> = ...`. That DEFINES a new global;
// it does not modify a builtin one. Conflating them made acorn, async and the
// @jridgewell packages look like global modifiers on ~50% of servers.
check("REGRESSION: UMD global export is global-define, not builtin modification",
  `global.acorn = {};`,
  one((h) => h.bucket === "global-define" && h.method === "acorn"));

check("modifying a real builtin global is still global",
  `global.setTimeout = function () {};`,
  one((h) => h.bucket === "global" && h.method === "setTimeout"));

// --- data write vs method replacement (REGRESSION) ---------------------------
check("REGRESSION: process.exitCode data write is not a core-module patch",
  `import process from 'node:process';
   process.exitCode = check() ? 0 : 2;`, none);

check("method replacement through a ternary of function refs still hits",
  `const buffer = require('buffer');
   buffer.Buffer.concat = makeNoOp ? noop : OriginalBufferConcat;`,
  one((h) => h.bucket === "coremodule" && h.method === "concat"));

// --- legacy accessor definition (found by S-3) --------------------------------
const { detectDefineAccessor } = require("./detect-server-patch.js");
const accessorScan = (src) => detectDefineAccessor(parse(src));
function checkAcc(label, src, assertion) {
  let hits;
  try { hits = accessorScan(src); }
  catch (e) { console.log("ERROR".padEnd(6), label, "--", e.message); fail++; return; }
  const ok = assertion(hits);
  console.log((ok ? "PASS" : "FAIL").padEnd(6), label);
  if (!ok) console.log("       got:", JSON.stringify(hits));
  ok ? pass++ : fail++;
}

checkAcc("S-3 REGRESSION: __defineGetter__ on a builtin prototype is a modification",
  `String.prototype.__defineGetter__('rainbow', function () { return this; });`,
  (h) => h.length === 1 && h[0].builtin === "String" && h[0].method === "rainbow");

checkAcc("__defineSetter__ is caught too",
  `Array.prototype.__defineSetter__('last', function (v) { this[this.length-1] = v; });`,
  (h) => h.length === 1 && h[0].kind === "defineSetter");

checkAcc("__defineGetter__ on a NON-builtin prototype does not hit",
  `MyClass.prototype.__defineGetter__('x', function () { return 1; });`,
  (h) => h.length === 0);

checkAcc("__defineGetter__ on an instance does not hit",
  `const o = {}; o.__defineGetter__('x', function () { return 1; });`,
  (h) => h.length === 0);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
