#!/usr/bin/env node
/**
 * Resolve the selected server-closure packages to published tarballs.
 *
 * Emits the same dataset shape as Exp-1's AugTop1K_npm.json so the existing,
 * integrity-verifying `fetch-corpus.js` can consume it unchanged (handoff §8:
 * reuse the corpus fetch, do not reimplement it).
 *
 * VERSION CAVEAT: the closures resolve at package-NAME granularity, so there is
 * no single version to ask for. We take each package's `latest`, which is a
 * proxy for what a fresh deploy installs, not necessarily the version any given
 * lockfile pinned. Recorded in the output so the writeup can state it.
 *
 * Registry metadata only; no auth, nothing executed.
 *
 * Usage:  node scripts/resolve-server-dataset.js [--limit N]
 * Output: results/server-dataset.json, cache/registry/<pkg>.json
 */
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");
const REG = path.join(ROOT, "cache", "registry");
/**
 * The registry rate-limits: an initial run at concurrency 16 with no backoff
 * drew HTTP 429 after ~674 packages and failed the remaining 2,357. Be a polite
 * client -- modest concurrency, exponential backoff, and honour Retry-After.
 * Per-package responses are cached, so a re-run resumes rather than refetches.
 */
const CONCURRENCY = 5;
const MAX_RETRIES = 6;
const log = (...a) => console.error("[resolve]", ...a);

async function manifest(name) {
  const cacheFile = path.join(REG, `${name.replace(/\//g, "+")}.json`);
  if (fs.existsSync(cacheFile)) {
    try { return JSON.parse(fs.readFileSync(cacheFile, "utf8")); } catch { /* refetch */ }
  }
  let res = null;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    res = await fetch(`https://registry.npmjs.org/${name}/latest`, {
      headers: { accept: "application/vnd.npm.install-v1+json, application/json" },
    });
    if (res.status !== 429 && res.status < 500) break;
    const retryAfter = Number(res.headers.get("retry-after"));
    const waitMs = Number.isFinite(retryAfter) && retryAfter > 0
      ? retryAfter * 1000
      : Math.min(30000, 500 * 2 ** attempt);
    await new Promise((r) => setTimeout(r, waitMs));
  }
  if (!res || !res.ok) return null;
  const j = await res.json();
  fs.mkdirSync(REG, { recursive: true });
  fs.writeFileSync(cacheFile, JSON.stringify(j));
  return j;
}

async function main() {
  const sel = JSON.parse(fs.readFileSync(path.join(RESULTS, "scan-targets.json"), "utf8"));
  let targets = sel.targets;
  const li = process.argv.indexOf("--limit");
  if (li !== -1) targets = targets.slice(0, Number(process.argv[li + 1]));

  const rows = [], failed = [];
  let i = 0, done = 0;
  async function worker() {
    for (;;) {
      const name = targets[i++];
      if (!name) return;
      let m = null;
      try { m = await manifest(name); } catch { /* counted below */ }
      done++;
      if (done % 250 === 0) log(`${done}/${targets.length}`);
      if (!m || !m.dist || !m.dist.tarball) { failed.push(name); continue; }
      rows.push({
        name, version: m.version,
        scoped: name.startsWith("@"),
        tarball: m.dist.tarball,
        integrity: m.dist.integrity || null,
        shasum: m.dist.shasum || null,
        unpackedSize: m.dist.unpackedSize || null,
        deprecated: Boolean(m.deprecated),
      });
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));

  rows.sort((a, b) => a.name.localeCompare(b.name));
  fs.writeFileSync(path.join(RESULTS, "server-dataset.json"), JSON.stringify(rows, null, 1));
  fs.writeFileSync(path.join(RESULTS, "server-dataset.meta.json"), JSON.stringify({
    generated: new Date().toISOString().slice(0, 10),
    requested: targets.length, resolved: rows.length, unresolved: failed.length,
    versionPolicy: "latest at resolution time; closures are name-granular so no lockfile version is implied",
    unresolvedPackages: failed.slice(0, 200),
  }, null, 1));
  log(`resolved ${rows.length}/${targets.length}; unresolved ${failed.length}`);
  log("wrote results/server-dataset.json");
}
main();
