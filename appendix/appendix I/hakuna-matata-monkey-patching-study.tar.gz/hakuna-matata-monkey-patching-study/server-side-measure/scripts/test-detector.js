#!/usr/bin/env node
// VENDORED from ../supply-chain-monkey-patch/scripts/test-detector.js (Exp 1/2 tooling).
// Copied rather than imported so this study is reproducible standalone (handoff §6).
// Upstream is the original; changes here are additive, never silent divergence.
/**
 * Detector fixtures. A prevalence study is only as trustworthy as its detector,
 * so both directions are tested: shapes that MUST be caught, and shapes that
 * must NOT be (property reads, strings, user classes, local prototypes).
 *
 * Usage: node scripts/test-detector.js
 */
const { parse, scanSource } = require("./scan-monkeypatch.js");

const scan = (src) => scanSource(src, parse(src));

let pass = 0, fail = 0;
function check(label, src, assertion) {
  let hits;
  try { hits = scan(src); }
  catch (e) { console.log("ERROR".padEnd(6), label, "--", e.message); fail++; return; }
  const ok = assertion(hits, src);
  console.log((ok ? "PASS" : "FAIL").padEnd(6), label);
  if (!ok) console.log("       got:", JSON.stringify(hits));
  ok ? pass++ : fail++;
}

const one = (pred) => (h) => h.length === 1 && pred(h[0]);
const none = (h) => h.length === 0;

console.log("--- must detect ---");
check("unconditional prototype assignment",
  `String.prototype.startsWith = function(){ return false }`,
  one((h) => h.builtin === "String" && h.method === "startsWith" &&
             h.kind === "assignment" && !h.guarded && h.target === "prototype"));

check("computed prototype assignment with literal key",
  `Array.prototype['includes'] = function(){}`,
  one((h) => h.method === "includes" && h.computed));

check("computed prototype assignment, dynamic key",
  `const n = 'x'; Array.prototype[n] = function(){}`,
  one((h) => h.method === null && h.computed));

check("Object.defineProperty on a prototype",
  `Object.defineProperty(Array.prototype, 'includes', { value: function(){} })`,
  one((h) => h.builtin === "Array" && h.method === "includes" && h.kind === "defineProperty"));

check("Object.defineProperties on a prototype (multiple methods)",
  `Object.defineProperties(String.prototype, { startsWith: {value:1}, endsWith: {value:2} })`,
  (h) => h.length === 2 && h.every((x) => x.kind === "defineProperty") &&
         h.map((x) => x.method).sort().join() === "endsWith,startsWith");

check("alias then mutate",
  `const p = Array.prototype; p.includes = function(){}`,
  one((h) => h.builtin === "Array" && h.method === "includes" && h.kind === "alias"));

check("Object.setPrototypeOf on a prototype",
  `Object.setPrototypeOf(Array.prototype, null)`,
  one((h) => h.kind === "setPrototypeOf"));

check("__proto__ write on a prototype",
  `Array.prototype.__proto__ = {}`,
  one((h) => h.method === "__proto__"));

check("static (non-prototype) global write tracked separately",
  `Array.isArray = function(){ return true }`,
  one((h) => h.target === "static" && h.method === "isArray"));

console.log("\n--- guard classification ---");
check("classic polyfill guard => guarded",
  `if (!Array.prototype.includes) { Array.prototype.includes = function(){} }`,
  one((h) => h.guarded === true));

check("typeof guard => guarded",
  `if (typeof String.prototype.trimStart !== 'function') { String.prototype.trimStart = function(){} }`,
  one((h) => h.guarded === true));

check("logical-or guard => guarded",
  `Array.prototype.includes || (Array.prototype.includes = function(){})`,
  one((h) => h.guarded === true));

check("'in' guard => guarded",
  `if (!('includes' in Array.prototype)) { Array.prototype.includes = function(){} }`,
  one((h) => h.guarded === true));

check("unrelated enclosing if => NOT guarded",
  `if (process.env.NODE_ENV === 'production') { Array.prototype.includes = function(){} }`,
  one((h) => h.guarded === false));

console.log("\n--- must NOT detect (false-positive guards) ---");
check("property READ, not write", `if (x.startsWith('a')) {}`, none);
check("method call on prototype", `Array.prototype.slice.call(args)`, none);
check("string mentioning a prototype", `const s = "Array.prototype.includes = 1"`, none);
check("comment mentioning a prototype", `// Array.prototype.includes = 1\nvar x=1;`, none);
check("user class prototype", `function Foo(){}; Foo.prototype.includes = function(){}`, none);
check("instance property write", `const a = []; a.includes = 1;`, none);
check("assignment to a local named like a member", `obj.prototype.includes = 1`, none);
check("reading defineProperty on non-builtin", `Object.defineProperty(Foo.prototype,'x',{})`, none);
check("defineProperty on a plain object", `Object.defineProperty({}, 'x', {})`, none);

console.log("\n--- shadowing detection (scope-aware) ---");
check("parameter shadowing a builtin => shadowed",
  `function f(Array){ Array.prototype.includes = 1 }`, one((h) => h.shadowed === true));
check("local const shadowing a builtin => shadowed",
  `const Map = require('./map'); Map.prototype.get = 1`, one((h) => h.shadowed === true));
check("genuine global use => NOT shadowed",
  `String.prototype.startsWith = 1`, one((h) => h.shadowed === false));
check("shadowing in a SIBLING scope does not taint the global use",
  `function f(Object){ return Object }\nArray.prototype.includes = function(){}`,
  one((h) => h.shadowed === false));
check("var hoisting inside the same function => shadowed",
  `function f(){ Array.prototype.includes = 1; var Array; }`, one((h) => h.shadowed === true));
check("import binding => shadowed",
  `import Map from 'm'; Map.prototype.get = 1;`, one((h) => h.shadowed === true));

console.log("\n--- import-time vs opt-in ---");
check("top-level assignment => import-time",
  `Array.prototype.includes = function(){}`, one((h) => h.importTime === true));
check("inside an exported function => opt-in, NOT import-time",
  `module.exports = function shim(){ Array.prototype.includes = function(){} }`,
  one((h) => h.importTime === false));
check("once.proto pattern => opt-in",
  `once.proto = once(function(){ Object.defineProperty(Function.prototype,'once',{value:1}) })`,
  one((h) => h.importTime === false));
check("IIFE still counts as import-time",
  `(function(){ Array.prototype.includes = function(){} })()`, one((h) => h.importTime === true));
check("nested inside if at top level => import-time",
  `if (x) { Array.prototype.includes = function(){} }`, one((h) => h.importTime === true));

console.log("\n--- parser coverage ---");
check("CommonJS with top-level return parses",
  `module.exports = 1; Array.prototype.includes = function(){}`,
  one((h) => h.method === "includes"));
check("ESM syntax parses",
  `import x from 'y'; Array.prototype.includes = function(){}; export default x;`,
  one((h) => h.method === "includes"));
check("modern syntax (optional chaining, ??=) parses",
  `const v = a?.b ?? c; Array.prototype.includes = function(){}`,
  one((h) => h.method === "includes"));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
