#!/usr/bin/env node
/**
 * Rooted dependency closure: which packages can the SERVER process reach?
 *
 * Handoff §3. The Exp-1 parsers (lockfiles.js) answer "what is in this lockfile"
 * and "what is production"; they root every traversal at ALL workspaces at once,
 * which is exactly the ambiguity this study has to remove -- it cannot tell a
 * core-js pulled in by `apps/web` from one the server actually loads.
 *
 * Here the traversal is rooted at a CHOSEN subset of workspaces, so the server
 * closure and the client-build closure are computed separately and reported as
 * separate columns (handoff §4: never a merged percent).
 *
 * Two rules matter for correctness:
 *   1. WORKSPACE LINKS ARE FOLLOWED. `apps/server` depending on `workspace:*`
 *      `packages/db` must pull in packages/db's own dependencies, or the closure
 *      stops at the monorepo boundary and undercounts massively. Internal
 *      packages are not npm packages, so they are traversed but never counted.
 *   2. DEV DEPENDENCIES ARE NOT RUNTIME. Only `dependencies` and
 *      `optionalDependencies` propagate; a server's devDependencies are build
 *      tooling, not something the running process loads.
 *
 * This is a static over-approximation of the require graph: a declared runtime
 * dependency may never actually be require()d. It is an UPPER bound on server
 * reach within the declared production closure, and is reported as such.
 * Nothing is executed.
 */
const YAML = require("yaml");

// ---------------------------------------------------------------------------
// pnpm
// ---------------------------------------------------------------------------

/** `/foo@1.2.3(peer@1)` | `foo@1.2.3` -> `foo` */
function pnpmName(key) {
  let k = key.startsWith("/") ? key.slice(1) : key;
  const paren = k.indexOf("(");
  if (paren !== -1) k = k.slice(0, paren);
  const at = k.lastIndexOf("@");
  return at > 0 ? k.slice(0, at) : null;
}

/**
 * @param {string} text        pnpm-lock.yaml contents
 * @param {(dir:string)=>boolean} isRoot  which importer dirs to root at
 */
function pnpmClosure(text, isRoot) {
  const doc = YAML.parse(text, { maxAliasCount: -1 });
  const out = { reached: new Set(), roots: [], unresolved: 0, importersSeen: [] };
  if (!doc || typeof doc !== "object" || !doc.importers) return { ...out, error: "no-importers" };

  const edges = doc.snapshots || doc.packages || {};
  const index = new Map();                       // bare `name@ver` -> real key
  for (const key of Object.keys(edges)) {
    const bare = (key.startsWith("/") ? key.slice(1) : key).split("(")[0];
    if (!index.has(bare)) index.set(bare, key);
  }

  const resolve = (name, version) => {
    let v = String(version);
    if (v.startsWith("npm:")) v = v.slice(4);
    const core = v.split("(")[0];
    const at = core.lastIndexOf("@");
    let real = name, ver = core;
    if (at > 0) { real = core.slice(0, at); ver = core.slice(at + 1); }
    return { real, key: index.get(`${real}@${ver}`) || null };
  };

  const importerQueue = [], seenImporter = new Set();
  const pkgQueue = [], seenPkg = new Set();

  for (const dir of Object.keys(doc.importers)) {
    if (!isRoot(dir === "." ? "" : dir)) continue;
    if (seenImporter.has(dir)) continue;
    seenImporter.add(dir); importerQueue.push(dir); out.roots.push(dir);
  }

  const normImporter = (spec, fromDir) => {
    // `link:../packages/db` relative to the importer's own directory
    const rel = String(spec).replace(/^link:/, "");
    const base = fromDir === "." ? "" : fromDir;
    const joined = base ? `${base}/${rel}` : rel;
    const parts = [];
    for (const seg of joined.split("/")) {
      if (seg === "." || seg === "") continue;
      if (seg === "..") parts.pop(); else parts.push(seg);
    }
    return parts.join("/") || ".";
  };

  while (importerQueue.length) {
    const dir = importerQueue.pop();
    out.importersSeen.push(dir);
    const imp = doc.importers[dir];
    if (!imp) continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, spec] of Object.entries(imp[field] || {})) {
        const v = spec && typeof spec === "object" ? spec.version : spec;
        if (!v) continue;
        const sv = String(v);
        if (/^(link|file):/.test(sv)) {                     // internal workspace package
          const target = normImporter(sv, dir);
          const cand = doc.importers[target] ? target : (doc.importers[`./${target}`] ? `./${target}` : null);
          if (cand && !seenImporter.has(cand)) { seenImporter.add(cand); importerQueue.push(cand); }
          else if (!cand) out.unresolved++;
          continue;
        }
        const { real, key } = resolve(n, sv);
        out.reached.add(real);
        if (key && !seenPkg.has(key)) { seenPkg.add(key); pkgQueue.push(key); }
        else if (!key) out.unresolved++;
      }
    }
  }

  while (pkgQueue.length) {
    const entry = edges[pkgQueue.pop()];
    if (!entry || typeof entry !== "object") continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, v] of Object.entries(entry[field] || {})) {
        if (!v || String(v).startsWith("link:")) continue;
        const { real, key } = resolve(n, v);
        out.reached.add(real);
        if (key && !seenPkg.has(key)) { seenPkg.add(key); pkgQueue.push(key); }
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// npm (lockfileVersion 2/3). v1 carries no dev marking and no workspace paths.
// ---------------------------------------------------------------------------

function npmClosure(text, isRoot) {
  const doc = JSON.parse(text);
  const out = { reached: new Set(), roots: [], unresolved: 0, importersSeen: [] };
  if (!doc.packages) return { ...out, error: "lockfileVersion-1" };

  const pkgs = doc.packages;

  /**
   * Node resolution: from `ctx`, find the entry providing `name` by walking up.
   *
   * The walk must climb ONE PATH SEGMENT at a time. An earlier version jumped
   * straight to the root whenever the path held no `/node_modules/` segment,
   * which silently skipped every intermediate workspace directory: ToolJet's
   * `frontend/package-lock.json` links a sibling `../plugins` tree, so
   * `../plugins/packages/dynamodb` never saw `../plugins/node_modules/...` and
   * 715 genuinely reachable packages went missing.
   */
  const resolveFrom = (ctx, name) => {
    let base = ctx;
    for (;;) {
      const cand = base ? `${base}/node_modules/${name}` : `node_modules/${name}`;
      if (pkgs[cand]) return cand;
      if (!base) return null;
      const cut = base.lastIndexOf("/node_modules/");
      if (cut !== -1) { base = base.slice(0, cut); continue; }
      const slash = base.lastIndexOf("/");
      base = slash === -1 ? "" : base.slice(0, slash);
    }
  };

  const queue = [], seen = new Set();
  for (const key of Object.keys(pkgs)) {
    const isWorkspaceRoot = key === "" || !key.includes("node_modules/");
    if (!isWorkspaceRoot) continue;
    if (!isRoot(key)) continue;
    if (seen.has(key)) continue;
    seen.add(key); queue.push(key); out.roots.push(key || ".");
  }

  while (queue.length) {
    const key = queue.pop();
    out.importersSeen.push(key || ".");
    const meta = pkgs[key];
    if (!meta) continue;
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const name of Object.keys(meta[field] || {})) {
        const target = resolveFrom(key, name);
        if (!target) { out.unresolved++; continue; }
        const t = pkgs[target];
        if (t && t.link && t.resolved) {                     // workspace link
          const ws = t.resolved.replace(/^file:/, "");
          if (pkgs[ws] && !seen.has(ws)) { seen.add(ws); queue.push(ws); }
          continue;
        }
        out.reached.add(name);
        if (!seen.has(target)) { seen.add(target); queue.push(target); }
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// yarn classic (v1)
// ---------------------------------------------------------------------------

/** Index a v1 lockfile: descriptor (`name@range`) -> entry. v1 is not YAML. */
function parseClassicEntries(text) {
  const byDescriptor = new Map();
  let current = null, inDeps = false;
  for (const rawLine of text.split("\n")) {
    const line = rawLine.replace(/\r$/, "");
    if (!line.trim() || line.startsWith("#")) continue;
    if (!/^\s/.test(line)) {
      const key = line.replace(/:\s*$/, "");
      current = { deps: {}, name: null };
      inDeps = false;
      for (const spec of key.split(",").map((x) => x.trim().replace(/^"|"$/g, ""))) {
        if (!spec) continue;
        const at = spec.lastIndexOf("@");
        if (at <= 0) continue;
        current.name = current.name || spec.slice(0, at);
        byDescriptor.set(spec, current);
      }
      continue;
    }
    if (!current) continue;
    const t = line.trim();
    if (/^(dependencies|optionalDependencies):/.test(t)) { inDeps = true; continue; }
    if (/^(version|resolved|integrity|dependenciesMeta|peerDependencies)/.test(t)) {
      if (!/^dependenciesMeta/.test(t)) inDeps = false;
      continue;
    }
    if (inDeps) {
      const m = /^"?([^"\s]+)"?\s+"?([^"]+)"?$/.exec(t);
      if (m) current.deps[m[1]] = m[2];
    }
  }
  return byDescriptor;
}

/**
 * A v1 lockfile contains NO workspace entries -- only resolved npm packages.
 * Roots therefore come from the repository's own manifests, and an internal
 * workspace dependency is recognised by the fact that it fails to resolve in the
 * lockfile while matching a sibling manifest's `name`. Without that name-based
 * link following, a yarn monorepo's server closure stops at its own packages.
 *
 * @param {Array<{dir:string, pkg:object}>} manifests  scoped to this lockfile
 */
function yarnClassicClosure(text, manifests, isRoot) {
  const out = { reached: new Set(), roots: [], unresolved: 0, importersSeen: [], looseResolutions: 0 };
  const byDescriptor = parseClassicEntries(text);
  if (!manifests || !manifests.length) return { ...out, error: "no-manifests" };

  const byName = new Map();                        // workspace packages, by name
  for (const m of manifests) if (m.pkg && m.pkg.name) byName.set(m.pkg.name, m);

  /** Resolved npm entries by name, for the same dedup fallback berry needs. */
  const entryByName = new Map();
  for (const e of byDescriptor.values()) {
    if (e.name && !entryByName.has(e.name)) entryByName.set(e.name, e);
  }

  const manQueue = [], seenMan = new Set();
  for (const m of manifests) {
    const d = m.dir.replace(/\/$/, "");
    if (!isRoot(d)) continue;
    if (seenMan.has(d)) continue;
    seenMan.add(d); manQueue.push(m); out.roots.push(d || ".");
  }

  const pkgQueue = [], seenPkg = new Set();
  const push = (name, range) => {
    let entry = byDescriptor.get(`${name}@${range}`);
    if (!entry) {
      const ws = byName.get(name);                       // internal workspace package
      if (ws) {
        if (!seenMan.has(ws.dir.replace(/\/$/, ""))) {
          seenMan.add(ws.dir.replace(/\/$/, "")); manQueue.push(ws);
        }
        return;
      }
      entry = entryByName.get(name);                     // dedup fallback, see berry note
      if (entry) out.looseResolutions++;
      else { out.unresolved++; return; }
    }
    if (entry.name) out.reached.add(entry.name);
    if (!seenPkg.has(entry)) { seenPkg.add(entry); pkgQueue.push(entry); }
  };

  while (manQueue.length) {
    const m = manQueue.pop();
    out.importersSeen.push(m.dir || ".");
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, r] of Object.entries((m.pkg && m.pkg[field]) || {})) push(n, String(r));
    }
  }
  while (pkgQueue.length) {
    const e = pkgQueue.pop();
    for (const [n, r] of Object.entries(e.deps)) push(n, r);
  }
  return out;
}

// ---------------------------------------------------------------------------
// yarn berry (v2+)
// ---------------------------------------------------------------------------

/** `lodash@npm:4.18.1` -> lodash ; alias `foo@npm:lodash@4.1` -> lodash */
function berryName(resolution, fallback) {
  if (!resolution) return fallback;
  const i = resolution.indexOf("@npm:");
  if (i === -1) {
    const at = resolution.lastIndexOf("@");
    return at > 0 ? resolution.slice(0, at) : fallback;
  }
  const rest = resolution.slice(i + 5);
  const at = rest.lastIndexOf("@");
  if (at > 0) return rest.slice(0, at);
  return resolution.slice(0, i);
}

/** Berry records workspaces explicitly: `resolution: "app@workspace:apps/server"`. */
function berryWorkspaceDir(resolution) {
  const i = (resolution || "").indexOf("@workspace:");
  if (i === -1) return null;
  const d = resolution.slice(i + "@workspace:".length);
  return d === "." ? "" : d;
}

/**
 * NOTE ON A BERRY TRAP: a workspace entry's `dependencies` in yarn.lock is the
 * MERGE of that workspace's dependencies and devDependencies -- verified against
 * actualbudget/actual, whose `packages/api` entry lists `vite` and `vitest`
 * despite those being devDependencies. Expanding workspace entries from the
 * lockfile therefore drags build tooling into the runtime closure. Workspace
 * entries are expanded from their real package.json instead; only non-workspace
 * (resolved npm) entries use lockfile edges, where `dependencies` is genuinely
 * runtime.
 *
 * @param {Array<{dir:string,pkg:object}>} manifests scoped to this lockfile
 */
function yarnBerryClosure(text, isRoot, manifests) {
  const doc = YAML.parse(text, { maxAliasCount: -1 });
  const out = { reached: new Set(), roots: [], unresolved: 0, importersSeen: [],
                unresolvedDescriptors: 0, workspacesWithoutManifest: [], looseResolutions: 0 };
  if (!doc || typeof doc !== "object") return { ...out, error: "unparseable" };

  const byDescriptor = new Map();
  const entries = [];
  for (const [key, val] of Object.entries(doc)) {
    if (key === "__metadata" || !val || typeof val !== "object") continue;
    entries.push(val);
    for (const d of key.split(",").map((x) => x.trim().replace(/^"|"$/g, ""))) {
      if (d) byDescriptor.set(d, val);
    }
  }
  const isWorkspace = (e) => /@workspace:/.test(e.resolution || "");
  const descriptorFor = (name, range) =>
    /^[a-z]+:/.test(range) ? `${name}@${range}` : `${name}@npm:${range}`;

  /**
   * Berry deduplicates: one entry can satisfy several requested ranges but the
   * lockfile records only the winning descriptor. Rocket.Chat requests
   * `undici@npm:^6.23.0` while the file holds only `undici@npm:^6.27.0`, so exact
   * descriptor matching loses 167 real edges. This study asks which package NAMES
   * the server reaches, not which versions, so an exact miss falls back to the
   * name index -- counted separately so the looseness stays visible.
   */
  const byName = new Map();
  for (const e of entries) {
    if (isWorkspace(e)) continue;
    const n = berryName(e.resolution, null);
    if (n && !byName.has(n)) byName.set(n, e);
  }

  const manifestByDir = new Map();
  for (const m of manifests || []) manifestByDir.set((m.dir || "").replace(/\/$/, ""), m.pkg);

  const queue = [], seen = new Set();
  for (const e of entries) {
    if (!isWorkspace(e)) continue;
    const dir = berryWorkspaceDir(e.resolution);
    if (dir === null || !isRoot(dir)) continue;
    if (seen.has(e)) continue;
    seen.add(e); queue.push(e); out.roots.push(dir || ".");
  }

  const push = (name, range) => {
    let entry = byDescriptor.get(descriptorFor(name, String(range)));
    if (!entry) {
      entry = byName.get(name);
      if (entry) out.looseResolutions++;
    }
    if (!entry) { out.unresolved++; out.unresolvedDescriptors++; return; }
    if (!isWorkspace(entry)) {
      const real = berryName(entry.resolution, name);
      if (real) out.reached.add(real);
    }
    if (!seen.has(entry)) { seen.add(entry); queue.push(entry); }
  };

  while (queue.length) {
    const e = queue.pop();
    if (isWorkspace(e)) {
      const dir = berryWorkspaceDir(e.resolution) || "";
      out.importersSeen.push(dir || ".");
      const pkg = manifestByDir.get(dir);
      if (pkg) {                                   // expand from the manifest, not the lockfile
        for (const field of ["dependencies", "optionalDependencies"]) {
          for (const [n, r] of Object.entries(pkg[field] || {})) push(n, r);
        }
      } else {
        out.unresolved++;                          // workspace with no cached manifest
        out.workspacesWithoutManifest.push(dir || ".");
      }
      continue;
    }
    for (const field of ["dependencies", "optionalDependencies"]) {
      for (const [n, r] of Object.entries(e[field] || {})) push(n, r);
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// dispatch
// ---------------------------------------------------------------------------

const isBerry = (text) => /^__metadata:/m.test(text);

/**
 * @param {Array<{dir:string,pkg:object}>} manifests  required for yarn classic,
 *        which has no workspace entries of its own.
 */
function closureFor(lockPath, text, isRoot, manifests) {
  if (/pnpm-lock\.ya?ml$/.test(lockPath)) return pnpmClosure(text, isRoot);
  if (/package-lock\.json$|npm-shrinkwrap\.json$/.test(lockPath)) return npmClosure(text, isRoot);
  if (/yarn\.lock$/.test(lockPath)) {
    return isBerry(text) ? yarnBerryClosure(text, isRoot, manifests) : yarnClassicClosure(text, manifests, isRoot);
  }
  return { reached: new Set(), roots: [], unresolved: 0, importersSeen: [], error: "unsupported-format" };
}

module.exports = { pnpmClosure, npmClosure, yarnClassicClosure, yarnBerryClosure,
                   closureFor, pnpmName, isBerry, berryName, berryWorkspaceDir };
