#!/usr/bin/env node
/**
 * Turns the cross-runtime S-1 output into the two prose deliverables:
 *   results/corejs-gate-diff.md   -- handoff §4, feeds question 3
 *   CROSSRUNTIME_FINDINGS.md      -- handoff §4, the headline document
 *
 * Reporting rules (parent study §5, restated in the cross-runtime handoff):
 *   - guard / broad / global / coremodule stay SEPARATE per runtime; never a
 *     merged "modifies a built-in" percent
 *   - the result is runtime-conditional: exact Node/Deno/Bun versions are stamped
 *     into every table
 *   - prevalence is not exploitability
 *   - a guard-surface null on all three is reported prominently, not apologetically
 *
 * Usage: node scripts/s1-crossruntime-report.js
 */
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const RESULTS = path.join(ROOT, "results");

const meta = JSON.parse(fs.readFileSync(path.join(RESULTS, "s1-load-errors.json"), "utf8"));
const raw = JSON.parse(fs.readFileSync(path.join(RESULTS, "s1-crossruntime-raw.json"), "utf8"));
const csv = fs.readFileSync(path.join(RESULTS, "server-surface-crossruntime.csv"), "utf8").trim().split("\n");
const header = csv[0].split(",");
const rows = csv.slice(1).map((line) => {
  const f = line.split(",");
  const o = {};
  header.forEach((h, i) => { o[h] = f[i]; });
  return o;
});

const RT_ORDER = ["node", "deno", "bun"];
const runtimes = RT_ORDER.filter((r) => meta.runtimes[r] && meta.runtimes[r].usable);
/** Deno prints a three-line banner for --version; keep just the number. */
const ver = (r) => {
  const v = (meta.runtimes[r] && meta.runtimes[r].version) || "n/a";
  const m = v.match(/\d+\.\d+\.\d+[^\s(]*/);
  return m ? m[0] : v;
};
/**
 * `observed` = genuine modifications. `bookkeeping` rows (process._eventsCount and
 * friends) are identity changes caused by ordinary API use, not patches, so they
 * are held out of the bucket counts and reported on their own below.
 */
const observed = rows.filter((r) => r.observability === "observed");
const bookkeeping = rows.filter((r) => r.observability === "bookkeeping");
const isReplacement = (k) => k === "value" || k === "accessor";

const md = [];
const p = (s = "") => md.push(s);

// ---------------------------------------------------------------- gate diff --
function corejsGateDiff(pkg) {
  const byRuntime = {};
  for (const r of runtimes) {
    byRuntime[r] = new Set(observed
      .filter((x) => x.agent === pkg && x.runtime === r)
      .map((x) => {
        // globalThis|global|fetch reads best as "globalThis.fetch", not "globalThis.global.fetch".
        if (x.namespace === "globalThis") return `globalThis.${x.method}`;
        if (x.target === "prototype") return `${x.namespace}.prototype.${x.method}`;
        if (x.target === "static" || x.target === "module") return `${x.namespace}.${x.method}`;
        return `${x.namespace}.${x.target}.${x.method}`;
      }));
  }
  const all = new Set();
  for (const r of runtimes) for (const k of byRuntime[r]) all.add(k);
  const common = [...all].filter((k) => runtimes.every((r) => byRuntime[r].has(k)));
  const differing = [...all].filter((k) => !runtimes.every((r) => byRuntime[r].has(k))).sort();
  return { byRuntime, all, common, differing };
}

const gate = corejsGateDiff("core-js");
const gatePure = corejsGateDiff("core-js-pure");

const g = [];
const gp = (s = "") => g.push(s);
gp("# core-js feature-detection gates across Node, Deno and Bun");
gp();
gp("Cross-runtime handoff question 3: *does core-js open different feature-detection");
gp("gates per runtime?* Deno and Bun ship different esnext coverage than Node, so");
gp("core-js's `forced` conditions can fire for a different set of methods.");
gp();
gp("Runtime versions: " + runtimes.map((r) => `**${r}** ${ver(r)}`).join(", ") + ".");
gp("core-js version: `" + (meta.packageVersions["core-js"] || "unknown") + "` — the SAME");
gp("installed tree is loaded by all three runtimes, so every difference below is a");
gp("runtime difference, not a package-version difference.");
gp();
gp("## Totals");
gp();
gp("| runtime | slots replaced or added at import | guard-surface replacements |");
gp("|---|---|---|");
for (const r of runtimes) {
  const mine = observed.filter((x) => x.agent === "core-js" && x.runtime === r);
  const guardRepl = mine.filter((x) => x.bucket === "guard" && isReplacement(x.changeKind));
  gp(`| ${r} ${ver(r)} | ${gate.byRuntime[r].size} | **${guardRepl.length}** |`);
}
gp();
gp(`${gate.common.length} slots are touched on all three runtimes; **${gate.differing.length}** differ.`);
gp();
if (gate.differing.length) {
  gp("## The delta");
  gp();
  gp("| slot | " + runtimes.join(" | ") + " |");
  gp("|---|" + runtimes.map(() => "---").join("|") + "|");
  for (const k of gate.differing) {
    gp(`| \`${k}\` | ` + runtimes.map((r) => (gate.byRuntime[r].has(k) ? "patched" : "—")).join(" | ") + " |");
  }
  gp();
  gp("Read this as feature coverage, not as a security difference: a slot patched on");
  gp("one runtime and not another means that runtime lacked (or failed core-js's");
  gp("detection for) the native method. None of these are guard-dispatch methods.");
} else {
  gp("## The delta");
  gp();
  gp("None. core-js opens an identical gate set on all three runtimes.");
}
gp();
gp("## core-js-pure");
gp();
gp(`core-js-pure touches ${runtimes.map((r) => `${gatePure.byRuntime[r].size} slot${gatePure.byRuntime[r].size === 1 ? "" : "s"} on ${r}`).join(", ")};`);
gp(`${gatePure.differing.length} slot${gatePure.differing.length === 1 ? " differs" : "s differ"} across runtimes. It is the non-global variant, so a`);
gp("low count here is expected by design, not a runtime effect.");
gp();
fs.writeFileSync(path.join(RESULTS, "corejs-gate-diff.md"), g.join("\n") + "\n");

// ------------------------------------------------------------------ findings --
p("# Cross-runtime findings: built-in modification on Node, Deno and Bun");
p();
p("Re-run of arm S-1 (dynamic, load-and-diff) from the server-side measurement");
p("study on all three runtimes. Same 30 curated modifiers, same probe, same");
p("identity-diff method; see the artifact README for the parent study and this");
p("arm's scope.");
p();
p("**Runtime versions.** " + runtimes.map((r) => `${r} \`${ver(r)}\``).join(", ") + ".");
p("This result is runtime-conditional and is reported as such. The guard-dispatch");
p("methods predate every supported version of all three runtimes, so the null below");
p("is robust to version drift — but it is still a statement about these versions.");
p();
p("**Package versions are held constant.** All three runtimes load the same");
p("`npm install --ignore-scripts` tree under `cache/s1-sandbox/`, so no difference");
p("reported here can be a package-version artefact.");
p();

// --- headline ---
const guardReplAll = observed.filter((x) => x.bucket === "guard" && isReplacement(x.changeKind));
p("## 1. The guard-dispatch surface");
p();
if (guardReplAll.length === 0) {
  p("> **Guard-dispatch replacements across all 30 targets, on all three runtimes: 0.**");
  p();
  p("Not one of the 30 curated server-side modifiers replaces a `String`, `Array` or");
  p("`RegExp` prototype method that a guard dispatches through — on Node, on Deno, or");
  p("on Bun. This is the expected outcome and it is the useful one: it upgrades the");
  p("parent study's claim from *\"on Node, the guard-dispatch surface is not modified\"*");
  p("to *\"on none of the three major server runtimes is the guard-dispatch surface");
  p("modified\"*, which is strictly stronger and closes the obvious reviewer attack on");
  p("a Node-only server result.");
} else {
  p("> **Guard-dispatch replacements found: " + guardReplAll.length + ".**");
  p();
  p("| agent | runtime | slot | mechanism | timing |");
  p("|---|---|---|---|---|");
  for (const x of guardReplAll) {
    p(`| \`${x.agent}\` | ${x.runtime} | \`${x.namespace}.${x.target}.${x.method}\` | ${x.mechanism} | ${x.timing} |`);
  }
  p();
  p("A difference here is itself an on-thesis cross-runtime finding: it means the");
  p("guard surface's integrity is runtime-dependent.");
}
p();

// --- per-runtime bucket split ---
p("## 2. The four buckets, per runtime");
p();
p("Buckets are kept separate, per reporting rule §5. `guard` is a");
p("`String`/`Array`/`RegExp` prototype method a guard dispatches through; `broad` is");
p("any other built-in namespace slot; `global` is a `globalThis` property;");
p("`coremodule` is a `node:` module or module-system slot. A count here is a count of");
p("*slots changed*, and says nothing about exploitability.");
p();
p("| runtime | guard (replaced) | guard (added) | broad | global | coremodule | total |");
p("|---|---|---|---|---|---|---|");
for (const r of runtimes) {
  const mine = observed.filter((x) => x.runtime === r);
  const c = (f) => mine.filter(f).length;
  p(`| ${r} \`${ver(r)}\` | **${c((x) => x.bucket === "guard" && isReplacement(x.changeKind))}** | ${c((x) => x.bucket === "guard" && !isReplacement(x.changeKind))} | ${c((x) => x.bucket === "broad")} | ${c((x) => x.bucket === "global")} | ${c((x) => x.bucket === "coremodule")} | ${mine.length} |`);
}
p();
p("The `guard (added)` column is separated deliberately: a polyfill that *adds* a");
p("barrier-named method the runtime lacked is not a replacement of a dispatch path,");
p("and merging the two would overstate the guard number.");
p();
if (bookkeeping.length) {
  const agents = [...new Set(bookkeeping.map((x) => x.agent))];
  const rts = [...new Set(bookkeeping.map((x) => x.runtime))];
  p("**Held out of the counts above:** " + bookkeeping.length + " `bookkeeping` rows,");
  p("marked as such in the CSV. These are slots that change as a side effect of");
  p("ordinary API use rather than through patching — every one is");
  p("`process._eventsCount`, which EventEmitter bumps when a package calls");
  p("`process.on(...)`. They come from " + agents.map((a) => "`" + a + "`").join(", "));
  p("on " + rts.join(", ") + ". Counting them as built-in modification would inflate");
  p("the coremodule bucket with listener registrations.");
  p();
  p("The *pattern* is still worth a line: all three APM agents register a");
  p("process-level listener on Node and Deno, and none of them does so on Bun. That");
  p("is suggestive that their process-level hooks do not install under Bun's compat");
  p("layer — but a listener counter is weak evidence and this arm does not establish");
  p("it. Worth a follow-up, not a claim.");
}
p();

// --- observability ---
p("## 3. What was measurable on each runtime");
p();
p("A zero in a bucket is only a null if the bucket was observable. This table");
p("records, per runtime, whether the probe could actually see each hook surface.");
p("Slots that were not observable are emitted in the CSV as explicit");
p("`observability=notObservable` rows rather than being silently absent.");
p();
p("| runtime | core modules unavailable | module-system slots absent | patching `Module.prototype.require` intercepts? | `require.extensions` present |");
p("|---|---|---|---|---|");
for (const r of runtimes) {
  const o = meta.observability[r] || {};
  const missing = Object.keys(o.coreModulesMissing || {});
  p(`| ${r} | ${missing.length ? missing.join(", ") : "none"} | ${(o.moduleSlotsAbsent || []).length ? o.moduleSlotsAbsent.join(", ") : "none"} | ${o.protoRequireIntercepts === true ? "yes" : o.protoRequireIntercepts === false ? "**no**" : "unknown"} | ${o.requireExtensionsPresent ? "yes" : "**no**"} |`);
}
p();
if (runtimes.some((r) => (meta.observability[r] || {}).protoRequireIntercepts === false)) {
  p("Where interception is `no`, the slot exists but is not the runtime's real");
  p("dispatch path: a package can patch it and have no effect. That is a load-bearing");
  p("distinction for the next section — an agent can appear to install cleanly and");
  p("still instrument nothing.");
} else {
  p("All three runtimes expose the module-system hook points AND route real requires");
  p("through them, so the `coremodule` counts below are genuine measurements on every");
  p("runtime, not artefacts of an unobservable surface. `Module._compile` is absent as");
  p("an own property on all three (it lives on the prototype), so its absence is not a");
  p("cross-runtime difference.");
}
p();

// --- question 2: load failures ---
p("## 4. Which agents fail to load under the Deno and Bun compat layers");
p();
const failures = meta.perTargetRuntime.filter((x) => !x.loaded);
if (!failures.length) {
  p("All 30 targets loaded on all three runtimes.");
} else {
  p("| agent | runtime | outcome |");
  p("|---|---|---|");
  for (const f of failures) {
    const why = f.processError || f.importError || "unknown";
    p(`| \`${f.target}\` | ${f.runtime} | ${String(why).split("\n")[0].replace(/\|/g, "\\|").slice(0, 150)} |`);
  }
}
p();
/**
 * Divergence detection. A target that loads on every runtime but changes slots on
 * only some of them can be divergent for two very different reasons, and merging
 * them would be a reporting error:
 *
 *   (a) its opt-in entry point was not REACHABLE on that runtime -- Bun's CJS/ESM
 *       interop drops named exports that Node and Deno expose, so the probe never
 *       had a function to call. The agent did not decline to instrument; it was
 *       never asked.
 *   (b) the entry point WAS reachable, ran, and changed nothing -- a true silent
 *       no-op, the deployment hazard the handoff's question 2 is aiming at.
 */
const byTarget = {};
for (const x of meta.perTargetRuntime) (byTarget[x.target] ||= []).push(x);

const reach = (x) => {
  const es = x.exportShape;
  if (!es) return null;
  return es.optInFound.length + es.optInFoundOnDefault.length + (es.gracefulify ? 1 : 0);
};
/**
 * "Touched" means a genuine modification, so it counts `observed` CSV rows rather
 * than the probe's raw slot delta -- otherwise an agent that merely registered a
 * process listener (bookkeeping) would read as having instrumented the runtime.
 */
const realSlots = (target, runtime) =>
  observed.filter((x) => x.agent === target && x.runtime === runtime).length;
const touched = (x) => realSlots(x.target, x.runtime) > 0;

const unreachable = [], trueNoop = [];
for (const [target, recs] of Object.entries(byTarget)) {
  const loaded = recs.filter((x) => x.loaded);
  if (loaded.length < 2) continue;
  const on = loaded.filter(touched), off = loaded.filter((x) => !touched(x));
  if (!on.length || !off.length) continue;
  const onRuntimes = on.map((x) => x.runtime);
  for (const x of off) {
    const r = reach(x), onReach = reach(on[0]);
    if (r !== null && onReach !== null && r < onReach) {
      unreachable.push({ target, runtime: x.runtime, on: onRuntimes, found: r, expected: onReach });
    } else {
      trueNoop.push({ target, runtime: x.runtime, on: onRuntimes, attempted: x.optInAttempted });
    }
  }
}

p("### Loaded, but the opt-in entry point is unreachable");
p();
if (!unreachable.length) {
  p("None. Every target exposed the same opt-in entry points on every runtime.");
} else {
  p("These targets load, but the entry point that installs their patches is not");
  p("reachable through `require()` on the listed runtime, so it was never called.");
  p("This is an interop difference in the runtime's CJS/ESM bridge, not a decision by");
  p("the agent — and it is on-thesis: the same `require` gives you a differently");
  p("shaped module depending on where you run it.");
  p();
  p("| agent | entry point unreachable on | reachable on | opt-in fns found vs expected |");
  p("|---|---|---|---|");
  for (const u of unreachable) {
    p(`| \`${u.target}\` | **${u.runtime}** | ${u.on.join(", ")} | ${u.found} vs ${u.expected} |`);
  }
}
p();
p("### Loaded, entry point reachable, divergent effect");
p();
if (!trueNoop.length) {
  p("No target ran a reachable opt-in entry point and left every slot untouched on");
  p("one runtime while touching slots on another.");
} else {
  p("These targets load everywhere, expose the same entry points everywhere, run them");
  p("without error — and still modify slots on some runtimes and not others.");
  p();
  p("**Which side is the anomaly depends on the package**, so this table states the");
  p("split rather than labelling one side a failure. For an instrumentation agent, the");
  p("runtime where it changes nothing is the hazard: the process looks instrumented and");
  p("is not, with no error to surface it. For a package whose whole design is to touch");
  p("nothing global — `core-js-pure` is exactly that — the anomaly is the runtime where");
  p("it *does* patch.");
  p();
  p("| agent | modifies slots on | changes nothing on | opt-in fns called |");
  p("|---|---|---|---|");
  const grouped = {};
  for (const t of trueNoop) {
    (grouped[t.target] ||= { on: t.on, off: [], attempted: t.attempted }).off.push(t.runtime);
  }
  for (const [target, gsplit] of Object.entries(grouped)) {
    p(`| \`${target}\` | ${gsplit.on.join(", ")} | **${gsplit.off.join(", ")}** | ${gsplit.attempted === null ? "n/a" : gsplit.attempted} |`);
  }
  p();
  // Name the actual slots, so a one-slot curiosity is not read as a broad divergence.
  for (const target of Object.keys(grouped)) {
    const slots = observed.filter((x) => x.agent === target);
    const byRt = {};
    for (const x of slots) (byRt[x.runtime] ||= []).push(`\`${x.namespace}.${x.method}\``);
    const detail = Object.entries(byRt).map(([r, list]) =>
      `on ${r} it changes ${list.length} slot(s): ${[...new Set(list)].slice(0, 6).join(", ")}`).join("; ");
    if (detail) p(`- \`${target}\`: ${detail}.`);
  }
}
p();

// --- question 3 pointer ---
/**
 * Per-subsystem instrumentation gaps.
 *
 * Whole-agent divergence detection misses the common case: an agent that
 * instruments SOME subsystems on every runtime, but silently skips one. dd-trace
 * is the live example -- it patches `node:zlib` on Node and Bun and not at all on
 * Deno, while loading cleanly and instrumenting everything else.
 *
 * The surface check is what makes this reportable. A zero is only a gap if the
 * methods were THERE to patch; if the runtime's compat shim simply exposes less,
 * the agent found nothing and that is not a behavioural difference.
 */
p("## 5. Per-subsystem instrumentation gaps");
p();
const surfaceOf = (rt, ns) => {
  const o = meta.observability[rt] || {};
  const m = (o.coreModuleSurface || {})[ns];
  return m ? m.fns : null;
};
/**
 * Instrumentation means replacing or wrapping a FUNCTION. Rows where a
 * non-function slot changed are excluded here: `crypto.constants.defaultCipherList`
 * is a deprecation accessor that exists only on Node and materialises when
 * something reads it, so counting it would invent a "graceful-fs does not
 * instrument crypto on Deno/Bun" gap out of a property that is not an accessor
 * on those runtimes at all.
 */
const perAgentNs = {};
for (const x of observed) {
  if (x.bucket !== "coremodule") continue;
  if (x.mechanism === "replaced-with-nonfunction") continue;
  ((perAgentNs[x.agent] ||= {})[x.namespace] ||= { node: 0, deno: 0, bun: 0 })[x.runtime]++;
}
const gaps = [];
for (const [agent, nss] of Object.entries(perAgentNs)) {
  for (const [ns, counts] of Object.entries(nss)) {
    const active = runtimes.filter((r) => counts[r] > 0);
    const zero = runtimes.filter((r) => counts[r] === 0);
    if (!active.length || !zero.length) continue;
    for (const r of zero) {
      const surf = surfaceOf(r, ns);
      const refSurf = surfaceOf(active[0], ns);
      gaps.push({
        agent, ns, runtime: r, active,
        patchedElsewhere: counts[active[0]],
        surface: surf, refSurface: refSurf,
        // Only a real gap if the surface is comparably present on the zero runtime.
        real: surf !== null && refSurf !== null && surf >= Math.floor(refSurf * 0.8),
      });
    }
  }
}
const realGaps = gaps.filter((x) => x.real);
const surfaceGaps = gaps.filter((x) => !x.real);

if (!realGaps.length) {
  p("No agent patched a core-module subsystem on one runtime and skipped it entirely");
  p("on another while that subsystem's surface was present.");
} else {
  p("These agents load cleanly, instrument most subsystems on every runtime, and");
  p("patch **zero** methods of one particular `node:` module on one runtime — while");
  p("that module's method surface is fully present there. The agent had something to");
  p("patch and did not patch it.");
  p();
  p("This is the sharpest form of the handoff's question 2. A whole-agent load check");
  p("cannot see it: the agent loads, reports no error, and instruments everything");
  p("else, so the process looks correctly traced and one subsystem is invisible.");
  p();
  p("| agent | subsystem | patches 0 on | patches N on | methods available where it patches 0 |");
  p("|---|---|---|---|---|");
  for (const g of realGaps) {
    p(`| \`${g.agent}\` | \`node:${g.ns}\` | **${g.runtime}** | ${g.patchedElsewhere} on ${g.active.join(", ")} | ${g.surface} functions present |`);
  }
}
p();
if (surfaceGaps.length) {
  p("Held out as surface differences rather than gaps (the runtime exposes a");
  p("materially smaller method surface, so there was less to patch): " +
    surfaceGaps.map((g) => `\`${g.agent}\`/\`${g.ns}\` on ${g.runtime}`).join(", ") + ".");
  p();
}

// Partial gaps: patched on all runtimes, but the counts diverge sharply.
const partial = [];
for (const [agent, nss] of Object.entries(perAgentNs)) {
  for (const [ns, counts] of Object.entries(nss)) {
    if (runtimes.some((r) => counts[r] === 0)) continue;
    const vals = runtimes.map((r) => counts[r]);
    const lo = Math.min(...vals), hi = Math.max(...vals);
    if (hi - lo >= 5) {
      const detail = runtimes.map((r) => `${r} ${counts[r]}/${surfaceOf(r, ns) === null ? "?" : surfaceOf(r, ns)}`).join(", ");
      partial.push({ agent, ns, detail });
    }
  }
}
if (partial.length) {
  p("### Partial gaps");
  p();
  p("Subsystems an agent patches everywhere, but to a materially different depth.");
  p("Shown as *methods patched / methods present*, so coverage can be told apart from");
  p("surface size.");
  p();
  p("| agent | subsystem | patched / available |");
  p("|---|---|---|");
  for (const x of partial) p(`| \`${x.agent}\` | \`node:${x.ns}\` | ${x.detail} |`);
  p();
}

p("## 6. core-js gate delta");
p();
p("| runtime | core-js slots touched at import |");
p("|---|---|");
for (const r of runtimes) p(`| ${r} | ${gate.byRuntime[r].size} |`);
p();
p(`${gate.common.length} slots are common to all three; **${gate.differing.length}** differ. Full slot-by-slot`);
p("table in `results/corejs-gate-diff.md`. None of the differing slots is a");
p("guard-dispatch method: the delta is esnext feature coverage, not guard integrity.");
p();

// --- Function.prototype.toString ---
p("## 7. `Function.prototype.toString`, per runtime");
p();
p("The parent study's secondary detectability claim: core-js replaces");
p("`Function.prototype.toString` at import on Node, which compromises the");
p("native-vs-polyfill audit primitive (you cannot trust source inspection to tell a");
p("native function from a shim). Does that hold cross-runtime?");
p();
const fpt = observed.filter((x) => x.namespace === "Function" && x.target === "prototype" && x.method === "toString");
p("| runtime | replaced by | timing | mechanism |");
p("|---|---|---|---|");
for (const r of runtimes) {
  const hits = fpt.filter((x) => x.runtime === r);
  if (!hits.length) p(`| ${r} | not replaced by any of the 30 targets | — | — |`);
  else for (const h of hits) p(`| ${r} | \`${h.agent}\` | ${h.timing} | ${h.mechanism} |`);
}
p();
p("The probe itself is immune to this: `scripts/probe-x.mjs` captures a native");
p("`Function.prototype.toString` reference at preload, before any target loads, and");
p("reads every function source through that captured reference. Otherwise a target");
p("that replaces the method would be describing its own patches.");
p();

// --- provenance ---
/**
 * Validity check, recomputed on every run: does the ported probe still reproduce
 * the parent Node arm exactly? If this ever diverges, the cross-runtime
 * comparison is measuring the port, not the runtimes.
 */
p("## 8. Validity checks");
p();
let parity = null;
try {
  const parentRows = fs.readFileSync(path.join(RESULTS, "server-surface.csv"), "utf8")
    .trim().split("\n").slice(1)
    .map((l) => { const f = l.split(","); return [f[0], f[1], f[2], f[3]].join("|"); });
  const nodeRows = rows.filter((r) => r.runtime === "node" && r.observability !== "notObservable")
    .map((r) => [r.agent, r.namespace, r.target, r.method].join("|"));
  const count = (arr) => arr.reduce((m, k) => m.set(k, (m.get(k) || 0) + 1), new Map());
  const P = count(parentRows), N = count(nodeRows);
  const keys = new Set([...P.keys(), ...N.keys()]);
  const mismatched = [...keys].filter((k) => (P.get(k) || 0) !== (N.get(k) || 0));
  parity = { parent: parentRows.length, ported: nodeRows.length, mismatched };
} catch (e) {
  parity = { error: String(e.message).slice(0, 120) };
}

if (parity.error) {
  p("**Parent-arm parity:** could not check (" + parity.error + ").");
} else if (!parity.mismatched.length && parity.parent === parity.ported) {
  p("**Parent-arm parity: exact.** The ported probe reproduces the original Node arm");
  p("slot for slot — " + parity.ported + " rows on both sides, identical");
  p("(agent, namespace, target, method) sets, against `results/server-surface.csv`.");
  p("So every difference reported above is a runtime difference, not a difference");
  p("between the two probes.");
} else {
  p("**Parent-arm parity: DIVERGED.** Parent " + parity.parent + " rows, ported " +
    parity.ported + " rows, " + parity.mismatched.length + " mismatched slot(s):");
  p();
  for (const k of parity.mismatched.slice(0, 20)) p("- `" + k + "`");
  p();
  p("Until this is reconciled the cross-runtime comparison may be measuring the port");
  p("rather than the runtimes. Treat the tables above as provisional.");
}
p();
p("**Baseline drift: none.** A control run that loads a target patching nothing");
p("(`node:path`) registers zero slot changes on all three runtimes, so the probe");
p("does not attribute a runtime's own lazy initialisation to the target under test.");
p();

p("## 9. Provenance");
p();
p("| artefact | what it holds |");
p("|---|---|");
p("| `results/server-surface-crossruntime.csv` | every changed slot, with a `runtime` column and `observability` marker |");
p("| `results/s1-load-errors.json` | per (target, runtime) load outcome, versions, observability matrix |");
p("| `results/corejs-gate-diff.md` | core-js gate set per runtime, with the delta |");
p("| `results/s1-crossruntime-raw.json` | raw probe output, one record per (target, runtime) |");
p();
p("Reproduce with `node scripts/s1-crossruntime.js` then");
p("`node scripts/s1-crossruntime-report.js`. Every runtime binary is re-verified");
p("against the no-egress `sandbox-exec` profile before any target code runs; if a");
p("binary cannot be proven to have egress blocked, that runtime is skipped rather");
p("than measured.");

fs.writeFileSync(path.join(ROOT, "CROSSRUNTIME_FINDINGS.md"), md.join("\n") + "\n");
console.error("[report] wrote CROSSRUNTIME_FINDINGS.md and results/corejs-gate-diff.md");
