#!/usr/bin/env node
/**
 * Read-only accessor for the Exp-1/2 repository file cache.
 *
 * `cache/repo-files/` is a symlink to the prior experiment's fetch artifact
 * (regenerable from GitHub by ../supply-chain-monkey-patch/scripts/scan-applications.js);
 * it is NOT a source input to this study. Files are keyed
 *   <owner>+<repo>__<path with / replaced by ~>
 * and cover every package.json and lockfile of all 173 analysed applications.
 */
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");
const FILES = path.join(ROOT, "cache", "repo-files");
/** Manifests the Exp-1 fetch truncated away (MAX_MANIFESTS=60); see fetch-missing-manifests.js. */
const EXTRA = path.join(ROOT, "cache", "repo-files-extra");
const SOURCES = [FILES, EXTRA];

const keyFor = (repo, p) => `${repo.replace("/", "+")}__${p.replace(/\//g, "~")}`;

function readRepoFile(repo, p) {
  for (const dir of SOURCES) {
    const f = path.join(dir, keyFor(repo, p));
    if (fs.existsSync(f)) return fs.readFileSync(f, "utf8");
  }
  return null;
}

/** Every cached path for a repository, decoded back to real repo-relative paths. */
function listRepoPaths(repo) {
  const prefix = `${repo.replace("/", "+")}__`;
  const out = new Set();
  for (const dir of SOURCES) {
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir)) {
      if (f.startsWith(prefix)) out.add(f.slice(prefix.length).replace(/~/g, "/"));
    }
  }
  return [...out];
}

/** All manifests of a repository, parsed. Unparseable ones are reported, not dropped silently. */
function manifests(repo) {
  const out = [], bad = [];
  for (const p of listRepoPaths(repo)) {
    if (!/(^|\/)package\.json$/.test(p)) continue;
    const text = readRepoFile(repo, p);
    if (text === null) continue;
    try { out.push({ path: p, dir: p.replace(/(^|\/)package\.json$/, "") || "", pkg: JSON.parse(text) }); }
    catch (e) { bad.push({ path: p, error: e.message }); }
  }
  return { manifests: out, unparseable: bad };
}

function population() {
  const d = JSON.parse(fs.readFileSync(path.join(ROOT, "cache", "app-scan.json"), "utf8"));
  return d.applications.filter((a) => a.status === "ok");
}

module.exports = { readRepoFile, listRepoPaths, manifests, population, keyFor, FILES, EXTRA };
