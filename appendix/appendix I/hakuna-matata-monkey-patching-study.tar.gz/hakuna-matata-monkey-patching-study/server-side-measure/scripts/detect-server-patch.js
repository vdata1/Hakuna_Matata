#!/usr/bin/env node
/**
 * Server-mechanism detectors: the shapes scan-monkeypatch.js cannot see.
 *
 * Handoff §2 is explicit that a detector tuned only for `String.prototype.m = ...`
 * reads the ecosystem's biggest SERVER modifiers as zero. Server-side modification
 * is mostly require-hook / `shimmer` wrapping plus core-module and global patching,
 * none of which touches a builtin prototype syntactically.
 *
 * This EXTENDS the Exp-1 detector rather than reimplementing it (handoff §8): the
 * builtin prototype/static shapes still come from `scanSource`, which is reused
 * unmodified, as are `parse`, `classifyRHS` and `isGuarded`'s RHS vocabulary. Kept
 * in a sibling module for the same reason `detectHelperProtoDefine` is kept apart
 * -- Exp-1's syntactic numbers must remain reproducible untouched.
 *
 * Buckets follow handoff §4 and are NEVER merged:
 *   coremodule   -- fs/http/... methods reached through a required core module
 *   global       -- writes to `global.*` / `globalThis.*`
 *   require-hook -- interception of module loading itself
 *   wrap-helper  -- shimmer / wrap(obj, 'method', fn)
 * Builtin prototype/static hits stay with scanSource and are not duplicated here.
 *
 * Scanning only. No package code is ever executed.
 */
const walk = require("acorn-walk");
const { classifyRHS, bindingsOf, BUILTINS } = require("./scan-monkeypatch.js");

/** Node types that introduce a scope; mirrors scan-monkeypatch.js. */
const SCOPE_TYPES = new Set([
  "Program", "FunctionDeclaration", "FunctionExpression", "ArrowFunctionExpression",
  "BlockStatement", "ForStatement", "ForInStatement", "ForOfStatement", "CatchClause",
]);

/** Innermost enclosing scope node for a position in the ancestor chain. */
function innermostScope(ancestors) {
  for (let i = ancestors.length - 1; i >= 0; i--) {
    if (SCOPE_TYPES.has(ancestors[i].type)) return ancestors[i];
  }
  return null;
}

/** The scope that actually provides `name` at this position, or null. */
function bindingScope(name, ancestors) {
  for (let i = ancestors.length - 1; i >= 0; i--) {
    const a = ancestors[i];
    if (SCOPE_TYPES.has(a.type) && bindingsOf(a).has(name)) return a;
  }
  return null;
}

/**
 * Globals that already exist. Writing one is a MODIFICATION; writing any other
 * name merely DEFINES a new global, which is what every UMD wrapper does
 * (`global.acorn = {}`). Conflating the two put `acorn`, `async` and the
 * `@jridgewell/*` packages among the top "global modifiers" at ~50% of servers,
 * which is a packaging convention, not builtin modification.
 */
const BUILTIN_GLOBALS = new Set([
  "setTimeout", "setInterval", "setImmediate", "clearTimeout", "clearInterval",
  "clearImmediate", "queueMicrotask", "structuredClone", "fetch", "Headers",
  "Request", "Response", "URL", "URLSearchParams", "AbortController", "AbortSignal",
  "TextEncoder", "TextDecoder", "Buffer", "process", "console", "crypto",
  "performance", "atob", "btoa", "Promise", "Error", "JSON", "Math", "Reflect",
  "Proxy", "WeakRef", "FinalizationRegistry", "Object", "Array", "String", "Number",
  "Boolean", "Function", "RegExp", "Date", "Map", "Set", "WeakMap", "WeakSet",
  "Symbol", "BigInt", "globalThis", "global", "require", "Intl", "Event",
  "EventTarget", "MessageChannel", "MessagePort", "Blob", "File", "FormData",
  "ReadableStream", "WritableStream", "TransformStream", "WebSocket", "navigator",
]);

/** Node core modules whose methods are worth tracking (handoff §3 bucket 3). */
const CORE_MODULES = new Set([
  "fs", "fs/promises", "http", "https", "http2", "net", "tls", "dns", "dgram",
  "child_process", "cluster", "crypto", "zlib", "stream", "os", "path", "url",
  "querystring", "util", "vm", "worker_threads", "perf_hooks", "async_hooks",
  "timers", "timers/promises", "module", "process", "readline", "events", "buffer",
]);

/** Packages whose mere presence means module loading is being intercepted. */
const HOOK_PACKAGES = new Set([
  "shimmer", "require-in-the-middle", "import-in-the-middle", "module-details-from-path",
]);

const isIdent = (n) => n && n.type === "Identifier";
const strOf = (n) => (n && n.type === "Literal" && typeof n.value === "string" ? n.value : null);
const norm = (m) => (m && m.startsWith("node:") ? m.slice(5) : m);

/** `require('x')` -> 'x' (also `require('node:x')`). */
function requireArg(node) {
  if (!node || node.type !== "CallExpression") return null;
  if (!isIdent(node.callee) || node.callee.name !== "require") return null;
  return norm(strOf(node.arguments[0]));
}

/**
 * Local bindings for core modules and for hook packages, from both CommonJS and
 * ESM. Needed because `fs.readFile = ...` is only meaningful once we know `fs`
 * came from `require('fs')` and is not some unrelated local object.
 */
function moduleBindings(ast) {
  const core = new Map();     // local name -> core module
  const hooks = new Map();    // local name -> hook package
  const named = new Map();    // local name -> {pkg, imported}  e.g. { wrap } = shimmer
  const declaredIn = new Map(); // local name -> the scope node that declares it

  walk.ancestor(ast, {
    VariableDeclarator(node, _state, ancestors) {
      const mod = requireArg(node.init);
      if (!mod) return;
      const scope = innermostScope(ancestors);
      if (isIdent(node.id)) {
        if (CORE_MODULES.has(mod)) { core.set(node.id.name, mod); declaredIn.set(node.id.name, scope); }
        if (HOOK_PACKAGES.has(mod)) { hooks.set(node.id.name, mod); declaredIn.set(node.id.name, scope); }
        return;
      }
      if (node.id.type === "ObjectPattern") {           // const { wrap } = require('shimmer')
        for (const p of node.id.properties) {
          if (p.type !== "Property" || !isIdent(p.value)) continue;
          const key = isIdent(p.key) ? p.key.name : strOf(p.key);
          if (!key) continue;
          if (HOOK_PACKAGES.has(mod)) named.set(p.value.name, { pkg: mod, imported: key });
          if (CORE_MODULES.has(mod)) named.set(p.value.name, { pkg: mod, imported: key });
        }
      }
    },
    ImportDeclaration(node, _state, ancestors) {
      const mod = norm(strOf(node.source));
      if (!mod) return;
      const scope = innermostScope(ancestors);
      for (const spec of node.specifiers) {
        if (!isIdent(spec.local)) continue;
        if (spec.type === "ImportDefaultSpecifier" || spec.type === "ImportNamespaceSpecifier") {
          if (CORE_MODULES.has(mod)) { core.set(spec.local.name, mod); declaredIn.set(spec.local.name, scope); }
          if (HOOK_PACKAGES.has(mod)) { hooks.set(spec.local.name, mod); declaredIn.set(spec.local.name, scope); }
        } else if (spec.type === "ImportSpecifier") {
          const key = isIdent(spec.imported) ? spec.imported.name : strOf(spec.imported);
          if (key) named.set(spec.local.name, { pkg: mod, imported: key });
        }
      }
    },
  });
  return { core, hooks, named, declaredIn };
}

const propName = (m) => {
  if (!m || m.type !== "MemberExpression") return null;
  if (m.computed) return m.property.type === "Literal" ? String(m.property.value) : null;
  return isIdent(m.property) ? m.property.name : null;
};

/**
 * Does the replacement call through what it replaced? `classifyRHS` already
 * distinguishes `wraps-original` from a constant return, so mechanism is derived
 * from it rather than guessed -- a wrap and a replace are different claims.
 */
/**
 * Does this right-hand side plausibly install a FUNCTION?
 *
 * The core-module bucket is about method replacement, not about writing data to
 * a module object. `is-docker` does `process.exitCode = isDocker() ? 0 : 2` --
 * an ordinary exit-code write that read as patching a core module on 31.7% of
 * servers. `minizlib` does `Buffer.concat = makeNoOp ? noop : OriginalBufferConcat`,
 * which is a genuine replacement; both are ternaries, so `rhsClass` cannot
 * separate them but the shape of the branches can.
 */
function looksFunctionValued(node) {
  if (!node) return false;
  switch (node.type) {
    case "FunctionExpression":
    case "ArrowFunctionExpression":
    case "ClassExpression":
    case "Identifier":
    case "MemberExpression":
    case "CallExpression":
    case "NewExpression":
      return true;
    case "ConditionalExpression":
      return looksFunctionValued(node.consequent) || looksFunctionValued(node.alternate);
    case "LogicalExpression":
      return looksFunctionValued(node.left) || looksFunctionValued(node.right);
    case "AssignmentExpression":
      return looksFunctionValued(node.right);
    default:
      return false;                                   // Literal, ObjectExpression, etc.
  }
}

function mechanismOf(rhsClass) {
  if (rhsClass === "wraps-original" || rhsClass === "semantics-preserving") return "wrap";
  if (rhsClass === "accessor") return "accessor";
  return "replace";
}

function scanServerSource(src, ast) {
  const hits = [];
  const { core, hooks, named, declaredIn } = moduleBindings(ast);
  const at = (n) => (n.loc ? n.loc.start.line : null);
  const push = (o) => hits.push(o);

  /**
   * A name bound to a core module is only that module where nothing closer
   * rebinds it. `parseurl` does `var url = require('url')` at module scope AND
   * uses a local `url` inside its functions; without this check every
   * `url.pathname = ...` on a parsed-URL object was recorded as patching the
   * `url` core module, making parseurl a top "core-module modifier" on 73% of
   * servers. Shadowing is resolved against the real scope chain, per hit.
   */
  const unshadowed = (name, ancestors) => {
    if (!name) return false;
    const declScope = declaredIn.get(name);
    if (!declScope) return false;
    return bindingScope(name, ancestors) === declScope;
  };

  walk.ancestor(ast, {
    AssignmentExpression(node, _state, ancestors) {
      const lhs = node.left;
      if (!lhs || lhs.type !== "MemberExpression") return;
      const method = propName(lhs);
      if (!method) return;
      const rhsClass = classifyRHS(node.right);

      /**
       * Module internals are checked BEFORE the generic core-module branch:
       * `require('module')` is itself a core module, so `Module._load = ...`
       * would otherwise be filed as an ordinary fs-style method replacement and
       * the require-hook bucket would read as empty.
       */
      const objName0 = isIdent(lhs.object) ? lhs.object.name
        : lhs.object.type === "MemberExpression" && isIdent(lhs.object.object) ? lhs.object.object.name : null;
      const isModuleSystem = (objName0 === "Module" || (objName0 && core.get(objName0) === "module")) &&
        (objName0 === "Module" || unshadowed(objName0, ancestors));
      if (isModuleSystem) {
        const onPrototype = lhs.object.type === "MemberExpression" && propName(lhs.object) === "prototype";
        if (/^(_load|_resolveFilename|_compile|_extensions|wrap|runMain)$/.test(method) ||
            (onPrototype && /^(require|_compile|load)$/.test(method))) {
          push({ bucket: "require-hook", namespace: "module", target: onPrototype ? `${objName0}.prototype` : objName0,
                 method, mechanism: mechanismOf(rhsClass), rhsClass, line: at(node), shape: "module-internals" });
          return;
        }
      }

      // fs.readFile = ...  (only when `fs` is a bound core module)
      if (isIdent(lhs.object) && core.has(lhs.object.name) && unshadowed(lhs.object.name, ancestors)) {
        if (!looksFunctionValued(node.right)) return;   // data write, not a method swap
        push({ bucket: "coremodule", namespace: core.get(lhs.object.name), target: "module",
               method, mechanism: mechanismOf(rhsClass), rhsClass, line: at(node), shape: "assignment" });
        return;
      }
      // fs.promises.readFile = ...
      if (lhs.object.type === "MemberExpression" && isIdent(lhs.object.object) &&
          core.has(lhs.object.object.name) && unshadowed(lhs.object.object.name, ancestors)) {
        if (!looksFunctionValued(node.right)) return;
        push({ bucket: "coremodule", namespace: core.get(lhs.object.object.name),
               target: propName(lhs.object) || "module", method,
               mechanism: mechanismOf(rhsClass), rhsClass, line: at(node), shape: "assignment" });
        return;
      }
      // global.setTimeout = ... / globalThis.fetch = ...
      if (isIdent(lhs.object) && (lhs.object.name === "global" || lhs.object.name === "globalThis")) {
        push({ bucket: BUILTIN_GLOBALS.has(method) ? "global" : "global-define",
               namespace: lhs.object.name, target: "global", method,
               mechanism: mechanismOf(rhsClass), rhsClass, line: at(node), shape: "assignment" });
        return;
      }
      // require.extensions['.ts'] = ...
      if (lhs.object.type === "MemberExpression" && isIdent(lhs.object.object) &&
          lhs.object.object.name === "require" && propName(lhs.object) === "extensions") {
        push({ bucket: "require-hook", namespace: "module", target: "require.extensions", method,
               mechanism: mechanismOf(rhsClass), rhsClass, line: at(node), shape: "require.extensions" });
      }
    },

    CallExpression(node, _state, ancestors) {
      const callee = node.callee;

      // shimmer.wrap(obj, 'method', fn) / shimmer.massWrap([...], [...], fn)
      if (callee.type === "MemberExpression" && isIdent(callee.object) && hooks.has(callee.object.name)) {
        const fn = propName(callee);
        if (fn === "wrap" || fn === "massWrap" || fn === "unwrap" || fn === "massUnwrap") {
          push({ bucket: "wrap-helper", namespace: hooks.get(callee.object.name), target: describeTarget(node.arguments[0]),
                 method: strOf(node.arguments[1]) || namesOf(node.arguments[1]) || "<computed>",
                 mechanism: fn.startsWith("mass") ? "wrap-many" : fn.startsWith("un") ? "unwrap" : "wrap",
                 rhsClass: "wraps-original", line: at(node), shape: `${hooks.get(callee.object.name)}.${fn}` });
          return;
        }
      }
      // bare `wrap(obj, 'method', fn)` destructured from shimmer
      if (isIdent(callee) && named.has(callee.name)) {
        const { pkg, imported } = named.get(callee.name);
        if (HOOK_PACKAGES.has(pkg) && /^(wrap|massWrap)$/.test(imported)) {
          push({ bucket: "wrap-helper", namespace: pkg, target: describeTarget(node.arguments[0]),
                 method: strOf(node.arguments[1]) || namesOf(node.arguments[1]) || "<computed>",
                 mechanism: imported === "massWrap" ? "wrap-many" : "wrap",
                 rhsClass: "wraps-original", line: at(node), shape: `${pkg}.${imported}` });
          return;
        }
      }
      // new Hook([...], fn) from require-in-the-middle / import-in-the-middle
      const hookName = isIdent(callee) ? callee.name : null;
      if (hookName && named.has(hookName) && HOOK_PACKAGES.has(named.get(hookName).pkg)) {
        push({ bucket: "require-hook", namespace: named.get(hookName).pkg, target: "Hook",
               method: namesOf(node.arguments[0]) || "<dynamic>", mechanism: "intercept",
               rhsClass: "other", line: at(node), shape: "hook-constructor" });
      }
    },

    NewExpression(node, _state, ancestors) {
      const callee = node.callee;
      const name = isIdent(callee) ? callee.name
        : callee.type === "MemberExpression" && isIdent(callee.object) ? callee.object.name : null;
      if (!name) return;
      const pkg = hooks.get(name) || (named.get(name) && named.get(name).pkg);
      if (pkg && HOOK_PACKAGES.has(pkg)) {
        push({ bucket: "require-hook", namespace: pkg, target: "Hook",
               method: namesOf(node.arguments[0]) || "<dynamic>", mechanism: "intercept",
               rhsClass: "other", line: at(node), shape: "new Hook()" });
      }
    },
  });
  return hits;
}

/** A readable description of what is being wrapped, without evaluating anything. */
function describeTarget(node) {
  if (!node) return "<none>";
  if (isIdent(node)) return node.name;
  if (node.type === "MemberExpression") {
    const o = isIdent(node.object) ? node.object.name : "?";
    return `${o}.${propName(node) || "?"}`;
  }
  if (node.type === "ArrayExpression") return "<array>";
  return "<expr>";
}

/** String literals inside an array argument: `massWrap([...], ['read','write'], fn)`. */
function namesOf(node) {
  if (!node || node.type !== "ArrayExpression") return null;
  const names = node.elements.map(strOf).filter(Boolean);
  return names.length ? names.join("+") : null;
}

/**
 * Legacy accessor definition on a builtin prototype:
 *   `String.prototype.__defineGetter__('rainbow', fn)`
 *
 * Found by Arm S-3, not by reasoning: booting `mirotalkc2c` showed 40 methods
 * appearing on `String.prototype` at runtime that the static scan had reported as
 * nothing at all. The cause is `colors`, which uses `__defineGetter__` rather than
 * assignment or `Object.defineProperty` -- a fifth shape neither the Exp-1
 * detector nor this one covered. The `colors` family is in 36.6% of server
 * closures, so this was a material false negative.
 *
 * Returns [{ builtin, target, method, kind, rhsClass }].
 */
function detectDefineAccessor(ast) {
  const out = [];
  const walkAny = walk;
  walkAny.simple(ast, {
    CallExpression(node) {
      const callee = node.callee;
      if (callee.type !== "MemberExpression") return;
      const fn = callee.computed
        ? (callee.property.type === "Literal" ? String(callee.property.value) : null)
        : (callee.property.type === "Identifier" ? callee.property.name : null);
      if (fn !== "__defineGetter__" && fn !== "__defineSetter__") return;

      // Receiver must be `<Builtin>.prototype`.
      const recv = callee.object;
      if (!recv || recv.type !== "MemberExpression" || recv.computed) return;
      const propName = recv.property.type === "Identifier" ? recv.property.name : null;
      if (propName !== "prototype") return;
      const base = recv.object.type === "Identifier" ? recv.object.name : null;
      if (!base || !BUILTINS.has(base)) return;

      const arg0 = node.arguments[0];
      const method = arg0 && arg0.type === "Literal" ? String(arg0.value) : "<computed>";
      out.push({
        builtin: base, target: "prototype", method,
        kind: fn === "__defineGetter__" ? "defineGetter" : "defineSetter",
        rhsClass: classifyRHS(node.arguments[1]) || "accessor",
      });
    },
  });
  return out;
}

module.exports = { scanServerSource, moduleBindings, CORE_MODULES, HOOK_PACKAGES,
                   mechanismOf, BUILTIN_GLOBALS, looksFunctionValued, detectDefineAccessor };
