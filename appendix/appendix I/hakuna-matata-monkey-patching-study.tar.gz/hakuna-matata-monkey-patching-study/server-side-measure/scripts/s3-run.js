#!/usr/bin/env node
/**
 * Arm S-3: boot real applications under the S-1 probe and snapshot the modified
 * surface at end-of-init.
 *
 * This is the only measurement that closes the gap between "the library patches
 * nothing when loaded alone" (S-1) and "the assembled application patches
 * nothing". S-1 reports zero for `shimmer`, `require-in-the-middle` and
 * `@opentelemetry/instrumentation` by construction -- in isolation nothing calls
 * them. A booted application is that caller.
 *
 * SAFETY (handoff §9). This executes real application code, so:
 *   - hand-picked, source-inspected applications only; never at population scale
 *   - pinned shallow clones, `npm install --ignore-scripts` where the app allows
 *   - execution wrapped in `sandbox-exec`: outbound network denied except
 *     localhost, so the app may reach its own database but cannot phone home;
 *     the envelope is verified before any application code runs
 *   - hard deadline, output captured to a file
 *
 * Every app carries a PREDICTION recorded before the boot, so this is validation
 * rather than exploration. The prediction comes from S-2 (what is in the server
 * closure) and S-1 (what each of those packages does when loaded).
 *
 * Usage: node scripts/s3-run.js [--only <name>] [--deadline 25000]
 * Output: results/server-headless.json
 */
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync, spawnSync } = require("node:child_process");

const ROOT = path.resolve(__dirname, "..");
const WORK = path.join(ROOT, "cache", "s3");
const PROFILE = path.join(WORK, "nonet.sb");
const RESULTS = path.join(ROOT, "results");
const log = (...a) => console.error("[s3]", ...a);

/**
 * Tier 1 only for now: applications needing no external service, to prove the
 * harness before spending time on Postgres. `coreJs` records whether core-js is
 * in the app's SERVER closure per S-2 -- the decisive predictor.
 */
const APPS = [
  {
    name: "mirotalkc2c", repo: "https://github.com/miroslavpejic85/mirotalkc2c",
    entry: null, services: "none", coreJs: false,
    predict: "0 guard. No core-js in closure, so no guard-surface change is possible from polyfills. Expect little beyond ordinary server startup.",
  },
  /**
   * Deployment-shape variants. `dd-trace` and OpenTelemetry are not ordinary
   * application dependencies -- they are injected at boot via NODE_OPTIONS in
   * production. Booting an app under them measures two things at once: whether an
   * instrumented application reaches the guard surface, and what the agents do
   * when something actually drives them (S-1 reports zero for OTel because,
   * loaded alone, nothing calls it). This also covers the population gap: the
   * awesome-selfhosted catalogue contains almost no commercially-instrumented
   * services (dd-trace 1.4%, newrelic 0.7%).
   */
  {
    name: "mirotalkc2c+dd-trace", repo: "https://github.com/miroslavpejic85/mirotalkc2c",
    entry: null, services: "none", coreJs: false,
    extraInstall: ["dd-trace"], preload: ["dd-trace/init"],
    predict: "0 guard. Expect ~226 core-module wraps mirroring S-1's isolated dd-trace figure of 228.",
  },
  {
    name: "mirotalkc2c+otel", repo: "https://github.com/miroslavpejic85/mirotalkc2c",
    entry: null, services: "none", coreJs: false,
    extraInstall: ["@opentelemetry/auto-instrumentations-node", "@opentelemetry/sdk-node"],
    preload: ["@opentelemetry/auto-instrumentations-node/register"],
    predict: "0 guard, but NON-zero core-module -- this is the direct test of whether S-1's zero for @opentelemetry/instrumentation was a scope artifact.",
  },
  {
    name: "myip", repo: "https://github.com/jason5ng32/MyIP",
    entry: "server.js", services: "none", coreJs: false,
    predict: "0 guard. No core-js in closure. Negative control.",
  },
  /**
   * Dropped after attempting: `strapi` is a framework MONOREPO, not a deployable
   * application -- its root has no server entry, and the server only exists in a
   * generated project. Recorded rather than silently removed; the "no services
   * detected" signal in the candidate ranking should have flagged it.
   */
  {
    name: "strapi", repo: "https://github.com/strapi/strapi",
    entry: null, services: "none-detected", coreJs: true, skip: true,
    skipReason: "framework monorepo with no bootable server entry; not a deployed application",
    predict: "n/a -- not bootable",
  },

  // Tier 2: one service, core-js present -- the decisive predictions.
  {
    name: "rsshub", repo: "https://github.com/DIYgod/RSSHub",
    entry: null, services: "redis (optional; falls back to in-memory)", coreJs: true,
    predict: "0 guard DESPITE core-js in the server closure -- S-1 shows its feature-detection gates are false for guard-dispatch methods on this Node. Expect core-module/global changes from hono/OTel/Sentry.",
  },
  /**
   * `Ghost` and `linkwarden` were dropped for the same reason as `strapi`: both
   * are monorepo roots with no `start` script and no `main`, so there is no
   * server to boot without reconstructing a full Nx / workspace build plus a
   * database. Recorded rather than silently removed -- "the repository root is
   * not the deployable unit" is a recurring property of this population and is
   * worth stating.
   */
  {
    name: "ghost", repo: "https://github.com/TryGhost/Ghost",
    entry: null, services: "n/a", coreJs: true, skip: true,
    skipReason: "Nx monorepo root: no start script, no main; server lives in ghost/core and needs a full workspace build",
    predict: "n/a -- not bootable at the repository root",
  },
  {
    name: "linkwarden", repo: "https://github.com/linkwarden/linkwarden",
    entry: null, services: "n/a", coreJs: true, skip: true,
    skipReason: "workspace monorepo root (apps/*): no start script, no main; Next app needs prisma generate, blocked by --ignore-scripts",
    predict: "n/a -- not bootable at the repository root",
  },
  /**
   * Substituted in: a real self-hosted server whose start script is a plain
   * `node index.js`, with core-js in its server closure. Chosen by filtering the
   * 36 core-js-positive applications for one that boots without a build.
   */
  {
    name: "audiobookshelf", repo: "https://github.com/advplyr/audiobookshelf",
    entry: null, services: "sqlite", coreJs: true,
    args: ["--config", "./.s3-config", "--metadata", "./.s3-metadata", "--port", "0"],
    /**
     * Cannot boot on Node v26: its transitive dependency
     * `buffer-equal-constant-time` does `SlowBuffer.prototype.equal = ...` at
     * import, and Node removed `SlowBuffer`. A package that monkey-patches a
     * builtin breaks when the runtime deletes that builtin -- an incidental but
     * pointed illustration of why runtime version matters. Recorded as an
     * environment incompatibility, not as a measurement.
     */
    nodeIncompatible: "buffer-equal-constant-time reads SlowBuffer.prototype; SlowBuffer was removed in modern Node",
    predict: "0 guard despite core-js in the server closure. Second core-js-positive booted app; expect core-module/global changes only, as with RSSHub.",
  },
];

function sh(cmd, args, opts) {
  return execFileSync(cmd, args, { encoding: "utf8", timeout: 900000,
                                   stdio: ["ignore", "pipe", "pipe"], ...opts });
}

function verifySandbox() {
  const check = spawnSync("sandbox-exec", ["-f", PROFILE, process.execPath, "-e",
    "fetch('https://registry.npmjs.org/').then(()=>console.log('ALLOWED')).catch(()=>console.log('BLOCKED'))"],
    { encoding: "utf8", timeout: 30000 });
  if (!/BLOCKED/.test(check.stdout || "")) {
    throw new Error("sandbox did not block external egress; refusing to boot applications");
  }
  log("sandbox verified: external egress blocked, localhost permitted");
}

function prepare(app) {
  // Variants share the base application's clone rather than re-cloning it.
  const dir = path.join(WORK, app.name.split("+")[0]);
  if (!fs.existsSync(path.join(dir, ".git"))) {
    log(`${app.name}: cloning (depth 1)`);
    sh("git", ["clone", "--depth", "1", app.repo, dir]);
  }
  app.commit = sh("git", ["rev-parse", "HEAD"], { cwd: dir }).trim();
  if (!fs.existsSync(path.join(dir, "node_modules"))) {
    /**
     * Use the package manager the repository actually uses. `strapi` is a pnpm
     * workspace and its manifests use the `catalog:` protocol, which npm cannot
     * parse at all ("Unsupported URL Type"). pnpm comes from corepack, which
     * ships with Node, so nothing is installed globally.
     */
    const usesPnpm = fs.existsSync(path.join(dir, "pnpm-lock.yaml"));
    const usesYarn = fs.existsSync(path.join(dir, "yarn.lock"));
    const cmd = usesPnpm ? ["corepack", ["pnpm", "install", "--ignore-scripts", "--config.confirmModulesPurge=false"]]
      : usesYarn ? ["corepack", ["yarn", "install", "--mode=skip-build"]]
      : ["npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund", "--loglevel=error"]];
    app.packageManager = usesPnpm ? "pnpm" : usesYarn ? "yarn" : "npm";
    log(`${app.name}: ${app.packageManager} install (scripts disabled)`);
    try { sh(cmd[0], cmd[1], { cwd: dir }); }
    catch (e) {
      const msg = String(e.stderr || e.message).split("\n").slice(0, 3).join(" ").slice(0, 300);
      return { dir, installError: msg };
    }
  }
  /**
   * Modern apps ship a build: RSSHub's start script is `node dist/index.mjs`,
   * which does not exist until `build` has run. The build executes the project's
   * own tooling and is allowed network (as `npm install` is); only the BOOT is
   * sandboxed, since that is where application code runs. Booting the TypeScript
   * entry via `tsx` instead would confound the measurement -- tsx patches module
   * resolution itself, and this study measures module-resolution patching.
   */
  if (!resolveEntry(app, dir)) {
    let pkg = null;
    try { pkg = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8")); } catch { /* ignore */ }
    const hasBuild = pkg && pkg.scripts && pkg.scripts.build;
    if (hasBuild) {
      const pm = app.packageManager || "npm";
      log(`${app.name}: no entry yet -- running ${pm} build (this is slow)`);
      try {
        if (pm === "npm") sh("npm", ["run", "build"], { cwd: dir, timeout: 1800000 });
        else sh("corepack", [pm, "run", "build"], { cwd: dir, timeout: 1800000 });
        app.built = true;
      } catch (e) {
        const msg = String(e.stderr || e.message).split("\n").filter(Boolean).slice(-3).join(" | ").slice(0, 400);
        return { dir, buildError: msg };
      }
    }
  }

  if (app.extraInstall && app.extraInstall.length) {
    const missing = app.extraInstall.filter((m) => !fs.existsSync(path.join(dir, "node_modules", m)));
    if (missing.length) {
      log(`${app.name}: installing agent(s) ${missing.join(", ")}`);
      try { sh("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund", "--loglevel=error", ...missing], { cwd: dir }); }
      catch (e) { return { dir, installError: String(e.stderr || e.message).slice(0, 300) }; }
    }
  }
  return { dir };
}

/**
 * Resolve the server entry the way the handoff specifies: the documented start
 * script first, then `main`. Hardcoding paths guessed wrong for mirotalkc2c
 * (`backend/server.js`, not `app/src/server.js`), and guessing is exactly what
 * this study removed at the dependency level.
 */
function resolveEntry(app, dir) {
  if (app.entry) {
    const e = path.join(dir, app.entry);
    if (fs.existsSync(e)) return e;
  }
  let pkg = null;
  try { pkg = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8")); } catch { return null; }
  const start = (pkg.scripts && (pkg.scripts.start || pkg.scripts.serve)) || "";
  const m = /\bnode\s+(?:--[\w-]+(?:=\S+)?\s+)*([\w./@-]+\.(?:js|cjs|mjs))/.exec(start);
  if (m) {
    const e = path.join(dir, m[1]);
    if (fs.existsSync(e)) return e;
  }
  if (typeof pkg.main === "string") {
    const e = path.join(dir, pkg.main);
    if (fs.existsSync(e)) return e;
  }
  return null;
}

function boot(app, dir, deadline) {
  const outFile = path.join(WORK, `${app.name}.snapshot.json`);
  try { fs.rmSync(outFile, { force: true }); } catch { /* ignore */ }
  const entry = resolveEntry(app, dir);
  if (!entry) return { error: `could not resolve a server entry (tried app.entry, scripts.start, main)` };
  app.resolvedEntry = path.relative(dir, entry);

  const preloads = [];
  for (const m of app.preload || []) preloads.push("--require", m);
  const res = spawnSync("sandbox-exec", ["-f", PROFILE, process.execPath,
      "--require", path.join(ROOT, "scripts", "probe.js"),
      "--require", path.join(ROOT, "scripts", "s3-snapshot.js"), ...preloads, entry,
      ...(app.args || [])],
    { cwd: dir, encoding: "utf8", timeout: deadline + 30000, maxBuffer: 64 * 1024 * 1024,
      env: { ...process.env, S3_OUT: outFile, S3_DEADLINE_MS: String(deadline),
             NODE_ENV: "production", PORT: "0", ...(app.env || {}) } });

  if (!fs.existsSync(outFile)) {
    return { error: (res.stderr || res.stdout || "no snapshot written").split("\n").slice(0, 4).join(" | ").slice(0, 500) };
  }
  const snap = JSON.parse(fs.readFileSync(outFile, "utf8"));
  snap.stderrHead = (res.stderr || "").split("\n").slice(0, 3).join(" | ").slice(0, 300);
  return snap;
}

const BUILTINS = new Set(["Object", "Array", "String", "RegExp", "Function", "Promise",
  "Map", "Set", "Number", "Boolean", "Date", "JSON", "Reflect", "Error", "Symbol",
  "Math", "WeakMap", "WeakSet", "BigInt", "TypeError", "RangeError", "SyntaxError"]);
const GUARD_NS = new Set(["String", "Array", "RegExp"]);
const BARRIER = new Set(["includes", "startsWith", "endsWith", "indexOf", "lastIndexOf",
  "test", "exec", "match", "search", "replace", "replaceAll", "split", "trim",
  "toLowerCase", "toUpperCase", "slice", "substring", "some", "every", "filter",
  "find", "findIndex", "keys", "values", "entries", "concat", "join", "flat", "flatMap"]);

function classify(changes) {
  const out = { guard: [], broad: [], global: [], coremodule: [] };
  for (const c of changes) {
    const [ns, target, method] = c.key.split("|");
    if (BUILTINS.has(ns)) {
      if (GUARD_NS.has(ns) && target === "prototype" && BARRIER.has(method)) out.guard.push(c.key);
      else out.broad.push(c.key);
    } else if (ns === "globalThis") out.global.push(c.key);
    else out.coremodule.push(c.key);
  }
  return out;
}

function main() {
  const onlyIdx = process.argv.indexOf("--only");
  const only = onlyIdx !== -1 ? process.argv[onlyIdx + 1] : null;
  const dIdx = process.argv.indexOf("--deadline");
  const deadline = dIdx !== -1 ? Number(process.argv[dIdx + 1]) : 25000;
  const apps = only ? APPS.filter((a) => a.name === only) : APPS;

  fs.mkdirSync(WORK, { recursive: true });
  verifySandbox();

  const results = [];
  for (const app of apps) {
    if (app.skip) {
      log(`${app.name}: skipped -- ${app.skipReason}`);
      results.push({ ...app, status: "skipped", error: app.skipReason });
      continue;
    }
    const prep = prepare(app);
    if (prep.installError) {
      log(`${app.name}: install FAILED -- ${prep.installError}`);
      results.push({ ...app, status: "install-failed", error: prep.installError });
      continue;
    }
    if (prep.buildError) {
      log(`${app.name}: build FAILED -- ${prep.buildError.slice(0, 160)}`);
      results.push({ ...app, status: "build-failed", error: prep.buildError });
      continue;
    }
    const snap = boot(app, prep.dir, deadline);
    if (snap.error) {
      log(`${app.name}: boot FAILED -- ${snap.error.slice(0, 160)}`);
      results.push({ ...app, status: "boot-failed", error: snap.error });
      continue;
    }
    const buckets = classify(snap.changes);
    /**
     * An application that exits in well under the deadline never reached steady
     * state, so its snapshot is a partial init and must not be read as "this app
     * modifies only N slots". `audiobookshelf` exited after 85ms on the first
     * attempt, before its server had started.
     */
    const partial = snap.reason !== "deadline" && snap.elapsedMs < 5000;
    results.push({
      ...app, status: partial ? "partial-init" : "ok",
      partialInit: partial || undefined,
      commit: app.commit, reason: snap.reason,
      elapsedMs: snap.elapsedMs, totalChanges: snap.changes.length,
      buckets: Object.fromEntries(Object.entries(buckets).map(([k, v]) => [k, v.length])),
      guardKeys: buckets.guard,
      shimmerWraps: snap.changes.filter((c) => c.shimmerMarker).length,
      namespaces: snap.changes.reduce((acc, c) => {
        const ns = c.key.split("|")[0]; acc[ns] = (acc[ns] || 0) + 1; return acc;
      }, {}),
      sample: snap.changes.slice(0, 40),
    });
    log(`${app.name.padEnd(22)} ${(partial ? "PARTIAL:" + snap.reason : snap.reason).padEnd(14)} changes=${String(snap.changes.length).padStart(4)} ` +
        `guard=${buckets.guard.length} broad=${buckets.broad.length} global=${buckets.global.length} core=${buckets.coremodule.length}`);
  }

  fs.mkdirSync(RESULTS, { recursive: true });
  const prior = fs.existsSync(path.join(RESULTS, "server-headless.json"))
    ? JSON.parse(fs.readFileSync(path.join(RESULTS, "server-headless.json"), "utf8")) : { applications: [] };
  const merged = [...prior.applications.filter((p) => !results.some((r) => r.name === p.name)), ...results];
  fs.writeFileSync(path.join(RESULTS, "server-headless.json"), JSON.stringify({
    generated: new Date().toISOString().slice(0, 10),
    question: "Does an assembled, booted application modify built-ins that its isolated dependencies do not?",
    method: {
      probe: "scripts/probe.js preload, 1826 slots, diffed by identity at end-of-init",
      snapshot: "beforeExit, or a wall-clock deadline for servers that stay up",
      sandbox: "sandbox-exec; outbound network denied except localhost; verified before each run",
      install: "npm install --ignore-scripts on a pinned shallow clone",
      selection: "hand-picked and source-inspected; never at population scale",
      prediction: "each app carries a prediction recorded before booting, derived from S-2 closure membership and S-1 per-package behaviour",
    },
    applications: merged,
  }, null, 1));
  log("wrote results/server-headless.json");
}
main();
