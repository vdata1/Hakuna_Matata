#!/usr/bin/env node
/**
 * S-1 probe: snapshot every builtin/global/core-module slot, load ONE target,
 * then diff by identity.
 *
 * Preloaded with `node --require ./probe.js` so the snapshot is taken BEFORE the
 * target is required. Attribution is trivial because exactly one target is loaded
 * per process (handoff §3).
 *
 * What a diff proves that S-2's static scan cannot: that the patch actually
 * applies when the package is loaded, and whether it applies at import time or
 * only after an explicit opt-in call. That is the gap between "reachable in the
 * dependency closure" and "the running process has a different function".
 */
const NAMESPACES = [
  "Object", "Array", "String", "RegExp", "Function", "Promise", "Map", "Set",
  "Number", "Boolean", "Date", "JSON", "Reflect", "Error", "Symbol", "Math",
  "WeakMap", "WeakSet", "BigInt", "TypeError", "RangeError", "SyntaxError",
];

const GLOBALS = [
  "setTimeout", "setInterval", "setImmediate", "clearTimeout", "clearInterval",
  "clearImmediate", "queueMicrotask", "structuredClone", "fetch", "URL",
  "URLSearchParams", "AbortController", "AbortSignal", "TextEncoder", "TextDecoder",
  "Buffer", "crypto", "performance", "atob", "btoa", "Headers", "Request",
  "Response", "FormData", "Blob", "ReadableStream", "WritableStream",
  "TransformStream", "Event", "EventTarget", "MessageChannel", "structuredClone",
];

const CORE_MODULES = [
  "fs", "fs/promises", "http", "https", "net", "dns", "child_process", "module",
  "path", "os", "crypto", "stream", "zlib", "events", "util", "timers", "url",
  "querystring", "vm", "worker_threads", "async_hooks", "readline", "buffer",
  "tls", "dgram", "perf_hooks", "string_decoder", "assert", "process",
];

/** key -> { value, get, set, isAccessor } */
function snapshot() {
  const map = new Map();
  const record = (ns, target, prop, obj) => {
    let d;
    try { d = Object.getOwnPropertyDescriptor(obj, prop); } catch { return; }
    if (!d) return;
    map.set(`${ns}|${target}|${prop}`, {
      value: d.value, get: d.get, set: d.set, isAccessor: Boolean(d.get || d.set),
    });
  };

  for (const ns of NAMESPACES) {
    const ctor = globalThis[ns];
    if (!ctor) continue;
    try {
      for (const p of Object.getOwnPropertyNames(ctor)) record(ns, "static", p, ctor);
      if (ctor.prototype) {
        for (const p of Object.getOwnPropertyNames(ctor.prototype)) record(ns, "prototype", p, ctor.prototype);
      }
    } catch { /* exotic namespace, skip */ }
  }

  for (const g of GLOBALS) record("globalThis", "global", g, globalThis);

  for (const m of CORE_MODULES) {
    let mod;
    try { mod = require(m); } catch { continue; }
    if (!mod || (typeof mod !== "object" && typeof mod !== "function")) continue;
    try {
      for (const p of Object.getOwnPropertyNames(mod)) record(m, "module", p, mod);
    } catch { /* getters that throw */ }
    // fs.promises and similar nested namespaces carry their own methods.
    for (const sub of ["promises", "constants", "Server", "Agent"]) {
      try {
        if (mod[sub] && typeof mod[sub] === "object") {
          for (const p of Object.getOwnPropertyNames(mod[sub])) record(m, sub, p, mod[sub]);
        }
      } catch { /* ignore */ }
    }
  }

  // The module system itself: the dominant server interception point.
  try {
    const Module = require("module");
    for (const p of ["_load", "_resolveFilename", "_compile", "_extensions", "wrap", "runMain"]) {
      record("module", "Module", p, Module);
    }
    if (Module.prototype) {
      for (const p of ["require", "load", "_compile"]) record("module", "Module.prototype", p, Module.prototype);
    }
    if (require.extensions) {
      for (const p of Object.getOwnPropertyNames(require.extensions)) {
        record("module", "require.extensions", p, require.extensions);
      }
    }
  } catch { /* ignore */ }

  return map;
}

const same = (a, b) => a === b || (Number.isNaN(a) && Number.isNaN(b));

/**
 * Compare a fresh snapshot against the baseline. Only slots whose identity
 * changed are reported; a slot that merely still exists is not a modification.
 */
function diff(baseline) {
  const now = snapshot();
  const changes = [];
  for (const [key, before] of baseline) {
    const after = now.get(key);
    if (!after) { changes.push({ key, kind: "deleted", before, after: null }); continue; }
    if (before.isAccessor || after.isAccessor) {
      if (!same(before.get, after.get) || !same(before.set, after.set) || before.isAccessor !== after.isAccessor) {
        changes.push({ key, kind: "accessor", before, after });
      }
      continue;
    }
    if (!same(before.value, after.value)) changes.push({ key, kind: "value", before, after });
  }
  for (const [key, after] of now) {
    if (!baseline.has(key)) changes.push({ key, kind: "added", before: null, after });
  }
  return changes;
}

let baseline = snapshot();
globalThis.__PROBE__ = {
  snapshot,
  diff: () => diff(baseline),
  /**
   * Re-take the baseline. The loader calls this immediately before requiring the
   * target, because Node sets `process.mainModule` when the main script starts --
   * after this preload runs -- and that would otherwise be attributed to the
   * target as an "added" slot.
   */
  rebaseline: () => { baseline = snapshot(); return baseline.size; },
  get baselineSize() { return baseline.size; },
};
