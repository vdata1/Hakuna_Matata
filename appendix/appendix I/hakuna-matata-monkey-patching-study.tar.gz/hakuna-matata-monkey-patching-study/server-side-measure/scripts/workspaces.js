#!/usr/bin/env node
/**
 * Workspace inventory + server/client classification.
 *
 * Handoff §3 calls this "the one hard part": a package counts as server-runtime
 * only if the server process can reach it, and core-js sitting in a client build
 * must not be counted as if the server loaded it.
 *
 * We classify each package.json in a repository as the root of a SERVER, CLIENT,
 * DUAL (SSR), or TOOLING dependency closure, then root the lockfile traversal at
 * the server ones only (see rooted-closure.js).
 *
 * Every classification records the *evidence* that produced it, so a reviewer can
 * audit any single decision rather than trusting a label. Nothing is executed;
 * manifests are parsed as data.
 */

/** Frameworks that only make sense inside a long-lived server process. */
const SERVER_FRAMEWORKS = new Set([
  "express", "fastify", "koa", "@nestjs/core", "@nestjs/common", "@hapi/hapi",
  "hapi", "restify", "polka", "h3", "hono", "connect", "apollo-server",
  "apollo-server-express", "@apollo/server", "graphql-yoga", "socket.io",
  "ws", "mongoose", "typeorm", "prisma", "@prisma/client", "sequelize", "knex",
  "pg", "mysql", "mysql2", "redis", "ioredis", "bullmq", "bull", "agenda",
  "passport", "jsonwebtoken", "helmet", "cors", "multer", "body-parser",
  "nodemailer", "pino", "winston", "bunyan", "dotenv", "cron", "node-cron",
]);

/** Libraries that only make sense in a browser document. */
const CLIENT_LIBS = new Set([
  "react-dom", "vue", "svelte", "preact", "solid-js", "jquery", "alpinejs",
  "@angular/platform-browser", "@angular/platform-browser-dynamic",
  "backbone", "ember-source", "lit", "@stencil/core", "htmx.org",
]);

/** Bundlers/toolchains: presence indicates a client build, not a server runtime. */
const BUNDLERS = new Set([
  "vite", "webpack", "rollup", "parcel", "esbuild", "@vitejs/plugin-react",
  "@vitejs/plugin-vue", "webpack-cli", "webpack-dev-server", "@parcel/core",
  "browserify", "snowpack", "@rsbuild/core", "rspack", "@rspack/core",
]);

/**
 * Meta-frameworks that genuinely run in BOTH places: they load inside the Node
 * server process for SSR *and* emit a client bundle. Per handoff §3 these must
 * never be silently binned into one column -- the study reports server-closure
 * figures both including and excluding them.
 */
const SSR_FRAMEWORKS = new Set([
  "next", "nuxt", "nuxt3", "@sveltejs/kit", "@remix-run/node",
  "@remix-run/server-runtime", "@remix-run/express", "astro", "gatsby",
  "@angular/ssr", "@nuxtjs/vue-app", "@builder.io/qwik-city", "solid-start",
  "@analogjs/platform", "vike", "fresh",
]);

/** `scripts` values that start a Node process. `next dev` is deliberately absent: SSR. */
const SERVER_START_RE =
  /(^|[\s;&|"'])(node|nodemon|tsx|ts-node|ts-node-dev|nest\s+start|fastify\s+start|pm2|forever|bun\s+run|deno\s+run)\b/;
const BUILD_CLIENT_RE =
  /(^|[\s;&|"'])(vite|webpack|rollup|parcel|esbuild|ng\s+build|craco|react-scripts|rsbuild)\b/;

const has = (obj, set) => Object.keys(obj || {}).filter((d) => set.has(d));

/**
 * Classify one manifest.
 * @returns {{kind:string, evidence:string[], ssr:string[]}}
 *   kind: 'server' | 'client' | 'dual' | 'tooling' | 'unknown'
 */
function classifyManifest(pkg, dir) {
  const deps = pkg.dependencies || {};
  const dev = pkg.devDependencies || {};
  const allDeps = { ...deps, ...dev };
  const scripts = pkg.scripts || {};
  const evidence = [];

  const ssr = [...new Set([...has(deps, SSR_FRAMEWORKS), ...has(dev, SSR_FRAMEWORKS)])];
  if (ssr.length) evidence.push(`ssr-framework:${ssr.join("+")}`);

  // --- server evidence ---
  const serverFw = has(deps, SERVER_FRAMEWORKS);
  if (serverFw.length) evidence.push(`server-dep:${serverFw.slice(0, 3).join("+")}`);
  if (pkg.bin) evidence.push("bin");
  const startScripts = ["start", "serve", "dev", "start:prod", "server"]
    .filter((k) => scripts[k] && SERVER_START_RE.test(scripts[k]));
  if (startScripts.length) evidence.push(`start-script:${startScripts[0]}`);
  if (pkg.engines && pkg.engines.node) evidence.push("engines.node");

  // --- client evidence ---
  const clientLib = [...has(deps, CLIENT_LIBS), ...has(dev, CLIENT_LIBS)];
  if (clientLib.length) evidence.push(`client-dep:${clientLib.slice(0, 3).join("+")}`);
  if (pkg.browser) evidence.push("browser-field");
  const bundler = has(allDeps, BUNDLERS);
  if (bundler.length) evidence.push(`bundler:${bundler.slice(0, 3).join("+")}`);
  const buildsClient = Object.entries(scripts)
    .some(([k, v]) => /^(build|bundle)/.test(k) && BUILD_CLIENT_RE.test(String(v)));
  if (buildsClient) evidence.push("client-build-script");

  const serverScore = serverFw.length * 2 + (pkg.bin ? 2 : 0) + startScripts.length * 2 +
    (pkg.engines && pkg.engines.node ? 1 : 0);
  /**
   * A bundler in devDependencies is weak evidence: servers routinely use esbuild
   * or tsup to compile TypeScript. Counting it at full weight misfiled n8n's
   * `packages/cli` -- the actual server, carrying bin + start script + bull/cron
   * -- as `dual` purely because it builds with esbuild. Only a bundler in real
   * `dependencies`, a `browser` field, or a browser library is strong evidence.
   */
  const bundlerDeps = has(deps, BUNDLERS);
  const clientScore = clientLib.length * 2 + (pkg.browser ? 2 : 0) +
    bundlerDeps.length * 2 + (bundler.length ? 1 : 0) + (buildsClient ? 2 : 0);

  /**
   * Dominance rule: `dual` is reserved for genuinely two-sided workspaces, not
   * for any workspace with a trace of both. One side must be at least twice the
   * other to claim the workspace outright.
   */
  let kind;
  if (ssr.length) kind = "dual";
  else if (serverScore && clientScore) {
    if (serverScore >= 2 * clientScore) kind = "server";
    else if (clientScore >= 2 * serverScore) kind = "client";
    else kind = "dual";
  }
  else if (serverScore) kind = "server";
  else if (clientScore) kind = "client";
  else if (Object.keys(deps).length === 0 && Object.keys(dev).length > 0) kind = "tooling";
  else kind = "unknown";

  if (kind === "dual" && !ssr.length) evidence.push("mixed-signals");
  return { kind, evidence, ssr, dir, name: pkg.name || null, serverScore, clientScore,
           deps: Object.keys(deps), devDeps: Object.keys(dev) };
}

module.exports = { classifyManifest, SERVER_FRAMEWORKS, CLIENT_LIBS, BUNDLERS, SSR_FRAMEWORKS };
