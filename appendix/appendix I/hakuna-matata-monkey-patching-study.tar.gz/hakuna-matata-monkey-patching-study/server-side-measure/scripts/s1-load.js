#!/usr/bin/env node
/**
 * S-1 target loader. Runs as: node --require probe.js s1-load.js <package>
 *
 * Loads exactly ONE target, diffs the probe snapshot, then attempts the package's
 * opt-in entry point (if any) and diffs again. Emits JSON on stdout.
 *
 * The two phases matter for the paper: a patch applied at import time affects any
 * process that merely has the package in its graph, whereas an opt-in patch only
 * lands if the application deliberately calls it. `graceful-fs` is the clean
 * example -- requiring it changes nothing; `.gracefulify(fs)` replaces fs methods.
 *
 * No classification happens here: the sandbox stays minimal and only reports raw
 * evidence (identity changed, shimmer markers, function source). The driver does
 * the classifying with the Exp-2 RHS classifier.
 */
/**
 * `require` inside this script resolves from scripts/, not from the sandbox
 * directory where the target was installed, so a plain require(target) fails
 * with MODULE_NOT_FOUND and the run looks like "modifies nothing". Resolve from
 * the sandbox cwd instead.
 */
const { createRequire } = require("node:module");
const nodeRequire = require;
const targetRequire = createRequire(require("node:path").join(process.cwd(), "package.json"));

const target = process.argv[2];
const out = { target, phases: {}, errors: [] };

// Discard anything the Node bootstrap changed between preload and here.
out.baselineSlots = globalThis.__PROBE__.rebaseline();

const describe = (chg) => {
  const a = chg.after, b = chg.before;
  const nv = a ? (a.isAccessor ? (a.get || a.set) : a.value) : undefined;
  const ov = b ? (b.isAccessor ? (b.get || b.set) : b.value) : undefined;
  let src = null, marker = false, fnName = null, arity = null;
  if (typeof nv === "function") {
    try { src = Function.prototype.toString.call(nv).slice(0, 600); } catch { src = null; }
    try { fnName = nv.name || null; arity = nv.length; } catch { /* proxy */ }
    // shimmer stamps its wrappers; the strongest available wrap signal.
    try { marker = Boolean(nv.__wrapped || nv.__original || nv.__unwrap); } catch { /* ignore */ }
  }
  return {
    key: chg.key, kind: chg.kind,
    newIsFunction: typeof nv === "function", oldIsFunction: typeof ov === "function",
    newIsAccessor: Boolean(a && a.isAccessor), oldIsAccessor: Boolean(b && b.isAccessor),
    shimmerMarker: marker, fnName, arity, src,
  };
};

function phase(name, fn) {
  try { fn(); } catch (e) { out.errors.push({ phase: name, error: String(e && e.message || e).slice(0, 300) }); }
  try { out.phases[name] = globalThis.__PROBE__.diff().map(describe); }
  catch (e) { out.errors.push({ phase: name + ":diff", error: String(e).slice(0, 200) }); }
}

// --- phase 1: import time -----------------------------------------------------
let mod = null;
phase("importTime", () => { mod = targetRequire(target); });

// --- phase 2: explicit opt-in -------------------------------------------------
/**
 * Called with no arguments wherever possible. `gracefulify` is special-cased
 * because it takes the fs module and is the canonical opt-in patcher.
 */
/**
 * `proto` is here because of `once`: it ships `Function.prototype.once` but only
 * installs it when the application calls `once.proto()`. Loading the package
 * changes nothing, which is exactly the import-time/opt-in distinction S-1 exists
 * to measure -- `once` reaches 83.1% of server closures in the static scan.
 */
const OPT_IN = ["init", "start", "instrument", "register", "enable", "setup",
                "install", "patch", "activate", "configure", "proto"];
phase("optIn", () => {
  if (!mod) return;
  const candidates = [];
  const root = typeof mod === "function" ? mod : null;
  const obj = (mod && typeof mod === "object") ? mod : (root || {});
  if (typeof obj.gracefulify === "function") {
    candidates.push(() => obj.gracefulify(nodeRequire("fs")));
  }
  for (const name of OPT_IN) {
    if (obj && typeof obj[name] === "function") candidates.push(() => obj[name]());
    if (obj && obj.default && typeof obj.default[name] === "function") candidates.push(() => obj.default[name]());
  }
  out.optInAttempted = candidates.length;
  for (const c of candidates) {
    try { c(); } catch (e) { out.errors.push({ phase: "optIn:call", error: String(e && e.message || e).slice(0, 200) }); }
  }
});

/**
 * Results go to a FILE, not stdout: `elastic-apm-node` writes its own JSON log
 * lines to stdout on load, which corrupted the probe output and lost the target
 * entirely. Anything a target prints is now harmless.
 */
const outPath = process.argv[3];
if (outPath) require("node:fs").writeFileSync(outPath, JSON.stringify(out));
else process.stdout.write(JSON.stringify(out));
