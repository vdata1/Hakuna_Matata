#!/usr/bin/env node
// VENDORED from ../supply-chain-monkey-patch/scripts/fetch-corpus.js (Exp 1/2 tooling).
// Copied rather than imported so this study is reproducible standalone (handoff §6).
// Upstream is the original; changes here are additive, never silent divergence.
/**
 * Fetch and verify the published tarball for every package in the population.
 *
 * We scan PUBLISHED artifacts, not
 * GitHub sources, because transpiled/bundled output is what actually runs in
 * users' applications and frequently differs from repository source.
 *
 * Per package:
 *   1. Download the tarball from the URL recorded in the population CSV.
 *   2. Verify bytes against `dist.integrity` (sha512) and `dist.shasum` (sha1)
 *      BEFORE anything touches disk. A mismatch is a hard failure, never a
 *      warning -- in a supply-chain study an integrity failure is itself a
 *      finding, not noise to be skipped past.
 *   3. Extract into corpus/<name>@<version>/, stripping the tarball's leading
 *      `package/` directory.
 *
 * Package code is NEVER executed: no npm install, no require(), no lifecycle
 * scripts. Download, hash, and untar are the only operations. (Handoff §8.)
 *
 * Usage:  node scripts/fetch-corpus.js [--dataset AugTop1K_npm.json]
 * Output: corpus/                      extracted packages
 *         cache/tarballs/              verified tarballs (re-extraction is free)
 *         results/corpus-<date>.json   manifest: dir -> package, + failures
 */

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { execFileSync } = require("node:child_process");

const CONCURRENCY = 8;
const MAX_RETRIES = 4;

const ROOT = path.resolve(__dirname, "..");
const CACHE = path.join(ROOT, "cache");
const TARBALLS = path.join(CACHE, "tarballs");
const CORPUS = path.join(ROOT, "corpus");
const RESULTS = path.join(ROOT, "results");

const log = (...a) => console.error("[corpus]", ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// CSV (minimal reader -- handles the quoting our writer emits)
// ---------------------------------------------------------------------------

function parseCSV(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n") { row.push(field); rows.push(row); row = []; field = ""; }
    else if (c !== "\r") field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  const header = rows.shift();
  return rows
    .filter((r) => r.length === header.length)
    .map((r) => Object.fromEntries(header.map((h, i) => [h, r[i]])));
}

// ---------------------------------------------------------------------------
// Integrity
// ---------------------------------------------------------------------------

/**
 * Verify downloaded bytes against the registry's recorded hashes.
 *
 * `integrity` is Subresource-Integrity format ("sha512-<base64>"); `shasum` is
 * a legacy hex sha1. Both are checked when present -- they are independent
 * assertions by the registry and disagreement would be significant.
 */
function verifyIntegrity(buf, { integrity, shasum }) {
  const problems = [];
  let checked = 0;

  if (integrity) {
    const [alg, expected] = integrity.split("-", 2);
    if (!alg || !expected) {
      problems.push(`unparseable integrity: ${integrity}`);
    } else {
      const actual = crypto.createHash(alg).update(buf).digest("base64");
      if (actual !== expected) {
        problems.push(`${alg} mismatch: expected ${expected}, got ${actual}`);
      }
      checked++;
    }
  }

  if (shasum) {
    const actual = crypto.createHash("sha1").update(buf).digest("hex");
    if (actual !== shasum) {
      problems.push(`sha1 mismatch: expected ${shasum}, got ${actual}`);
    }
    checked++;
  }

  return { ok: problems.length === 0 && checked > 0, checked, problems };
}

// ---------------------------------------------------------------------------
// Fetch + extract
// ---------------------------------------------------------------------------

async function download(url) {
  let lastErr;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const res = await fetch(url);
      if (res.status === 404) return { missing: true };
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return { buf: Buffer.from(await res.arrayBuffer()) };
    } catch (err) {
      lastErr = err;
      if (attempt < MAX_RETRIES) {
        await sleep(500 * 2 ** attempt + Math.floor(Math.random() * 250));
      }
    }
  }
  throw new Error(`${url}: ${lastErr.message}`);
}

/**
 * Extract into `dest`, stripping the leading `package/` component that every
 * npm tarball uses.
 *
 * Safety: tar is invoked WITHOUT -P/--absolute-names, so both bsdtar (macOS)
 * and GNU tar strip leading slashes and refuse `..` traversal. Extraction only
 * writes files -- it cannot execute them.
 */
function extract(tgz, dest) {
  // maxRetries guards against transient ENOTEMPTY: on macOS an external
  // indexer can create a file inside the tree mid-delete, which surfaces as a
  // spurious extract failure on re-runs.
  fs.rmSync(dest, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
  fs.mkdirSync(dest, { recursive: true });
  execFileSync("tar", ["xzf", tgz, "-C", dest, "--strip-components=1"], {
    stdio: ["ignore", "ignore", "pipe"],
  });

  // Normalise permissions: tarballs may declare directory modes without the
  // execute bit (pngjs ships drw-rw-rw-), which makes the directory
  // untraversable. Left alone, the scanner would silently read ZERO files from
  // those packages and under-report prevalence -- and rmSync could not clean
  // them up on a re-run either. `u+rwX` adds execute to directories only,
  // never to regular files. File CONTENT is never modified.
  execFileSync("chmod", ["-R", "u+rwX", dest], { stdio: ["ignore", "ignore", "pipe"] });
}

/** Count extracted files and how many are JavaScript the scanner will parse. */
function surveyFiles(dir) {
  let files = 0;
  let js = 0;
  let bytes = 0;
  const stack = [dir];
  while (stack.length) {
    let entries;
    try {
      entries = fs.readdirSync(stack.pop(), { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const p = path.join(e.parentPath ?? e.path, e.name);
      if (e.isDirectory()) stack.push(p);
      else if (e.isFile()) {
        files++;
        try { bytes += fs.statSync(p).size; } catch {}
        if (/\.(c|m)?jsx?$/.test(e.name) || /\.(c|m)?ts$/.test(e.name)) js++;
      }
    }
  }
  return { files, js, bytes };
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function pooled(items, worker, label) {
  const out = new Array(items.length);
  const started = Date.now();
  let next = 0;
  let done = 0;
  async function run() {
    while (next < items.length) {
      const i = next++;
      out[i] = await worker(items[i], i);
      done++;
      if (done % 100 === 0 || done === items.length) {
        const rate = done / ((Date.now() - started) / 1000);
        const eta = Math.round((items.length - done) / rate);
        log(`  ${label}: ${done}/${items.length}` +
            (done < items.length ? ` (${rate.toFixed(1)}/s, ~${eta}s left)` : ""));
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, items.length) }, run));
  return out;
}

/**
 * Resolve the input package list.
 *
 * The canonical input is the standalone dataset artifact (AugTop1K_npm.json),
 * which is independent of this analysis and may be shared with other tasks.
 * The population CSV is still accepted so the pipeline works before the dataset
 * has been exported.
 */
function resolveDataset(argv) {
  const flag = argv.findIndex((a) => a === "--dataset" || a === "--population");
  const explicit = flag !== -1 && argv[flag + 1] ? path.resolve(argv[flag + 1]) : null;
  if (explicit) return explicit;

  const dataset = path.join(ROOT, "AugTop1K_npm.json");
  if (fs.existsSync(dataset)) return dataset;

  const found = fs
    .readdirSync(RESULTS)
    .filter((f) => /^population-\d{4}-\d{2}-\d{2}\.csv$/.test(f))
    .sort();
  if (!found.length) {
    throw new Error(
      "no AugTop1K_npm.json and no results/population-<date>.csv; " +
        "run build-population.js then export-dataset.js first"
    );
  }
  return path.join(RESULTS, found[found.length - 1]);
}

/** Normalise either input format to the fields this script needs. */
function loadDataset(file) {
  if (file.endsWith(".json")) {
    const doc = JSON.parse(fs.readFileSync(file, "utf8"));
    const pkgs = Array.isArray(doc) ? doc : doc.packages;
    if (!Array.isArray(pkgs)) {
      throw new Error(`${file}: expected an array or a { packages: [...] } object`);
    }
    return pkgs.map((p) => ({
      rank: p.rank,
      name: p.name,
      version: p.version,
      tarball: p.tarball,
      integrity: p.integrity,
      shasum: p.shasum,
    }));
  }
  return parseCSV(fs.readFileSync(file, "utf8")).map((r) => ({
    rank: Number(r.rank),
    name: r.name,
    version: r.version,
    tarball: r.tarball,
    integrity: r.integrity,
    shasum: r.shasum,
  }));
}

async function main() {
  fs.mkdirSync(TARBALLS, { recursive: true });
  fs.mkdirSync(CORPUS, { recursive: true });
  fs.mkdirSync(RESULTS, { recursive: true });

  const popPath = resolveDataset(process.argv);
  const rows = loadDataset(popPath);
  log(`dataset: ${path.basename(popPath)} (${rows.length} packages)`);

  const results = await pooled(
    rows,
    async (row) => {
      const { name, version, tarball, integrity, shasum } = row;
      const rec = { name, version, rank: Number(row.rank) };

      if (!tarball) {
        return { ...rec, status: "no-tarball-url" };
      }

      // Cache key includes the version, so a re-run after a version bump
      // refetches rather than silently reusing stale bytes.
      const tgz = path.join(TARBALLS, `${name.replace("/", "+")}-${version}.tgz`);
      const dest = path.join(CORPUS, `${name}@${version}`);

      let buf;
      if (fs.existsSync(tgz)) {
        buf = fs.readFileSync(tgz);
      } else {
        const dl = await download(tarball);
        if (dl.missing) return { ...rec, status: "404" };
        buf = dl.buf;
      }

      // Verify BEFORE writing or extracting.
      const check = verifyIntegrity(buf, { integrity, shasum });
      if (!check.ok) {
        return { ...rec, status: "integrity-failure", problems: check.problems };
      }

      if (!fs.existsSync(tgz)) fs.writeFileSync(tgz, buf);

      try {
        extract(tgz, dest);
      } catch (err) {
        const msg = (err.stderr && err.stderr.toString().trim()) || err.message;
        return { ...rec, status: "extract-failure", problems: [msg] };
      }

      const survey = surveyFiles(dest);
      return {
        ...rec,
        status: "ok",
        dir: path.relative(ROOT, dest),
        tarballBytes: buf.length,
        hashesChecked: check.checked,
        ...survey,
      };
    },
    "packages"
  );

  const ok = results.filter((r) => r.status === "ok");
  const failed = results.filter((r) => r.status !== "ok");

  const manifest = {
    generated: new Date().toISOString().slice(0, 10),
    dataset: path.basename(popPath),
    counts: {
      requested: results.length,
      extracted: ok.length,
      failed: failed.length,
      integrityFailures: failed.filter((r) => r.status === "integrity-failure").length,
      totalFiles: ok.reduce((n, r) => n + r.files, 0),
      totalJsFiles: ok.reduce((n, r) => n + r.js, 0),
      totalBytes: ok.reduce((n, r) => n + r.bytes, 0),
    },
    verification:
      "every tarball checked against dist.integrity (sha512) and dist.shasum (sha1) before extraction; no package code executed",
    failures: failed,
    // dir -> package mapping, so the scanner attributes a file to a package by
    // path prefix without having to parse scoped names out of directories.
    packages: ok.map((r) => ({
      dir: r.dir, name: r.name, version: r.version, rank: r.rank,
      files: r.files, js: r.js, bytes: r.bytes,
    })),
  };

  const outPath = path.join(RESULTS, `corpus-${manifest.generated}.json`);
  fs.writeFileSync(outPath, JSON.stringify(manifest, null, 2) + "\n");

  log(`extracted ${ok.length}/${results.length}`);
  if (failed.length) {
    log(`FAILURES (${failed.length}):`);
    for (const f of failed.slice(0, 20)) {
      log(`  ${f.name}@${f.version}: ${f.status}${f.problems ? " -- " + f.problems.join("; ") : ""}`);
    }
  }
  log(`wrote ${outPath}`);
  console.log(JSON.stringify(manifest.counts, null, 2));
}

// Only run when invoked as a CLI -- importing this module (e.g. from a test)
// must not kick off a 1,000-package fetch.
if (require.main === module) {
  main().catch((err) => {
    console.error("[corpus] FAILED:", err);
    process.exit(1);
  });
}

module.exports = { verifyIntegrity, parseCSV, surveyFiles };
