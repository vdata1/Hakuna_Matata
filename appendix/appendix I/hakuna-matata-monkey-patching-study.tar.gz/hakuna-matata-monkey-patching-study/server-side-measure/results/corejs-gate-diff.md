# core-js feature-detection gates across Node, Deno and Bun

Cross-runtime handoff question 3: *does core-js open different feature-detection
gates per runtime?* Deno and Bun ship different esnext coverage than Node, so
core-js's `forced` conditions can fire for a different set of methods.

Runtime versions: **node** 26.5.0, **deno** 2.9.4, **bun** 1.3.14.
core-js version: `3.50.0` — the SAME
installed tree is loaded by all three runtimes, so every difference below is a
runtime difference, not a package-version difference.

## Totals

| runtime | slots replaced or added at import | guard-surface replacements |
|---|---|---|
| node 26.5.0 | 112 | **0** |
| deno 2.9.4 | 111 | **0** |
| bun 1.3.14 | 113 | **0** |

110 slots are touched on all three runtimes; **5** differ.

## The delta

| slot | node | deno | bun |
|---|---|---|---|
| `Error.isError` | — | — | patched |
| `Math.sumPrecise` | patched | — | — |
| `Object.prototype.__proto__` | — | patched | — |
| `Symbol.metadata` | patched | — | patched |
| `globalThis.queueMicrotask` | — | — | patched |

Read this as feature coverage, not as a security difference: a slot patched on
one runtime and not another means that runtime lacked (or failed core-js's
detection for) the native method. None of these are guard-dispatch methods.

## core-js-pure

core-js-pure touches 0 slots on node, 0 slots on deno, 1 slot on bun;
1 slot differs across runtimes. It is the non-global variant, so a
low count here is expected by design, not a runtime effect.

